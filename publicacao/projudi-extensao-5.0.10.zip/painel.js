const $ = (id) => document.getElementById(id);
const SITES_IA = { chatgpt: { nome: "ChatGPT" }, gemini: { nome: "Gemini" }, claude: { nome: "Claude" }, jusbrasil: { nome: "IA do Jusbrasil" } };      // (o resto vive em ia-externa-cliente.js, carregado só no clique)
const iaCliente = () => import("./ia-externa-cliente.js");
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const sa = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
const BASE = "https://projudi.tjgo.jus.br/";
const link = (p) => (p.url ? new URL(p.url, BASE).href : "");
const ROTULO = { naoAnalisadas: "Não analisadas", preAnalisadas: "Pré-analisadas" };
// Serventias e cargos (perfis) que o usuário escondeu: não aparecem nem entram nos totais, e a verificação nem os lê. Guardado na conta do Chrome (leve, sem banco).
let ocultas = { servs: [], cargos: [] }, falhasLeitura = {};
const salvarOcultas = () => chrome.storage.sync.set({ ocultas });
function aplicarOcultas(e) {
  if (!e?.serventias) return e;
  return { ...e, serventias: e.serventias.filter((s) => !ocultas.servs.includes(s.serventia) && !ocultas.cargos.includes(s.perfil)) };
}
let estadoCheio = null;
const guardarEstado = (e) => { estadoCheio = e; estado = aplicarOcultas(e); };
let estado = null, aberto = false, clsAberto = false;      // clsAberto: a tabela “Por classificador” começa recolhida e o usuário a expande
// Dois perfis (dois juízes) na MESMA unidade listam os mesmos processos: cada processo aparece uma só vez (o do primeiro perfil lido) e o perfil repetido não soma de novo.
function deduplicar(e) {
  if (!e?.serventias) return e;
  const unidade = (n) => String(n || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
  const vistos = new Map();
  for (const s of e.serventias) {
    const k = unidade(s.serventia), set = vistos.get(k) || new Set(); vistos.set(k, set);
    const primeira = set.size === 0 && !s.__lida;
    let removidos = 0, lidos = 0;
    for (const tipo of ["naoAnalisadas", "preAnalisadas"]) {
      const lista = s.processos?.[tipo] || [];
      lidos += lista.length;
      const nova = lista.filter((p) => { const id = String(p.processo || "").replace(/\D/g, "").slice(0, 13) || p.processo; if (set.has(id)) { removidos++; return false; } set.add(id); return true; });
      if (s.processos) s.processos[tipo] = nova;
    }
    s.__lida = true;
    if (!primeira && lidos > 0 && removidos === lidos) { s.repetida = true; s.linhas = (s.linhas || []).map((l) => ({ ...l, naoAnalisadas: 0, preAnalisadas: 0 })); }
  }
  return e;
}
// Situação de cada processo na automação: baixado / em que etapa da esteira (Studio, Google Docs, Projudi) está.
let sitProc = {};
const incluidos = new Set();          // já baixados que o usuário marcou de novo à mão
const fora = (proc) => excluidos.has(proc) || (!!sitProc[proc]?.feito && !incluidos.has(proc) && !opcoes.refazer);
const ETAPAS = {
  aguardando: ["⏳", "Baixado — na fila do Studio"], analisando: ["🤖", "Analisando no Studio"], pausado: ["⏸", "Interrompido no Studio — decidir na esteira"],
  conferindo: ["📝", "Google Docs — aguardando a sua conferência"], conferido: ["⚖", "Indo para o Projudi"], cadastrando: ["⚖", "No Projudi — lançar a minuta"],
  concluido: ["✔", "Concluído"], erro: ["✖", "Erro na esteira"], pulado: ["↷", "Pulado na esteira"],
};
async function carregarSituacao() {
  const tudo = await chrome.storage.local.get(null), novo = {};
  for (const [proc, b] of Object.entries(tudo.baixados || {})) novo[proc] = { feito: true, icone: "⬇", texto: "Baixado em " + new Date(b.em).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }), esteira: false };
  for (const id of tudo.esteira_ordem || []) {
    const it = tudo["esteira_" + id]; if (!it) continue;
    const [icone, texto] = ETAPAS[it.estado] || ["", it.estado];
    novo[it.processo] = { feito: true, icone, texto: texto + (it.estado === "erro" && it.erro ? ": " + it.erro : ""), esteira: true, estado: it.estado };
  }
  sitProc = novo;
}
const celulaSit = (proc) => { const x = sitProc[proc]; return x ? `<span class="sit sit-${x.estado || "baixado"}">${x.icone} ${esc(x.texto)}</span>${x.esteira ? ' <a href="esteira.html" target="_blank">abrir esteira</a>' : ""}` : '<span class="sit-nada">não baixado</span>'; };
const selCls = new Set(), selSit = new Set(["naoAnalisadas", "preAnalisadas"]), excluidos = new Set();   // seleção para baixar PDFs
let opcoes = { atualizarBase: false, studio: false, modo: "analise", docs: false, refazer: false, iaId: "chatgpt" };   // o que fazer depois de baixar
let entradaStudio = "pdf";
let agaiaAvisoOculto = false;   // o usuário pediu para não mostrar mais a orientação do prompt do Agaia (guardado na conta do Chrome)
let automacao = {};   // { serventia: { ativa, prompt, promptAgaia, agaiaIgual } } (agaiaIgual: o usuário confirmou que o prompt do Agaia é igual ao do Studio) — guardado na conta do Chrome (sincroniza entre computadores)
const salvarAuto = () => chrome.storage.sync.set({ automacao });
// Preenche sozinho (sem sobrescrever o que o usuário escreveu) o prompt e o arquivo de modelos de cada serventia.
// Não grava mais palpite de prompt/arquivo: esses nomes são de cada usuário (um usuário novo não tem os do gabinete de quem programou a sugestão).
// A sugestão (Sugestoes) aparece só como dica no campo e vale como padrão na hora de rodar; o que o usuário digitar é o que vale.
function completarAuto() {}
const nomeCls = (p) => p.classificador || "(sem classificador)";

const todos = (s) => ["naoAnalisadas", "preAnalisadas"].flatMap((tipo) =>
  (s.processos?.[tipo] || []).map((p) => ({ ...p, situacao: ROTULO[tipo], tipo })));

function casa(p, q) {
  return !q || sa([p.processo, p.classificador, p.usuarioPreAnalise, p.tipoConclusao, p.tipoMovimento, p.tipoAcao, p.urgenciaTexto].join(" ")).includes(q);
}

const dias0 = (p) => RenderProjudi.diasDe(p, Date.now());

function desenhar() {
  const el = $("conteudo"), q = sa($("busca").value.trim());
  $("quando").textContent = estado?.quando ? "Atualizado " + new Date(estado.quando).toLocaleString("pt-BR") : "";
  if (!estado) return (el.innerHTML = '<div class="msg">Ainda sem dados. Clique em “Verificar agora”.</div>');
  if (estado.status === "verificando") return (el.innerHTML = '<div class="msg">Verificando… (pode levar alguns minutos)</div>');
  if (estado.status === "deslogado") return (el.innerHTML = '<div class="msg">Você não está logado no Projudi. <a href="https://projudi.tjgo.jus.br/" target="_blank">Entrar</a> e clique em “Verificar agora”.</div>');
  if (estado.status === "erro") return (el.innerHTML = `<div class="msg erro">Erro: ${esc(estado.mensagem)}</div>`);

  // 1) Resumo: uma linha por serventia
  let h = "<h2>Resumo por serventia</h2><table><tr><th>Serventia</th><th>Perfil</th><th>Não analisadas</th><th>Pré-analisadas</th><th>Urgentes</th><th></th></tr>";
  let tNa = 0, tPre = 0, tUrg = 0;
  for (const s of estado.serventias) {
    const na = s.linhas.reduce((n, l) => n + l.naoAnalisadas, 0), pre = s.linhas.reduce((n, l) => n + l.preAnalisadas, 0);
    const urg = todos(s).filter((p) => p.urgencia && p.urgencia < 3).length;
    tNa += na; tPre += pre; tUrg += urg;
    const lis = (k) => (s.processos?.[k] || []).length;
    const c = (n, k) => `<td class="n ${n ? "alerta" : "zero"}">${n}${n !== lis(k) && (n || lis(k)) ? `<br><small>(lista: ${lis(k)})</small>` : ""}</td>`;
    h += `<tr><td><a href="${esc(s.url)}" target="_blank">${esc(s.serventia)}</a>${s.repetida ? "<br><small>(mesma unidade de outro perfil: processos já contados acima)</small>" : ""}${s.erro ? `<br><span class="erro">${esc(s.erro)}</span>${(falhasLeitura[s.serventia + "|" + s.perfil] || 0) >= 2 ? ' <b class="aviso">falhou em ' + falhasLeitura[s.serventia + "|" + s.perfil] + ' verificações seguidas — ocultar?</b>' : ""}` : ""}${(s.avisos || []).map((a) => `<br><span class="aviso">⚠ ${a.tipo === "naoAnalisadas" ? "não analisadas" : "pré-analisadas"}: a tela inicial conta ${a.esperado}, mas só ${a.lido} vieram na lista</span>`).join("")}</td><td>${esc(s.perfil)}</td>${c(na, "naoAnalisadas")}${c(pre, "preAnalisadas")}<td class="n ${urg ? "alerta" : "zero"}">${urg}</td><td class="ocultar"><button data-ocultar-serv="${esc(s.serventia)}" title="Não mostrar nem ler mais esta serventia">ocultar serventia</button> <button data-ocultar-cargo="${esc(s.perfil)}" title="Não mostrar nem ler mais este cargo (ex.: juiz que saiu)">ocultar cargo</button></td></tr>`;
  }
  h += `<tr><th colspan="2">Total</th><th class="n">${tNa}</th><th class="n">${tPre}</th><th class="n">${tUrg}</th><th></th></tr></table>`;
  const nOc = ocultas.servs.length + ocultas.cargos.length;
  if (nOc) h += `<details class="bloco"><summary>Ocultas (${nOc}) <span class="qtd">— não aparecem nem são lidas; clique para reativar</span></summary>` +
    ocultas.servs.map((n) => `<div>Serventia: <b>${esc(n)}</b> <button data-reativar-serv="${esc(n)}">reativar</button></div>`).join("") +
    ocultas.cargos.map((n) => `<div>Cargo: <b>${esc(n)}</b> <button data-reativar-cargo="${esc(n)}">reativar</button></div>`).join("") +
    `<small>Depois de reativar, clique em “Verificar agora” para ler de novo.</small></details>`;

  // 2) Por classificador (todas as serventias juntas)
  const porCls = new Map();
  for (const s of estado.serventias) for (const p of todos(s)) {
    const k = p.classificador || "(sem classificador)";
    const o = porCls.get(k) || { naoAnalisadas: 0, preAnalisadas: 0 };
    o[p.tipo]++; porCls.set(k, o);
  }
  if (porCls.size) {
    h += `<details id="det-cls" class="bloco" ${clsAberto ? "open" : ""}><summary>Por classificador (todas as serventias) <span class="qtd">— ${porCls.size} classificador(es); clique para ${clsAberto ? "recolher" : "expandir"}</span></summary><table><tr><th>Classificador</th><th>Não analisadas</th><th>Pré-analisadas</th></tr>`;
    [...porCls].sort((a, b) => (b[1].naoAnalisadas + b[1].preAnalisadas) - (a[1].naoAnalisadas + a[1].preAnalisadas))
      .forEach(([k, o]) => (h += `<tr><td class="cls">${esc(k)}</td><td class="n">${o.naoAnalisadas}</td><td class="n">${o.preAnalisadas}</td></tr>`));
    h += "</table></details>";
  }

  // 3a) Baixar PDFs para análise: o assessor marca as serventias (varas) em que trabalha; a extensão baixa os processos delas
  // e cada serventia usa o seu prompt no app de IA. Classificadores são um filtro opcional.
  {
    const todosP = estado.serventias.flatMap((s) => todos(s).map((p) => ({ ...p, serventia: s.serventia, serventiaUrl: s.url || "" })));
    const clsLista = [...new Set(todosP.filter((p) => automacao[p.serventia]?.ativa).map(nomeCls))].sort((a, b) => a.localeCompare(b, "pt-BR"));
    const cand = todosP.filter((p) => automacao[p.serventia]?.ativa && (!selCls.size || selCls.has(nomeCls(p))) && selSit.has(p.tipo) && p.url).sort(Ordenar.comparador($("modo").value));
    const fila = cand.filter((p) => !fora(p.processo));
    completarAuto(estado.serventias);
    h += `<h2>Baixar PDFs para análise</h2><div class="baixar"><div><b>1) Serventias em que você trabalha</b> <small>(a extensão só mexe nas marcadas)</small></div>` +
      `<table class="tp"><thead><tr><th>Automatizar</th><th>Serventia</th><th>Processos</th><th>Prompt no Studio <small>(igual ao da lista “Prompt Ativo”)</small></th><th>Arquivo de modelos na base <small>(PDF único)</small></th><th class="th-agaia">Prompt no ExecAgaia <small>(opcional; vazio = igual ao do Studio)</small>${!agaiaAvisoOculto && estado.serventias.some((x) => { const a = automacao[x.serventia] || {}; return a.ativa && !(a.promptAgaia || "").trim() && !a.agaiaIgual; }) ? '<br><span class="alerta-agaia">⚠️ se usar o Agaia: digite o nome IGUAL ao cadastrado no Agaia</span>' : ""}</th></tr></thead><tbody>` +
      estado.serventias.map((s) => `<tr class="tp-linha"><td class="n"><input type="checkbox" data-serv="${esc(s.serventia)}" ${automacao[s.serventia]?.ativa ? "checked" : ""}></td><td>${esc(s.serventia)}</td><td class="n">${todos(s).length}</td>` +
        `<td><input type="text" data-promptia="${esc(s.serventia)}" value="${esc(automacao[s.serventia]?.prompt || "")}" placeholder="${esc(Sugestoes.prompt(s.serventia) ? "sugestão: " + Sugestoes.prompt(s.serventia) : "ex.: Outros Área Judicial - Família e Sucessões")}" size="40"></td>` +
        `<td><input type="text" data-prompt="${esc(s.serventia)}" value="${esc(automacao[s.serventia]?.arquivoModelos || "")}" placeholder="${esc(Sugestoes.arquivo(s.serventia) ? "sugestão: " + Sugestoes.arquivo(s.serventia) : "ex.: Família - Decisões, Despachos e Sentenças")}" size="40"></td>` +
        `<td><input type="text" data-promptagaia="${esc(s.serventia)}" value="${esc(automacao[s.serventia]?.promptAgaia || "")}" placeholder="nome igual ao do Agaia, ex.: Fabrício Família e Sucessões" title="Digite o nome do prompt exatamente como está cadastrado no Agaia (letras, acentos e espaços iguais). Se estiver diferente, a extensão não acha o prompt." size="34"></td></tr>`).join("") + `</tbody></table>`;
    if (clsLista.length) h += `<div><b>2) Só estes classificadores</b> <small>(opcional — sem marcar nenhum, baixa todos)</small><br>` +
      clsLista.map((c) => `<label class="chip"><input type="checkbox" data-cls="${esc(c)}" ${selCls.has(c) ? "checked" : ""}> ${esc(c)} <small>(${todosP.filter((p) => nomeCls(p) === c && automacao[p.serventia]?.ativa).length})</small></label>`).join(" ") + `</div>`;
    h += `<div>Situação: <label><input type="checkbox" data-sit="naoAnalisadas" ${selSit.has("naoAnalisadas") ? "checked" : ""}> Não analisadas</label> <label><input type="checkbox" data-sit="preAnalisadas" ${selSit.has("preAnalisadas") ? "checked" : ""}> Pré-analisadas</label></div>`;
    const SECOES = [["naoAnalisadas", "Não analisadas"], ["preAnalisadas", "Pré-analisadas"]];
    const ordenada = [];   // a fila segue esta ordem: primeiro as não analisadas, depois as pré-analisadas (cada grupo na ordem de trabalho)
    for (const [tipo, rotulo] of SECOES) {
      const grupo = cand.filter((p) => p.tipo === tipo);
      if (!grupo.length) continue;
      ordenada.push(...grupo);
      const marcados = grupo.filter((p) => !fora(p.processo)).length;
      h += `<h3 class="sub-baixar">${rotulo} <span class="qtd">(${marcados} de ${grupo.length} marcados)</span></h3>` +
        `<table class="tp"><thead><tr><th><input type="checkbox" data-todos="${tipo}" ${marcados === grupo.length ? "checked" : ""} title="Marcar/desmarcar todos"></th><th>Processo</th><th>Serventia</th><th>Classificador</th><th>Urgência</th><th>Início</th><th class="n">Dias</th><th>Situação na automação</th></tr></thead><tbody>` +
        grupo.map((p) => `<tr class="tp-linha"><td><input type="checkbox" data-proc="${esc(p.processo)}" ${fora(p.processo) ? "" : "checked"}></td><td><b>${esc(p.processo)}</b></td><td>${esc(p.serventia)}</td><td class="cls">${esc(nomeCls(p))}</td><td>${esc(p.urgenciaTexto)}</td><td>${esc(p.dataInicio)}</td><td class="n">${dias0(p)}</td><td>${celulaSit(p.processo)}</td></tr>`).join("") + `</tbody></table>`;
    }
    if (!ordenada.length) h += `<p class="zero">${Object.values(automacao).some((x) => x.ativa) ? "Nenhum processo com esse filtro." : "Marque ao menos uma serventia acima."}</p>`;
    const fila2 = ordenada.filter((p) => !fora(p.processo));
    const jaFeitos = cand.filter((p) => sitProc[p.processo]?.feito).length;
    h += `<div class="opcoes"><label><input type="checkbox" data-op="refazer" ${opcoes.refazer ? "checked" : ""}> Baixar de novo também os já baixados <small>(${jaFeitos} já baixado(s)/na esteira — por padrão ficam desmarcados)</small></label> <a href="esteira.html" target="_blank">Abrir a esteira de minutas</a></div>` +
      `<div class="opcoes"><b>3) Depois de baixar:</b><br>` +
      `<label><input type="checkbox" data-op="studio" ${opcoes.studio ? "checked" : ""}> <b>Iniciar a análise</b> de cada PDF no Studio, uma de cada vez, com o prompt da vara:</label>` +
      `<label class="radio"><input type="radio" name="modoStudio" data-modo="analise" ${opcoes.modo === "analise" ? "checked" : ""} ${opcoes.studio ? "" : "disabled"}> Análise dos processos (Gerar Minuta Judicial)</label>` +
      `<label class="radio"><input type="radio" name="modoStudio" data-modo="lupa" ${opcoes.modo === "lupa" ? "checked" : ""} ${opcoes.studio ? "" : "disabled"}> Lupa do Magistrado <small>(pega a minuta do assessor em “Visualizar” das pré-analisadas, sobe os autos na Lupa e clica em Auditar)</small></label>` +
      `<label class="radio"><input type="radio" name="modoStudio" data-modo="turbo" ${opcoes.modo === "turbo" ? "checked" : ""} ${opcoes.studio ? "" : "disabled"}> ⚡ Análise Turbo <small>(Módulo Turbo Independente: anexa o PDF com OCR, Auto-detectar, e gera)</small></label>` +
      `<label class="radio"><input type="radio" name="modoStudio" data-modo="ia" ${opcoes.modo === "ia" ? "checked" : ""} ${opcoes.studio ? "" : "disabled"}> 🌐 IA externa <small>(a extensão anexa o PDF com OCR na IA escolhida, cola o prompt, espera a minuta e traz para o Histórico do Studio)</small></label>` +
      (opcoes.modo === "ia" ? `<div class="ia-ext"><label>IA: <select data-iaid ${opcoes.studio ? "" : "disabled"}>${Object.entries(SITES_IA).map(([k, v]) => `<option value="${k}" ${opcoes.iaId === k ? "selected" : ""}>${v.nome}</option>`).join("")}</select></label> <button type="button" data-ia-perm>Autorizar este site</button> <button type="button" data-ia-diag>Diagnosticar tela da IA</button> <small id="iaMsg">Entre na conta da IA nessa aba antes. O Studio cuida só do prompt e do Histórico.</small></div>` : "") +
      `<label>Enviar os autos ao Studio como: <select data-entrada ${opcoes.studio ? "" : "disabled"}><option value="pdf" ${entradaStudio === "pdf" ? "selected" : ""}>PDF (arquivo completo)</option><option value="txt" ${entradaStudio === "txt" ? "selected" : ""}>texto extraído do PDF com OCR (mais rápido)</option></select> <small>(o .txt de cada processo também é salvo ao lado do PDF)</small></label></div>`;
    h += `<p><button id="baixarLote" ${fila2.length ? "" : "disabled"}>⬇ Baixar PDFs dos ${fila2.length} processo(s)</button> <small>Ordem da fila: “${esc(Ordenar.MODOS[$("modo").value])}”. Cada processo gera <b>número-OCR.pdf</b>.</small></p></div>` +
      `<div class="opcoes"><b>ou, sem baixar PDF:</b><br>` +
      (() => {
        // O aviso só aparece enquanto faltar o nome do prompt do Agaia em alguma serventia da fila e o usuário não tiver confirmado que o prompt é igual ao do Studio (nem escondido o aviso).
        const faltam = [...new Set(fila2.filter((p) => { const a = automacao[p.serventia] || {}; return !(a.promptAgaia || "").trim() && !a.agaiaIgual; }).map((p) => p.serventia))];
        if (agaiaAvisoOculto) return faltam.length ? `<p class="agaia-mostrar"><button type="button" class="link-agaia" data-agaia-mostrar data-testid="agaia-mostrar">ℹ️ Mostrar a orientação sobre o nome do prompt do Agaia</button></p>` : "";
        if (!faltam.length) return "";
        return `<div class="aviso-agaia" data-testid="aviso-agaia"><b>⚠️ Antes de enviar ao Agaia: o nome do prompt tem de ser IGUAL ao cadastrado no Agaia.</b> Os prompts do Agaia podem ter nomes diferentes dos do Studio. Na tabela de serventias (acima), na coluna <b>“Prompt no ExecAgaia”</b>, digite o nome do prompt <u>exatamente como está cadastrado no Agaia</u> (mesmas letras, acentos e espaços; o ideal é copiar e colar). Se o nome estiver diferente, a extensão não acha o prompt no Agaia e o processo dá erro.` +
          `<div class="aviso-agaia-faltam" data-testid="aviso-agaia-faltam">Ainda sem o nome do prompt do Agaia em: <b>${faltam.map(esc).join("; ")}</b>. Nessas serventias a extensão vai procurar no Agaia o nome do prompt do <u>Studio</u>.</div>` +
          `<div class="aviso-agaia-botoes"><button type="button" data-agaia-igual="${esc(JSON.stringify(faltam))}" data-testid="agaia-igual" title="Marca estas serventias como conferidas: o aviso some e a extensão usa o nome do prompt do Studio no Agaia">✔ Meu prompt do Agaia é igual ao do Studio (está correto)</button> <button type="button" data-agaia-ocultar data-testid="agaia-ocultar" title="Esconde esta orientação; dá para mostrá-la de novo">Já entendi, não mostrar mais este aviso</button></div></div>`;
      })() +
      `<button id="enviarAgaia" ${fila2.length ? "" : "disabled"} title="O Agaia lê o processo direto do Projudi; a esteira abre cada processo no Agaia, executa o prompt e lança a minuta no Histórico do Studio">🤖 Enviar os ${fila2.length} processo(s) ao Agaia</button> <small>Um de cada vez, na ordem da fila. Quando o Agaia não consegue (arquivado, segredo de justiça…), o motivo fica registrado no processo e a esteira segue para o próximo.</small></div>`;
    window.__candidatos = fila2;
  }

  // 3) Detalhe: tabelas no formato do Projudi (ou fila única na ordem de trabalho)
  const modo = $("modo").value, fila = $("visao").value === "fila", agora = Date.now();
  const cmp = Ordenar.comparador(modo);
  const dias = (p) => RenderProjudi.diasDe(p, agora);
  const linha = (p) => {
    const num = link(p) ? `<a href="${esc(link(p))}" target="_blank"><b>${esc(p.processo)}</b></a>` : `<b>${esc(p.processo)}</b>`;
    const urg = p.urgencia && p.urgencia < 3 ? `<span class="dot u${p.urgencia}" title="${esc(p.urgenciaTexto)}"></span>` : "";
    return `<tr class="tp-linha"><td class="n">${p.prioridade ?? ""}</td><td class="proc">${urg}${num} <button class="copiar" data-num="${esc(p.processo)}" title="Copiar número do processo">📋</button>${urg ? `<span class="urgtxt">${esc(p.urgenciaTexto)}</span>` : ""}</td>` +
      `<td class="cls">${esc(p.classificador) || '<i>sem classificador</i>'}</td><td>${esc(p.situacao)}${p.origem === "multipla" ? ' <span class="multipla">múltipla</span>' : ""}</td>` +
      `<td>${esc(p.dataInicio)}</td><td class="n ${dias(p) >= 30 ? "velho" : ""}" title="dias desde o início">${dias(p)}</td><td>${esc(p.dataPreAnalise)}</td><td>${esc(p.tipoConclusao)}</td><td>${esc(p.tipoAcao)}</td><td>${esc(p.usuarioPreAnalise)}</td><td>${esc(p.tipoMovimento)}</td></tr>`;
  };
  h += "<h2>Processos</h2>";
  let achou = false;
  for (const s of estado.serventias) {
    const procs = todos(s).filter((p) => casa(p, q));
    if (!procs.length) continue;
    achou = true;
    h += `<details ${aberto || q || fila ? "open" : ""}><summary>${esc(s.serventia)} <span class="qtd">— ${procs.length} processo(s)</span></summary>`;
    if (fila) {
      h += `<table class="tp"><thead><tr><th class="n" title="Prioridade do classificador">Prior.</th><th>Processo</th><th>Classificador</th><th>Situação</th><th>Início (data e hora)</th><th class="n" title="Dias desde o início">Dias</th><th>Pré-análise</th><th>Conclusão</th><th>Tipo da ação</th><th>Usuário</th><th>Movimento</th></tr></thead><tbody>` +
        [...procs].sort(cmp).map(linha).join("") + "</tbody></table>";
    } else {
      for (const tipo of ["naoAnalisadas", "preAnalisadas"]) {
        const dessa = procs.filter((p) => p.tipo === tipo);
        if (!dessa.length) continue;
        h += `<details open><summary>${ROTULO[tipo]} <span class="qtd">(${dessa.length})</span></summary>${RenderProjudi.tabela(dessa, { tipo, modo, dias: true, agora })}</details>`;
      }
    }
    h += "</details>";
  }
  if (!achou) h += `<p class="zero">${q ? "Nada encontrado para esse filtro." : "Nenhum processo listado (ou as listas ainda não foram lidas — use “Copiar diagnóstico” no popup)."}</p>`;
  el.innerHTML = h;
}

function csv() {
  const cab = ["Serventia", "Perfil", "Situação", "Classificador", "Prioridade do classificador", "Urgência", "Processo", "Link", "Conclusão", "Início (data e hora)", "Pré-análise", "Tipo da ação", "Usuário", "Movimento"];
  const lin = [cab];
  estado?.serventias?.forEach((s) => todos(s).sort(Ordenar.comparador($("modo").value)).forEach((p) =>
    lin.push([s.serventia, s.perfil, p.situacao, p.classificador, p.prioridade, p.urgenciaTexto, p.processo, link(p), p.tipoConclusao, p.dataInicio, p.dataPreAnalise, p.tipoAcao, p.usuarioPreAnalise, p.tipoMovimento])));
  const txt = "﻿" + lin.map((r) => r.map((c) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(";")).join("\r\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([txt], { type: "text/csv;charset=utf-8" }));
  a.download = `conclusoes-projudi-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
}

(async () => {
  ocultas = { servs: [], cargos: [], ...((await chrome.storage.sync.get({ ocultas: {} })).ocultas) };
  falhasLeitura = (await chrome.storage.local.get({ falhas: {} })).falhas;
  guardarEstado(deduplicar((await chrome.storage.local.get("estado")).estado));
  await carregarSituacao();
  chrome.storage.onChanged.addListener((c, area) => { if (area === "local" && c.estado) { guardarEstado(deduplicar(c.estado.newValue)); desenhar(); } });
  chrome.storage.onChanged.addListener(async (c, area) => {      // andamento da fila/esteira: atualiza a coluna "Situação na automação"
    if (area === "local" && Object.keys(c).some((k) => k === "baixados" || k.startsWith("esteira_"))) { await carregarSituacao(); desenhar(); }
  });
  const guardado = (k, d) => { try { return localStorage.getItem(k) || d; } catch { return d; } };
  $("modo").innerHTML = Object.entries(Ordenar.MODOS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("");
  $("modo").value = guardado("modo", "trabalho"); $("visao").value = guardado("visao", "tabela");
  for (const id of ["modo", "visao"]) $(id).onchange = () => { try { localStorage.setItem(id, $(id).value); } catch {} desenhar(); };
  $("busca").oninput = desenhar;
  RenderProjudi.ligarCopiar($("conteudo"));
  automacao = (await chrome.storage.sync.get("automacao")).automacao || {};
  agaiaAvisoOculto = !!(await chrome.storage.sync.get("agaiaAvisoOculto")).agaiaAvisoOculto;
  // limpeza única: versões antigas gravaram palpites (e alguns errados, pelo nome da cidade) como se o usuário os tivesse escolhido
  if (!(await chrome.storage.sync.get("palpitesLimpos")).palpitesLimpos) {
    const antigo = (serv) => { const t = String(serv || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); const r = [[/juizado.*fazenda|fazenda.*juizado/, "Juizado Faz.Pub.", "Juizado da Fazenda Pública"], [/juizado.*criminal|criminal.*juizado/, "Juizado Especial Criminal", "Juizado Especial Criminal"], [/juizado.*civel|civel.*juizado/, "Juizado Especial Cível", "Juizado Especial Cível"], [/infracional/, "Infância e Juventude Infracional", "Infância e Juventude Infracional"], [/inf[aâ]ncia|infancia|juventude|inf\.? e juv/, "Infância e Juventude Cível", "Infância e Juventude Cível"], [/familia|sucess/, "Família e Sucessões", "Família"], [/execucao fiscal.*estadual|estadual.*execucao fiscal/, "Execução Fiscal Estadual", "Execução Fiscal"], [/execucao fiscal|exec\.? fiscal/, "Execução Fiscal Municipal", "Execução Fiscal"], [/fazenda/, "Fazenda Pública Comum", "Fazenda Pública"], [/eleitoral/, "Eleitoral", "Eleitoral"], [/criminal|penal/, "Criminal", "Criminal"], [/civel|civil/, "Cível", "Cível"]].find((x) => x[0].test(t)); return r ? { p: "Outros Área Judicial - " + r[1], a: r[2] + " - Decisões, Despachos e Sentenças" } : null; };
    for (const [serv, v] of Object.entries(automacao)) { if (!v || typeof v !== "object") continue; const o = antigo(serv); if (!o) continue; if (v.prompt === o.p) v.prompt = ""; if (v.arquivoModelos === o.a) v.arquivoModelos = ""; }
    salvarAuto(); await chrome.storage.sync.set({ palpitesLimpos: true });
  }
  entradaStudio = ((await chrome.storage.sync.get("esteiraConfig")).esteiraConfig || {}).entrada || "pdf";
  opcoes = { ...opcoes, ...((await chrome.storage.sync.get("opcoesLote")).opcoesLote || {}) };
  if (opcoes.modo === "mesa") opcoes.modo = "analise";      // a Mesa de Audiência fica só na tela da Pauta de audiências
  $("conteudo").addEventListener("change", (e) => {
    const t = e.target, dado = t.dataset || {};
    if (dado.entrada !== undefined) { entradaStudio = t.value; chrome.storage.sync.get("esteiraConfig").then(({ esteiraConfig = {} }) => chrome.storage.sync.set({ esteiraConfig: { ...esteiraConfig, entrada: t.value } })); return; }
    if (dado.serv !== undefined) { automacao[dado.serv] = { ...automacao[dado.serv], ativa: t.checked }; salvarAuto(); }
    else if (dado.promptagaia !== undefined) { automacao[dado.promptagaia] = { ...automacao[dado.promptagaia], promptAgaia: t.value.trim() }; salvarAuto(); desenhar(); return; }
    else if (dado.promptia !== undefined) { automacao[dado.promptia] = { ...automacao[dado.promptia], prompt: t.value.trim() }; salvarAuto(); return; }
    else if (dado.prompt !== undefined) { automacao[dado.prompt] = { ...automacao[dado.prompt], arquivoModelos: t.value.trim() }; salvarAuto(); return; }
    else if (dado.cls !== undefined) { t.checked ? selCls.add(dado.cls) : selCls.delete(dado.cls); }
    else if (dado.op !== undefined) { opcoes[dado.op] = t.checked; chrome.storage.sync.set({ opcoesLote: opcoes }); }
    else if (dado.iaid !== undefined) { opcoes.iaId = t.value; chrome.storage.sync.set({ opcoesLote: opcoes }); }
    else if (dado.modo !== undefined) { opcoes.modo = dado.modo; chrome.storage.sync.set({ opcoesLote: opcoes }); }
    else if (dado.sit !== undefined) { t.checked ? selSit.add(dado.sit) : selSit.delete(dado.sit); }
    else if (dado.proc !== undefined) { if (t.checked) { excluidos.delete(dado.proc); incluidos.add(dado.proc); } else { excluidos.add(dado.proc); incluidos.delete(dado.proc); } }
    else if (dado.todos !== undefined) { // marcar/desmarcar todos de UMA tabela (não analisadas ou pré-analisadas)
      const tabela = t.closest("table");
      [...tabela.querySelectorAll("input[data-proc]")].forEach((x) => (t.checked ? (excluidos.delete(x.dataset.proc), incluidos.add(x.dataset.proc)) : (excluidos.add(x.dataset.proc), incluidos.delete(x.dataset.proc))));
    }
    else return;
    desenhar();
  });
  $("conteudo").addEventListener("click", async (e) => {
    const d = e.target.dataset || {};
    const mexer = (lista, v, add) => { const i = ocultas[lista].indexOf(v); if (add && i < 0) ocultas[lista].push(v); if (!add && i >= 0) ocultas[lista].splice(i, 1); salvarOcultas(); estado = aplicarOcultas(estadoCheio); desenhar(); };
    if (d.iaPerm !== undefined) { const m = document.getElementById("iaMsg"); const ok = await (await iaCliente()).pedirPermissao(opcoes.iaId).catch(() => false); if (m) m.textContent = ok ? `${SITES_IA[opcoes.iaId].nome} autorizado.` : "Autorização negada."; return; }
    if (d.iaDiag !== undefined) { const m = document.getElementById("iaMsg"); if (m) m.textContent = "Olhando a tela…"; try { const r = await (await iaCliente()).diagnosticarIa(opcoes.iaId); if (m) m.textContent = (r.pronto ? "✅ Pronto: " : "⚠ Atenção: ") + `caixa: ${r.compositor || "NÃO achada"}; anexar: ${r.botaoAnexar || r.campoArquivo || "NÃO achado"}; enviar: ${r.botaoEnviar || "(só aparece com texto)"}; logado: ${r.logado ? "sim" : "NÃO"}${r.bloqueio ? "; captcha!" : ""}.`; } catch (err) { if (m) m.textContent = "Erro: " + err.message; } return; }
    if (d.ocultarServ !== undefined) return mexer("servs", d.ocultarServ, true);
    if (d.ocultarCargo !== undefined) return mexer("cargos", d.ocultarCargo, true);
    if (d.reativarServ !== undefined) return mexer("servs", d.reativarServ, false);
    if (d.reativarCargo !== undefined) return mexer("cargos", d.reativarCargo, false);
    if (!e.target.closest || !e.target.closest("#baixarLote")) return;
    const fila = window.__candidatos || [];   // já na ordem de trabalho
    if (!fila.length) return;
    const hoje = new Date().toISOString().slice(0, 10), id = String(Date.now());
    const vistosLote = new Set();      // o mesmo processo nunca entra duas vezes no lote (ex.: dois perfis/juízes na mesma unidade)
    const itens = fila.filter((p) => { const k = String(p.processo).replace(/\D/g, "").slice(0, 13) || p.processo; if (vistosLote.has(k)) return false; vistosLote.add(k); return true; }).map((p) => ({ processo: p.processo, url: p.url, classificador: nomeCls(p), serventia: p.serventia, situacao: p.tipo, urlPre: p.urlPre || "", serventiaUrl: p.serventiaUrl || "", arquivoModelos: automacao[p.serventia]?.arquivoModelos || "", prompt: automacao[p.serventia]?.prompt || (globalThis.Sugestoes ? Sugestoes.prompt(p.serventia) : "") || "", pasta: `Projudi/${hoje}/${[p.serventia, nomeCls(p)].map((x) => String(x).replace(/[\\/:*?"<>|]+/g, "_").slice(0, 60).replace(/[\s.]+$/g, "")).join("/")}` }));
    // sem prompt da matéria a análise rodaria com o prompt que estiver ATIVO no Studio (ex.: Criminal num processo de Família): não deixa seguir
    if (opcoes.studio && opcoes.modo !== "turbo") {
      const sem = [...new Set(itens.filter((i) => !i.prompt).map((i) => i.serventia))];
      if (sem.length) { alert("Defina o prompt destas serventias antes de enviar ao Studio (campo “Prompt no Studio” na tabela de serventias):\n\n" + sem.join("\n")); return; }
    }
    await chrome.storage.local.set({ ["lote_" + id]: { itens, pasta: "Projudi/" + hoje, opcoes: { atualizarBase: false, studio: { ativo: opcoes.studio, modo: opcoes.modo, docs: false, iaId: opcoes.iaId } } } });
    chrome.tabs.create({ url: chrome.runtime.getURL("lote.html?lote=" + id) });
  });
  // Aviso do prompt do Agaia: confirmar que o prompt é igual ao do Studio, esconder a orientação ou mostrá-la de novo
  document.addEventListener("click", (e) => {
    const t = e.target.closest ? e.target.closest("[data-agaia-igual],[data-agaia-ocultar],[data-agaia-mostrar]") : null; if (!t) return;
    if (t.dataset.agaiaIgual !== undefined) { let lista = []; try { lista = JSON.parse(t.dataset.agaiaIgual); } catch (err) { /* sem lista */ } for (const sv of lista) automacao[sv] = { ...automacao[sv], agaiaIgual: true }; salvarAuto(); }
    else if (t.dataset.agaiaOcultar !== undefined) { agaiaAvisoOculto = true; chrome.storage.sync.set({ agaiaAvisoOculto: true }); }
    else { agaiaAvisoOculto = false; chrome.storage.sync.set({ agaiaAvisoOculto: false }); }
    desenhar();
  });
  // Esteira → Agaia (sem baixar PDF): cada processo entra na fila da esteira no modo "agaia"; a esteira abre o processo no Agaia, executa o prompt e lança a minuta no Histórico do Studio
  document.addEventListener("click", async (e) => {
    if (!e.target.closest || !e.target.closest("#enviarAgaia")) return;
    const fila = window.__candidatos || []; if (!fila.length) return;
    const btn = e.target.closest("#enviarAgaia"); btn.disabled = true;
    const { enfileirar, todos } = await import("./esteira-banco.js");
    const jaNaFila = new Set((await todos()).filter((i) => i.modo === "agaia" && ["aguardando", "analisando", "pausado"].includes(i.estado)).map((i) => String(i.processo).replace(/\D/g, "").slice(0, 13)));
    const { automacao: aut = {} } = await chrome.storage.sync.get("automacao");
    let n = 0, sem = [];
    for (const p of fila) {
      const k = String(p.processo).replace(/\D/g, "").slice(0, 13) || p.processo; if (jaNaFila.has(k)) continue; jaNaFila.add(k);
      const prompt = aut[p.serventia]?.promptAgaia || aut[p.serventia]?.prompt || (globalThis.Sugestoes ? Sugestoes.prompt(p.serventia) : "") || "";
      if (!prompt) { sem.push(p.serventia); }
      await enfileirar({ processo: p.processo, url: p.url, urlPre: p.urlPre || "", serventia: p.serventia, serventiaUrl: p.serventiaUrl || "", prompt, modo: "agaia", pdfNome: "(Agaia — sem PDF)", classificador: nomeCls(p) }, new Uint8Array([0]));
      n++;
    }
    try { chrome.runtime.sendMessage({ acao: "esteira-abrir" }); } catch (err) { /* a esteira abre pelo link */ }
    btn.textContent = `✔ ${n} processo(s) enviados à esteira (modo Agaia)` + (sem.length ? ` — sem prompt do Agaia em: ${[...new Set(sem)].join(", ")} (defina “Prompt no Agaia” na tabela de serventias)` : "");
  });
  $("csv").onclick = csv;
  document.addEventListener("toggle", (e) => { if (e.target && e.target.id === "det-cls") clsAberto = e.target.open; }, true);
  $("abrir").onclick = () => { aberto = !aberto; $("abrir").textContent = aberto ? "Recolher tudo" : "Expandir tudo"; desenhar(); };
  $("atualizar").onclick = () => chrome.runtime.sendMessage({ acao: "verificar" });
  desenhar();
})();

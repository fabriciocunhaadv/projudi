const DOMINIO = "tjgo.jus.br";
const BASE = "https://projudi.tjgo.jus.br/";
const LISTA = BASE + "Usuario?PaginaAtual=9";
const PADRAO = { filtro: "", notificar: true };      // filtro de serventias vazio = todas (vários juízes, de comarcas diferentes, usam a extensão)
let rodando = false;
const getOcultas = async () => { const o = (await chrome.storage.sync.get({ ocultas: {} })).ocultas || {}; return { servs: o.servs || [], cargos: o.cargos || [] }; };

// o padrão antigo era "Montes Claros": uma única vez, esse valor (que quase sempre era só o padrão gravado) volta a vazio
async function limparFiltroAntigo() {
  const c = await chrome.storage.sync.get({ filtro: "", filtroPadraoLimpo: false });
  if (!c.filtroPadraoLimpo) await chrome.storage.sync.set({ filtroPadraoLimpo: true, ...(c.filtro === "Montes Claros" ? { filtro: "" } : {}) });
}
const getCfg = async () => { await limparFiltroAntigo(); return { ...PADRAO, ...(await chrome.storage.sync.get(PADRAO)) }; };

async function garantirOffscreen() {
  const ja = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (ja.length) return;
  await chrome.offscreen.createDocument({
    url: "offscreen.html", reasons: ["DOM_PARSER"], justification: "Ler o HTML do Projudi",
  });
}

const ler = (tipo, html) => chrome.runtime.sendMessage({ alvo: "offscreen", tipo, html });

async function baixar(url, init = {}) {
  const r = await fetch(url, { credentials: "include", cache: "no-store", ...init });
  if (!r.ok) throw new Error("HTTP " + r.status);
  return new TextDecoder("windows-1252").decode(await r.arrayBuffer()); // o Projudi usa LATIN1
}

const INICIO = BASE + "Usuario?PaginaAtual=-10"; // tela dentro do iframe da moldura
const LISTAS = { // menu Conclusões: "Pendentes" e "Pré-Análises > Simples"
  naoAnalisadas: "PreAnalisarConclusao?PaginaAtual=2&tipo=todas",
  preAnalisadas: "PreAnalisarConclusao?PaginaAtual=6&tipo=todas",
  // "Pré-Análises > Múltiplas": a contagem da tela inicial soma Simples + Múltiplas
  preMultiplas: "PreAnalisarConclusao?PaginaAtual=7&tipo=todas",
};

const chaveProc = (p) => p.idPendencia || `${p.processo}|${p.tipoConclusao}|${p.dataPreAnalise}`;
const juntar = (a, b) => { const vistos = new Set(a.map(chaveProc)); return a.concat(b.filter((p) => !vistos.has(chaveProc(p)))); };

async function guardarDebug(rotulo, url, html) {
  const limpo = html.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").slice(0, 60000);
  const { debug = {} } = await chrome.storage.local.get("debug");
  debug[rotulo] = { url, html: limpo };
  await chrome.storage.local.set({ debug });
}

async function lerProcessos(s, tipo) {
  const url = BASE + LISTAS[tipo];
  let html = await baixar(url);
  let r = await ler("processos", html);
  if (!r.processos.length && r.formulario) { // a lista só aparece depois de "Consultar"
    const f = r.formulario, alvo = new URL(f.action || LISTAS[tipo], url).href;
    const dados = new URLSearchParams(f.campos);
    html = f.method === "post"
      ? await baixar(alvo, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: dados })
      : await baixar(alvo + (alvo.includes("?") ? "&" : "?") + dados);
    r = await ler("processos", html);
  }
  const { debug = {} } = await chrome.storage.local.get("debug");
  if (!r.processos.length) await guardarDebug(`${s.serventia} :: ${tipo} (SEM PROCESSOS LIDOS)`, url, html);
  else if (!debug["amostra " + tipo]) await guardarDebug("amostra " + tipo, url, html);
  return r.processos;
}

// Compara o nome da serventia da lista ("… - GO") com o da tela ("Serventia: …", às vezes cortado): sem acento, sem “- GO”, um começando o outro.
function mesmaServentia(tela, lista) {
  if (!tela) return true;      // a tela não informa a serventia: não dá para conferir
  const n = (s) => semAcento(s).replace(/\s+/g, " ").replace(/\s*-\s*go\s*$/, "").replace(/[….]+$/, "").trim();
  const a = n(tela), b = n(lista);
  return !!a && !!b && (a === b || a.startsWith(b) || b.startsWith(a));
}

const ocioso = (ms) => new Promise((ok) => setTimeout(ok, ms));

async function verificar() {
  if (rodando) return;
  const { lote_sessao_ts: ocupadaPor } = await chrome.storage.local.get("lote_sessao_ts");
  if (ocupadaPor && Date.now() - ocupadaPor < 120000) {      // um lote de PDFs está trocando de serventia na mesma sessão: os números sairiam misturados
    await chrome.storage.local.set({ estado: { status: "erro", mensagem: "Há um download de PDFs (lote) em andamento: ele troca de serventia na sessão do Projudi. Aguarde terminar e clique em Verificar agora." } });
    return;
  }
  rodando = true;
  await chrome.storage.local.set({ estado: { status: "verificando" } });
  try {
    const cfg = await getCfg();
    await garantirOffscreen();
    const lista = await ler("lista", await baixar(LISTA));
    if (!lista.logado) return await terminar({ status: "deslogado" }, cfg);

    const filtros = cfg.filtro.split(";").map((f) => semAcento(f)).filter(Boolean);
    const oc = await getOcultas();      // serventias/cargos que o usuário escondeu no painel: nem são lidos
    const alvos = lista.itens.filter((i) =>
      (!filtros.length || filtros.some((f) => semAcento(i.serventia).includes(f))) && !oc.servs.includes(i.serventia) && !oc.cargos.includes(i.perfil));
    const falhas = (await chrome.storage.local.get({ falhas: {} })).falhas;

    await chrome.storage.local.set({ debug: {} });
    const serventias = [];
    for (const a of alvos) {
      const url = new URL(a.href, BASE).href;
      const s = { serventia: a.serventia, perfil: a.perfil, url, linhas: [], processos: { naoAnalisadas: [], preAnalisadas: [] }, erro: null };
      try {
        // escolhe a serventia na sessão e confere, pela própria tela, que a sessão está nela (outra aba do Projudi pode trocar de serventia no meio)
        let html = "", r = null, ok = false;
        for (let t = 0; t < 4 && !ok; t++) {
          await baixar(url); // escolhe a serventia na sessão (devolve só a moldura da página)
          html = await baixar(INICIO);
          r = await ler("conclusoes", html);
          ok = mesmaServentia(r.serventiaTela, a.serventia);
          if (!ok) await ocioso(2500 * (t + 1));
        }
        if (!ok) throw new Error(`a sessão do Projudi mudou de serventia durante a leitura (a tela mostrou “${r?.serventiaTela || "?"}” em vez de “${a.serventia}”): outra aba do Projudi está trocando de serventia; feche-as e verifique de novo`);
        if ((await chrome.storage.local.get("debug")).debug?.["amostra inicio"] === undefined) await guardarDebug("amostra inicio", INICIO, html);
        if (!r.linhas) { guardarDebug(s.serventia + " :: tela inicial", INICIO, html); s.erro = "tabela de conclusões não encontrada"; }
        else {
          s.linhas = r.linhas;
          const soma = (k) => r.linhas.reduce((n, l) => n + l[k], 0);
          const nNa = soma("naoAnalisadas"), nPre = soma("preAnalisadas");
          if (nNa) s.processos.naoAnalisadas = await lerProcessos(s, "naoAnalisadas");
          if (nPre) {
            const simples = (await lerProcessos(s, "preAnalisadas")).map((p) => ({ ...p, origem: "simples" }));
            let todas = simples;
            if (simples.length < nPre) { // o que falta está nas pré-análises "Múltiplas"
              await ocioso(800);
              const multiplas = (await lerProcessos(s, "preMultiplas")).map((p) => ({ ...p, origem: "multipla" }));
              todas = juntar(simples, multiplas);
            }
            s.processos.preAnalisadas = todas;
          }
          // a sessão continuou na mesma serventia até o fim da leitura das listas?
          const fim = await ler("conclusoes", await baixar(INICIO));
          if (!mesmaServentia(fim.serventiaTela, a.serventia)) throw new Error(`a sessão do Projudi trocou de serventia no meio da leitura (agora “${fim.serventiaTela || "?"}”): outra aba do Projudi está mudando de serventia; feche-as e verifique de novo`);
          s.avisos = [["naoAnalisadas", nNa], ["preAnalisadas", nPre]]
            .map(([k, esperado]) => ({ tipo: k, esperado, lido: s.processos[k].length }))
            .filter((x) => x.lido !== x.esperado);
        }
      } catch (e) {
        s.erro = String(e.message || e);
      }
      const kf = s.serventia + "|" + s.perfil; if (s.erro) falhas[kf] = (falhas[kf] || 0) + 1; else delete falhas[kf];      // erro repetido: o painel sugere ocultar
      serventias.push(s);
      await ocioso(1500); // ritmo humano
    }
    await chrome.storage.local.set({ falhas });
    await terminar({ status: "ok", quando: Date.now(), serventias }, cfg);
  } catch (e) {
    await chrome.storage.local.set({ estado: { status: "erro", mensagem: String(e.message || e) } });
  } finally {
    rodando = false;
  }
}

// O background não carrega parser.js (precisa de DOM); só a normalização de texto é repetida aqui.
function semAcento(s) {
  return (s || "").trim().normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
}

const chave = (s, l) => `${s.serventia}|${s.perfil}|${l.tipo}`;

async function terminar(estado, cfg) {
  const { estado: anterior } = await chrome.storage.local.get("estado");
  await chrome.storage.local.set({ estado });
  if (estado.status !== "ok") {
    await chrome.action.setBadgeText({ text: "!" });
    await chrome.action.setBadgeBackgroundColor({ color: "#b00020" });
    return;
  }
  let naoAn = 0, pre = 0;
  const novos = [];
  const antes = new Map();
  (anterior?.serventias || []).forEach((s) =>
    s.linhas.forEach((l) => antes.set(chave(s, l), l)));
  estado.serventias.forEach((s) => s.linhas.forEach((l) => {
    naoAn += l.naoAnalisadas; pre += l.preAnalisadas;
    const a = antes.get(chave(s, l));
    if (anterior?.status === "ok" && l.naoAnalisadas > (a?.naoAnalisadas || 0))
      novos.push(`${s.serventia}: ${l.tipo} (+${l.naoAnalisadas - (a?.naoAnalisadas || 0)})`);
  }));
  await chrome.action.setBadgeText({ text: naoAn ? String(naoAn) : "" });
  await chrome.action.setBadgeBackgroundColor({ color: "#1a56a0" });
  if (cfg.notificar && novos.length) {
    chrome.notifications.create({
      type: "basic", iconUrl: "icone.png", title: "Novas conclusões no Projudi",
      message: novos.slice(0, 5).join("\n"),
    });
  }
}


// A verificação das conclusões é SEMPRE manual ("Verificar agora"): nada roda sozinho no Projudi, para não derrubar a sessão do usuário.
chrome.runtime.onInstalled.addListener(() => { chrome.storage.sync.remove("formatacao"); });
// Captura o HTML da aba (e de todos os iframes), sem scripts/estilos, para diagnóstico/ajustes.
async function capturarAba(tabId) {
  const res = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    func: () => {
      const orig = [...document.querySelectorAll("input,textarea,select")];
      const c = document.documentElement.cloneNode(true);
      [...c.querySelectorAll("input,textarea,select")].forEach((el, i) => { // grava o estado atual dos campos
        const o = orig[i];
        if (!o) return;
        if (["checkbox", "radio"].includes(o.type)) el.toggleAttribute("checked", o.checked);
        else if (o.tagName === "INPUT" && !["password", "file"].includes(o.type)) el.setAttribute("value", o.value);
        else if (o.tagName === "TEXTAREA") el.textContent = o.value;
      });
      c.querySelectorAll("script,style,link,svg,noscript,meta,input[type=password]").forEach((e) => e.remove());
      return { url: location.href, titulo: document.title, html: c.outerHTML.replace(/\s+/g, " ").slice(0, 200000) };
    },
  });
  return res.map((r) => r.result).filter(Boolean);
}

// Atalho Alt+Shift+C: captura a aba/janela em foco (inclusive janelas pop-up sem barra de extensões)
// e abre uma página com o texto pronto para copiar.
async function capturarEAbrir(tabId) {
  if (!tabId) [{ id: tabId } = {}] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const quadros = await capturarAba(tabId);
  const txt = quadros.map((f, i) => `===== FRAME ${i} | ${f.url} | ${f.titulo} =====\n${f.html}`).join("\n\n");
  await chrome.storage.local.set({ captura: txt });
  await chrome.tabs.create({ url: chrome.runtime.getURL("captura.html") });
}
chrome.commands.onCommand.addListener((c) => c === "capturar-tela" && capturarEAbrir().catch(console.error));

// Pede ao Projudi (aba "Navegação de Arquivos") para abrir a janela "Gerar PDF"; lá o gerarpdf.js marca os arquivos e gera.
importScripts("tabs-retry.js", "gerar-util.js", "projudi-quadro.js", "lancar-projudi.js");
async function abrirGerarPdf(tabId) {
  if (!tabId) return false;
  const r = await GerarUtil.capturarGerar(tabId);
  if (r.url) { await chrome.tabs.create({ url: r.url, active: true }); return true; }
  return r.achou;    // achou e clicou, mas a página abriu a janela por conta própria
}

chrome.runtime.onMessage.addListener((m, s, responder) => {
  if (m?.acao === "agaia-enviar") {       // abre o ExecAgaia com o número do processo; agaia-form.js marca as opções e o prompt
    const rota = m.rota !== false;      // padrão: faz o caminho pelas telas do Agaia (agaia-rota.js); "rota: false" abre direto pela URL do processo
    const url = rota ? "https://simplesefacil.tjgo.jus.br/agaia/home"
      : "https://simplesefacil.tjgo.jus.br/agaia/prompts/moderno?numero_processo=" + encodeURIComponent(m.numero) + "&tipo_processo=judicial&acao_id=6&validado=True";
    chrome.storage.local.set({ agaia_pedido: { numero: m.numero, serventia: m.serventia || "", prompt: m.prompt || "", rota, ts: Date.now() } })
      .then(() => chrome.tabs.create({ url, active: true })).then(() => responder({ ok: true }), (e) => responder({ ok: false, erro: String(e.message || e) }));
    return true;
  }
  if (m?.acao === "lancar-projudi") { lancarNoProjudi(m, s.tab).then(responder, (e) => responder({ ok: false, erro: String(e.message || e) })); return true; }      // botão “Lançar no Projudi” da minuta do Studio
  if (m?.acao === "lancar-serventias") {      // lista as serventias NÃO ocultas para o usuário escolher onde lançar a minuta
    (async () => {
      const { estado } = await chrome.storage.local.get("estado"), oc = await getOcultas();
      const vistos = new Set(), lista = [];
      for (const sv of (estado?.serventias || [])) { if (!sv.url || oc.servs.includes(sv.serventia) || oc.cargos.includes(sv.perfil) || vistos.has(sv.url)) continue; vistos.add(sv.url); lista.push({ serventia: sv.serventia, perfil: sv.perfil || "", url: sv.url }); }
      const { lancar_ultima_serventia: ultima = "" } = await chrome.storage.local.get("lancar_ultima_serventia");
      const item = m.processo ? await lpAchaItem(m.processo).catch(() => null) : null;
      const sugerida = [ultima, item?.serventiaUrl ? new URL(item.serventiaUrl, LP_BASE).href : ""].find((u) => u && lista.some((x) => x.url === u)) || "";
      return { ok: true, serventias: lista, sugerida };
    })().then(responder, (e) => responder({ ok: false, serventias: [], erro: String(e.message || e) }));
    return true;
  }
  if (m?.acao === "leis-abrir") {       // o app (Central de fontes) pediu para buscar as leis do Planalto pelo navegador: guarda o pedido e abre a página que pede a permissão e busca
    chrome.storage.local.set({ leisJob: { pedidoId: String(m.pedidoId || ""), tabId: s.tab ? s.tab.id : null, leis: Array.isArray(m.leis) ? m.leis.slice(0, 40) : [] } })
      .then(() => chrome.tabs.create({ url: chrome.runtime.getURL("leis.html"), active: true })).then(() => responder({ ok: true }), (e) => responder({ ok: false, erro: String(e.message || e) }));
    return true;
  }
  if (m?.acao === "minha-aba") { responder({ tabId: s.tab ? s.tab.id : null }); return false; }
  if (m?.acao === "esteira-abrir") {       // garante a aba que roda a fila de minutas
    const url = chrome.runtime.getURL("esteira.html");
    chrome.runtime.getContexts({ contextTypes: ["TAB"] }).then((cs) => (cs.some((c) => (c.documentUrl || "").startsWith(url)) ? null : chrome.tabs.create({ url, active: false }))).then(() => responder({ ok: true }), (e) => responder({ ok: false, erro: String(e.message || e) }));
    return true;
  }
  if (m?.acao === "gerar-pdf-interceptar") { // a janela "Gerar PDF" entregou o pedido: a extensão busca o PDF, faz OCR e salva
    const id = String(Date.now());
    chrome.storage.local.set({ ["gerar_" + id]: { url: m.url, corpo: m.corpo, nome: m.nome, pasta: m.pasta, lote: m.lote, studio: m.studio } })
      .then(() => chrome.tabs.create({ url: chrome.runtime.getURL("ocr.html?gerar=" + id), active: !m.lote }))
      .then((aba) => { chrome.tabs.update(aba.id, { autoDiscardable: false }).catch(() => {}); return aba; })      // o Chrome não pode descartar a aba de OCR (Economia de memória) no meio do trabalho
      .then(() => responder({ ok: true }), (e) => responder({ erro: String(e.message || e) }));
    return true;
  }
  if (m?.acao === "gerar-pdf-projudi") { // pedido da página de seleção
    chrome.storage.local.set({ gerarpdf_pedido: { ...m.pedido, ts: Date.now() } })
      .then(() => abrirGerarPdf(m.tabId).catch(() => false))
      .then((abriu) => responder({ ok: true, abriu }), (e) => responder({ erro: String(e.message || e) }));
    return true;
  }
  if (m?.acao === "baixar-arquivos") { // vindo do botão na "Navegação de Arquivos": abre a página de seleção
    const id = String(Date.now());
    chrome.storage.local.set({ ["baixar_" + id]: { ...m.job, tabId: s.tab?.id } })
      .then(() => chrome.tabs.create({ url: chrome.runtime.getURL("baixar.html?job=" + id) }))
      .then(() => responder({ ok: true }), (e) => responder({ erro: String(e.message || e) }));
    return true;
  }
  if (m?.acao === "verificar") verificar();
  if (m?.acao === "capturar") { capturarAba(m.tabId).then(responder, (e) => responder({ erro: String(e.message || e) })); return true; }
});


// ---------- OCR automático dos PDFs baixados do Projudi ----------
// Só se a pessoa ligar a opção em Ferramentas (padrão: desligada). Quando um PDF de *.tjgo.jus.br termina de baixar, abre a página de OCR em segundo plano.
// Ela lê o arquivo, faz OCR só nas páginas-imagem e salva "<nome>-OCR.pdf" em Downloads.
const tratados = new Set();
const hostProjudi = (u) => { try { return new URL(u).hostname.endsWith(DOMINIO); } catch { return false; } };
const parecePdf = (it) => /pdf/i.test(it.mime || "") || /\.pdf$/i.test(it.filename || "") || /\.pdf(\?|$)|GerarPDF/i.test(it.finalUrl || it.url || "");

chrome.downloads.onChanged.addListener(async (delta) => {
  if (!delta.state || delta.state.current !== "complete") return;
  try {
    const [it] = await chrome.downloads.search({ id: delta.id });
    if (!it || tratados.has(it.id) || it.byExtensionId === chrome.runtime.id) return; // não refaz o que a própria extensão baixou
    if (!hostProjudi(it.finalUrl || it.url) || !parecePdf(it)) return;
    const { ocr } = await chrome.storage.sync.get("ocr");
    if (ocr?.ocrAuto !== true) return;      // desligado por padrão: o PDF baixado pelo botão do próprio Projudi não aciona a extensão; só liga se a pessoa marcar em Ferramentas
    tratados.add(it.id);
    await chrome.storage.local.set({ ["ocr_" + it.id]: { id: it.id, url: it.finalUrl || it.url, filename: it.filename } });
    await chrome.tabs.create({ url: chrome.runtime.getURL("ocr.html?auto=" + it.id), active: false });
  } catch (e) { console.error("OCR automático:", e); }
});

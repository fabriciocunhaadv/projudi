// No app "Assessor Judicial" (AI Studio): coloca um PDF na "Base de Conhecimento do Gabinete", SUBSTITUINDO o documento de mesmo nome
// se já existir (apaga o antigo e envia o novo), para nunca duplicar.
(() => {
  if (window.__projudiStudioBase) return;
  window.__projudiStudioBase = true;
  try { document.documentElement.dataset.assessorExtensao = chrome.runtime.getManifest().version; } catch (e) { /* sem manifest */ }      // o app mostra a tarja “instale a extensão” só quando este aviso não existe
  const dorme = (ms) => new Promise((ok) => setTimeout(ok, ms));
  const visivel = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const texto = (e) => (e.textContent || "").replace(/\s+/g, " ").trim();

  async function esperar(fn, ms, passo = 250) {
    const t0 = Date.now();
    for (;;) { const v = fn(); if (v) return v; if (Date.now() - t0 > ms) return null; await dorme(passo); }
  }
  const abaBase = () => document.getElementById("tour-teses-base-conhecimento-tab") || [...document.querySelectorAll("button")].find((b) => /^Base de Conhecimento$/i.test(texto(b)));
  const cartoes = () => [...document.querySelectorAll("p[title]")].filter((p) => p.closest("div.border") && p.parentElement.querySelector("div,span") && /\.pdf$/i.test(p.getAttribute("title") || ""));
  const cartaoDe = (nome) => cartoes().find((p) => p.getAttribute("title") === nome);
  const raizBase = () => { const s = [...document.querySelectorAll("span")].find((x) => /Base de Conhecimento do Gabinete/i.test(texto(x))); return s && (s.closest(".bg-slate-50") || s.closest("div.relative") || s.parentElement.parentElement); };

  async function abrirBase() {
    if (!abaBase() || !visivel(abaBase())) {      // abre o "Caderno de Teses & Modelos" pelo menu lateral ou pelo rodapé
      const abre = [...document.querySelectorAll("button")].find((b) => /^Teses\s*&\s*Modelos/i.test(b.getAttribute("title") || "") || /^Teses do Gabinete$/i.test(texto(b)));
      if (!abre) throw new Error("não achei o botão “Teses & Modelos” do app");
      abre.click();
    }
    const aba = await esperar(() => abaBase(), 15000);
    if (!aba) throw new Error("a janela do Caderno de Teses não abriu");
    if (!raizBase()) { aba.click(); }
    if (!(await esperar(() => raizBase(), 15000))) throw new Error("a aba “Base de Conhecimento” não abriu");
  }

  async function apagar(nome) {
    const p = cartaoDe(nome);
    if (!p) return false;
    const card = p.closest("div.border");
    const lixo = [...card.querySelectorAll("button")].find((b) => /excluir/i.test(b.getAttribute("title") || ""));
    if (!lixo) throw new Error("não achei o botão de excluir do documento antigo");
    document.documentElement.dataset.projudiAutoConfirm = "1";
    try {
      lixo.click();
      await dorme(500);
      // se o app abrir uma caixa própria de confirmação, confirma
      const conf = [...document.querySelectorAll("button")].find((b) => visivel(b) && !card.contains(b) && /^(excluir|confirmar|sim|remover|apagar)(\b|$)/i.test(texto(b)) && !/Excluir documento/i.test(b.title || ""));
      if (conf) conf.click();
      if (!(await esperar(() => !cartaoDe(nome), 30000))) throw new Error("o documento antigo não foi excluído");
    } finally { delete document.documentElement.dataset.projudiAutoConfirm; }
    return true;
  }

  const arquivos = new Map();      // arquivos recebidos da extensão (em partes), por id
  const partes = new Map();

  async function enviar(nome, arquivoId, b64, substituir = false) {
    await abrirBase();
    if (!substituir && cartaoDe(nome)) return { ok: false, existe: true, erro: `Já existe “${nome}” na base de conhecimento do app. O app não permite editar: exclua o documento antigo (lixeira) e envie de novo.` };
    let bytes = arquivoId ? arquivos.get(arquivoId) : null;
    if (!bytes && b64) { const bin = atob(b64); bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i); }
    if (!bytes) throw new Error("arquivo não recebido");
    const existia = await apagar(nome);
    const raiz = raizBase();
    const entradas = [...document.querySelectorAll("input[type=file]")];
    const input = entradas.find((i) => raiz && raiz.contains(i)) || entradas[entradas.length - 1];
    if (!input) throw new Error("não achei o campo de envio de PDF");
    const dt = new DataTransfer();
    dt.items.add(new File([bytes], nome, { type: "application/pdf" }));
    input.files = dt.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
    const p = await esperar(() => cartaoDe(nome), 5 * 60000, 500);       // o app lê todas as páginas: pode demorar
    if (!p) throw new Error("o app não mostrou o documento depois do envio");
    return { ok: true, substituiu: existia, quantos: cartoes().filter((x) => x.getAttribute("title") === nome).length, info: texto(p.parentElement) };
  }

  // ---------- análise de um processo ----------
  const normal = (t) => String(t || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\s+/g, " ").trim().toLowerCase().replace(/\boutr[oa]s?\b/g, "outros");      // “Outros/Outras”: a tradução automática do Chrome troca uma pela outra
  const botao = (rx, raiz = document) => [...raiz.querySelectorAll("button")].find((b) => rx.test(texto(b)) && visivel(b));
  // Botão da auditoria da Lupa: pelo id do app (estável) e, na falta dele, pelo texto — tolerante à tradução do Chrome (“Auditar” vira “Auditor”)
  const botaoAuditar = (modal) => modal.querySelector("#btn-lupa-auditar-minuta") || botao(/Audit(ar|or)\s+Minuta|Minuta com Rigor/i, modal);
  function definirValor(el, valor) {   // campos controlados pelo React: usa o "setter" nativo e avisa a página
    const proto = el.tagName === "SELECT" ? HTMLSelectElement.prototype : el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, valor);
    el.dispatchEvent(new Event(el.tagName === "SELECT" ? "change" : "input", { bubbles: true }));
    if (el.tagName !== "SELECT") el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  const traduzida = () => /translated-(ltr|rtl)/.test(document.documentElement.className);
  const dicaTraducao = () => traduzida() ? " — o Chrome está TRADUZINDO esta página do Studio e isso muda os nomes e botões; desative a tradução (ícone de tradução na barra de endereço → “Nunca traduzir este site”) e tente de novo" : "";
  const pnormal = (t) => normal(t).replace(/\bcivil\b/g, "civel");      // “Civil” (grafia antiga das sugestões) = “Cível” do app
  function escolherPrompt(sel, prompt) {
    if (!prompt) return true;
    const op = [...sel.options].find((o) => pnormal(o.text) === pnormal(prompt)) || [...sel.options].find((o) => pnormal(o.text).includes(pnormal(prompt)));
    if (!op) {      // o juiz não tem o prompt exato: usa o parecido da mesma matéria (ex.: Execução Fiscal Estadual → Municipal)
      const p = globalThis.PromptSimilar?.melhor([...sel.options].filter((o) => o.value && /Área Judicial|Area Judicial/i.test(o.text)).map((o) => ({ texto: o.text, ref: o })), prompt, window.__dicasPrompt);
      if (!p) return false;
      definirValor(sel, p.ref.value); window.__promptAproximado = `prompt “${prompt}” não cadastrado: usado o parecido “${p.texto.trim()}”`;
      return true;
    }
    definirValor(sel, op.value);
    return true;
  }
  const seletorDePrompt = (raiz, prompt) => [...raiz.querySelectorAll("select")].find((s) => [...s.options].some((o) => /Área Judicial|Area Judicial/i.test(o.text)) && (!prompt || [...s.options].some((o) => pnormal(o.text).includes(pnormal(prompt))) || !!globalThis.PromptSimilar?.melhor([...s.options].filter((o) => /Área Judicial|Area Judicial/i.test(o.text)).map((o) => ({ texto: o.text, ref: o })), prompt, window.__dicasPrompt)));
  // Sem o prompt (nem parecido da mesma matéria): o erro leva a lista de prompts do Studio para a esteira deixar o usuário escolher.
  const opcoesDePrompt = (raiz) => [...new Set([...(raiz || document).querySelectorAll("select"), ...document.querySelectorAll("select")].flatMap((s) => [...s.options].map((o) => o.text.trim()).filter((t) => /Área Judicial|Area Judicial/i.test(t))))];
  const erroSemPrompt = (prompt, raiz, onde) => { const e = new Error(`não achei o prompt “${prompt}” ${onde}, nem outro da mesma matéria${dicaTraducao()} — escolha abaixo um prompt da lista do seu Studio`); e.opcoes = opcoesDePrompt(raiz); return e; };
  const erroNaTela = () => {
    const t = document.querySelector("[data-rht-toaster]"); const x = t ? texto(t) : "";
    if (/erro|falha|inv[aá]lid|limite|quota|n[aã]o foi poss/i.test(x)) return x;
    // faixa vermelha do app (“…Por favor, clique em ‘Tentar Novamente’”): não é um aviso rápido, fica fixa no topo da tela
    const bt = botao(/^Tentar Novamente$/i);
    if (bt) { let el = bt.parentElement; for (let i = 0; i < 4 && el && texto(el).length < 60; i++) el = el.parentElement; const y = el ? texto(el) : ""; if (y.length > 20) return y.slice(0, 400); }
    return "";
  };
  // Falha passageira dos servidores de IA (alta demanda, 503, tempo de fila): espera 5 s e aperta o botão de novo (até 6 vezes).
  const transitorio = (msg) => !/processamento turbo demorou/i.test(msg || "") && /alta demanda|503|timeout de fila|reten[cç][aã]o em fila|tente novamente|tentar novamente|sobrecarg|indispon[ií]vel|interrompida momentaneamente|conex[aã]o com a intelig[eê]ncia/i.test(msg || "");
  function repetirSePassageiro(estado, e, apertar) {
    if (!transitorio(e) || estado.vezes >= 6) return false;
    if (Date.now() < estado.ate) return true;       // o mesmo aviso ainda está na tela
    estado.vezes++; estado.ate = Date.now() + 12000;
    setTimeout(() => { try { (botao(/^Tentar Novamente$/i) || null)?.click(); apertar(); } catch (x) { /* tela mudou */ } }, 5000);
    return true;
  }
  function fecharJanelas() {
    for (let i = 0; i < 3; i++) {
      const f = botao(/^Fechar$/i) || [...document.querySelectorAll("button[title=Fechar]")].find(visivel);
      if (!f) break; f.click();
    }
  }
  const painelResultado = () => [...document.querySelectorAll("h3")].find((h) => /Resultado\s*&\s*An[aá]lise/i.test(texto(h)));
  const resultadoPronto = () => {
    const h = painelResultado(); if (!h) return false;
    if (document.getElementById("tour-result-tabs") && document.querySelector("div.font-serif")) return true;      // abas e texto da minuta já na tela
    const barra = h.parentElement.parentElement.lastElementChild;     // botões Editar / Copiar / Gerar PDF: ficam bloqueados enquanto não há resultado
    return !(barra && /pointer-events-none/.test(barra.className)) && !/Aguardando Execu/i.test(texto(h.closest("div.border") || document.body));
  };
  const executando = () => { const b = document.getElementById("tour-execute-btn"); return !b || b.disabled || !/Gerar (Minuta|1ª Etapa)/i.test(texto(b)); };
  // A esteira usa “Execução em 2 Etapas” (1ª etapa: assessor fático; 2ª: juiz revisor): garante a opção MARCADA durante a análise, aperta
  // “Prosseguir para 2ª Etapa” e, no fim, devolve a caixa ao que o usuário tinha.
  const caixaDuasEtapas = () => [...document.querySelectorAll("label")].find((l) => /Execu[cç][aã]o em 2 Etapas/i.test(texto(l)) && visivel(l))?.querySelector("input[type=checkbox]");
  const prosseguirEtapa2 = () => botao(/Prosseguir para (a )?2ª Etapa/i);

  // Resumo dos processos gigantes que o app está lendo em lotes (o app o publica no atributo data-gigantes da página)
  // O app monta o mapa do processo em segundo plano (leva minutos e não é demora da análise): esse tempo não conta nos limites de espera (no máximo 40 min).
  const mapasAtivos = () => { try { return JSON.parse(document.documentElement.dataset.mapas || "[]").some((m) => ["planejando", "lendo", "consolidando"].includes(m.status)); } catch { return false; } };
  const novoRelogio = () => { const t0 = Date.now(); let parado = 0, ult = t0; return () => { const n = Date.now(); if (mapasAtivos() && parado < 40 * 60000) parado += n - ult; ult = n; return n - t0 - parado; }; };
  const listaGigantes = () => { try { return JSON.parse(document.documentElement.dataset.gigantes || "[]"); } catch { return []; } };
  async function analisar({ arquivoId, nome, prompt, tipo, texto: textoAutos, ate1, processo }) {
    const inicioAnalise = Date.now();
    const bytes = arquivos.get(arquivoId);
    if (!bytes && !textoAutos) throw new Error("arquivo não recebido");
    fecharJanelas();
    botao(/^Nova An[aá]lise$/i)?.click(); await dorme(600);
    let painel = await esperar(() => document.getElementById("tour-input-panel"), 8000);
    // Sem a área de entrada o app está em outra tela (minuta em tela cheia, janela aberta, erro na tela): tenta voltar ao painel “Autos & Prompts” antes de desistir
    for (let t = 0; !painel && t < 3; t++) {
      fecharJanelas(); try { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); } catch (e) { /* sem teclado */ }
      (botao(/^\s*Autos\s*&\s*Prompts\s*$/i) || botao(/^\s*Dividir Tela\s*$/i) || botao(/^Nova An[aá]lise$/i))?.click();
      painel = await esperar(() => document.getElementById("tour-input-panel"), 6000);
    }
    if (!painel) throw new Error("não achei a área de entrada dos autos do app (botões na tela: " + [...document.querySelectorAll("button")].filter(visivel).map((x) => texto(x).slice(0, 26)).filter(Boolean).slice(0, 12).join(" | ") + ")");
    const sel = prompt ? await esperar(() => seletorDePrompt(document, prompt), 30000) : seletorDePrompt(document, prompt);      // a lista de prompts do app carrega depois da página
    if (prompt && (!sel || !escolherPrompt(sel, prompt))) throw erroSemPrompt(prompt, document, "na lista do app");
    await dorme(400);
    if (tipo && !/auto/i.test(tipo)) { const bt = botao(new RegExp("^" + tipo + "$", "i"), painel); if (bt) bt.click(); }
    else { const ba = botao(/Auto-?Detectar/i, painel); if (ba) ba.click(); }
    if (textoAutos) {      // entrada “Texto / Casos”: cola o texto do PDF com OCR (bem mais rápido que enviar o PDF)
      const bt = [...painel.querySelectorAll("button")].find((b) => /^Texto/i.test(texto(b)) && visivel(b)); if (bt) bt.click();
      const ta = await esperar(() => [...painel.querySelectorAll("textarea")].find(visivel), 10000);
      if (!ta) throw new Error("não achei o campo de texto da entrada “Texto / Casos” do app");
      definirValor(ta, textoAutos); await dorme(500);
      if (ta.value.length < textoAutos.length * 0.98) throw new Error("o campo de texto do app não aceitou o texto completo");
    } else {
      const bpdf = [...painel.querySelectorAll("button")].find((b) => /^PDF$/.test(texto(b))); if (bpdf) bpdf.click();
      await dorme(300);
      const input = painel.querySelector("input[type=file]");
      if (!input) throw new Error("não achei o campo de envio do PDF do processo");
      const dt = new DataTransfer(); dt.items.add(new File([bytes], nome, { type: "application/pdf" }));
      input.files = dt.files; input.dispatchEvent(new Event("change", { bubbles: true }));
      // o app tem de mostrar o PDF recebido; sem isso ele geraria uma minuta genérica (partes/número em branco) só com o prompt
      let recebido = await esperar(() => texto(painel).includes(nome.slice(0, 18)), 20000);
      if (!recebido) { const dt2 = new DataTransfer(); dt2.items.add(new File([bytes], nome, { type: "application/pdf" })); input.files = dt2.files; input.dispatchEvent(new Event("change", { bubbles: true })); recebido = await esperar(() => texto(painel).includes(nome.slice(0, 18)), 20000); }
      if (!recebido) throw new Error(`o app do Studio não recebeu o PDF ${nome} (ele não aparece na área de entrada); a minuta não foi gerada para não sair com dados genéricos — tente de novo`);
    }
    const duas = caixaDuasEtapas(); let desmarcar = false;
    if (duas && !duas.checked) { duas.click(); desmarcar = true; await dorme(400); }      // estava desmarcada: marca para a análise e desmarca depois
    try {
      // o app pode ainda estar ocupado com a análise anterior (botão “Processando…”): espera até 4 min; se o botão continuar desabilitado, reenvia o texto uma vez
      let exec = await esperar(() => { const b = document.getElementById("tour-execute-btn"); return b && !b.disabled ? b : null; }, 90000);
      if (!exec && textoAutos) {
        const ta2 = [...document.querySelectorAll("#tour-input-panel textarea")].find(visivel); if (ta2) { definirValor(ta2, textoAutos + " "); await dorme(300); definirValor(ta2, textoAutos); }
        exec = await esperar(() => { const b = document.getElementById("tour-execute-btn"); return b && !b.disabled ? b : null; }, 150000);
      }
      if (!exec) { const b = document.getElementById("tour-execute-btn"); throw new Error("o botão “Gerar Minuta Judicial” não ficou disponível (estado do botão: " + (b ? `“${texto(b).slice(0, 60)}”, ${b.disabled ? "desabilitado" : "habilitado"}` : "não encontrado") + ")"); }
      const gigantesAntes = new Set(listaGigantes().map((g) => g.id));
      // o resultado do processo anterior pode continuar na tela quando este começa: só vale como pronto o que MUDOU depois do clique
      const assinatura = () => ((document.getElementById("tour-meta-parties-box")?.innerText || "").replace(/\s+/g, " ").slice(0, 300)) + "|" + ((document.querySelector("div.font-serif")?.innerText || "").replace(/\s+/g, " ").slice(0, 400));
      const antes = resultadoPronto() ? assinatura() : "";
      const resultadoNovo = () => resultadoPronto() && (!antes || assinatura() !== antes);
      exec.click();
      const novoGigante = () => listaGigantes().filter((g) => !gigantesAntes.has(g.id)).sort((x, y) => (x.parte || 0) - (y.parte || 0))[0];      // processo em partes: acompanha a Parte 1
      if (!(await esperar(() => executando() || resultadoNovo() || erroNaTela() || novoGigante(), 60000))) throw new Error("a análise não começou");
      const decorrido = novoRelogio(), rep = { vezes: 0, ate: 0 };
      for (;;) {
        const gig = novoGigante();      // processo gigante (acima do limite da análise normal): o app lê em lotes, em segundo plano; a fila segue
        if (gig) return { ok: true, gigante: true, jobId: gig.id, mensagem: "processo gigante: o Studio está lendo em lotes, em segundo plano" };
        const e = erroNaTela();
        if (e && /tamanho|muito grande|grande demais|limite de (?:token|entrada)|processamento turbo demorou/i.test(e)) {
        const err = new Error("O PDF/texto extraído deste processo é grande demais para o Módulo Turbo. Use a “análise normal” para este processo; a fila segue para o próximo.");
        err.semRetry = true; err.grande = true; throw err;
      }
      if (e && repetirSePassageiro(rep, e, () => { const b = document.getElementById("tour-execute-btn"); if (b && !b.disabled && /Gerar (Minuta|1ª Etapa)/i.test(texto(b))) b.click(); })) { await dorme(1000); continue; }
        if (e) throw new Error("o app avisou: " + e);
        const pro = prosseguirEtapa2();      // se a 1ª etapa saiu mesmo assim, segue para a 2ª (minuta completa)
        if (ate1 && pro) {      // esteira automática: SÓ a 1ª etapa. Nunca aperta “Prosseguir para 2ª Etapa”; espera o app ficar ocioso (ou 2 min) e devolve
          if (!rep.pro1) rep.pro1 = Date.now();
          const ocupadoAinda = /Processando/i.test(texto(document.getElementById("tour-execute-btn") || document.body).slice(0, 200));
          if (resultadoNovo() && (!ocupadoAinda || Date.now() - rep.pro1 > 120000)) break;
          await dorme(1000); continue;
        }
      if (pro && !pro.disabled && !rep.etapa2) { rep.etapa2 = pro; pro.click(); await dorme(1500); continue; }
      if (!executando() && resultadoNovo() && !prosseguirEtapa2() && !(rep.etapa2 && rep.etapa2.isConnected)) break;      // com a 2ª etapa em curso o botão fica na tela (“Executando…”) até terminar
        if (decorrido() > 20 * 60000) throw new Error("a análise demorou mais de 20 minutos");
        await dorme(1000);
      }
    } finally {
      if (desmarcar) { const c = caixaDuasEtapas(); if (c && c.checked) c.click(); }
    }
    // confere se a minuta é mesmo DESTE processo: o app, sem ler o PDF, devolve número 0000000-00… e “Parte Autora/Parte Ré” e guardaria tudo como um processo só
    const dig = String(processo || "").replace(/\D/g, ""), caixa = document.getElementById("tour-meta-parties-box");
    if (dig.length >= 7 && caixa && !(caixa.innerText || "").replace(/\D/g, "").includes(dig.slice(0, 7))) throw new Error(`a minuta saiu com dados que não são de ${processo} (o app mostrou “${(caixa.innerText || "").replace(/\s+/g, " ").trim().slice(0, 90)}”): o app mostrou o resultado de outro processo (provavelmente o anterior) e esta análise não foi concluída. NADA foi apagado do Histórico; use “Analisar de novo”.`);
    // o app avisa quando o ato foi (ou não) gravado no Histórico; sem isso a esteira dava o processo por salvo sem estar
    let historico = null;
    if (document.documentElement.dataset.historicoSuporte === "1") {
      historico = await esperar(() => { try { const h = JSON.parse(document.documentElement.dataset.historicoSalvo || "null"); return h && h.t >= inicioAnalise ? h : null; } catch (e) { return null; } }, 90000);
    }
    const avisoHistorico = historico ? (historico.ok ? "" : " ⚠ ATENÇÃO: a minuta NÃO foi gravada no Histórico do app (" + (historico.erro || "erro desconhecido") + "). Ela está na tela; salve/copie antes de limpar.") : (document.documentElement.dataset.historicoSuporte === "1" ? " ⚠ O app não confirmou a gravação no Histórico em 90 s: confira se o processo aparece lá." : "");
    return { ok: true, historicoErro: historico ? (historico.ok ? "" : historico.erro || "erro") : "", mensagem: "análise concluída" + avisoHistorico + (window.__promptAproximado ? " — " + window.__promptAproximado : ""), aproximado: window.__promptAproximado || "", minuta: await lerMinuta(), minutaHtml: minutaHtmlDoPainel(), injecao: lerInjecao() };
  }

  // Tarja de "prompt injection" do app (vermelha: com a movimentação/arquivo/página; verde: nada encontrado). Lida da tela, sem mexer nela.
  function lerInjecao(escopo) {
    try {
      const raiz = escopo || document;
      const v = raiz.querySelector("[data-testid=aviso-prompt-injection]"), g = raiz.querySelector("[data-testid=aviso-prompt-injection-ok]");
      if (v) return { estado: "vermelha", texto: [...v.querySelectorAll("li")].slice(0, 6).map((li) => (li.innerText || "").replace(/\s+/g, " ").trim().slice(0, 260)).join(" | ") };
      if (g) return { estado: "verde", texto: "nada encontrado" };
    } catch (e) { /* sem tarja */ }
    return null;
  }
  // Texto da minuta gerada, lido direto do painel de resultado (só o texto do ato: sem caixas de auditoria/teses).
  // Se a estrutura da tela mudar, usa o botão "Copiar" do app.
  function minutaDoPainel() {
    const raiz = document.querySelector("div.font-serif"); if (!raiz) return "";
    const linhas = [];
    const blocos = [...raiz.children];
    blocos.forEach((bl, i) => {
      if (bl.id === "tour-meta-parties-box") return;
      const md = bl.querySelector(".markdown-body"), h = bl.querySelector(":scope > h3");
      if (md) {
        if (h) linhas.push(texto(h));
        [...md.children].forEach((c) => { for (const l of (c.innerText || c.textContent || "").split(/\n+/)) { const t = l.replace(/\s+/g, " ").trim(); if (t) linhas.push(t); } });
      } else if (i === 0) {
        [...bl.querySelectorAll("p,span")].forEach((e) => { const t = texto(e); if (t && !linhas.includes(t) && e.children.length === 0) linhas.push(t); });
      } else { const t = (bl.innerText || "").replace(/\s+/g, " ").trim(); if (t) linhas.push(t); }
    });
    return linhas.join("\n");
  }
  window.__projudiMinutaDoPainel = minutaDoPainel;      // usado nos testes
  // Mesma minuta, em HTML simples (títulos, parágrafos, citações, negrito e itálico preservados).
  function minutaHtmlDoPainel() {
    const raiz = document.querySelector("div.font-serif"); if (!raiz) return "";
    const esc = (x) => x.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const limpo = (no) => {
      if (no.nodeType === 3) {      // texto com quebras de linha preservadas pelo CSS (white-space: pre-*) vira <br>
        const pre = no.parentElement && /^pre/.test(getComputedStyle(no.parentElement).whiteSpace);
        return pre ? esc(no.nodeValue).replace(/\n/g, "<br>") : esc(no.nodeValue);
      }
      if (no.nodeType !== 1) return "";
      const t = no.tagName.toLowerCase(); let h = [...no.childNodes].map(limpo).join("");
      if (t === "br") return "<br>";
      if (/^(p|blockquote|h[1-6]|li|ul|ol)$/.test(t)) return `<${t}>${h}</${t}>`;
      const c = no.classList;
      if (/^(b|strong)$/.test(t) || c.contains("font-bold") || c.contains("font-semibold")) h = `<b>${h}</b>`;
      if (/^(i|em)$/.test(t) || c.contains("italic")) h = `<i>${h}</i>`;
      return h;
    };
    const saida = [];
    [...raiz.children].forEach((bl, i) => {
      if (bl.id === "tour-meta-parties-box") return;
      const md = bl.querySelector(".markdown-body"), h = bl.querySelector(":scope > h3");
      if (md) { if (h) saida.push(`<h3>${esc(texto(h))}</h3>`); saida.push([...md.childNodes].map(limpo).join("")); }
      else if (i === 0) [...bl.querySelectorAll("p,span")].forEach((e) => { const t = texto(e); if (t && e.children.length === 0 && !saida.includes(`<h3>${esc(t)}</h3>`)) saida.push(`<h3>${esc(t)}</h3>`); });
      else { const t = (bl.innerText || "").replace(/\s+/g, " ").trim(); if (t) saida.push(`<p>${esc(t)}</p>`); }
    });
    return saida.join("");
  }
  window.__projudiMinutaHtml = minutaHtmlDoPainel;      // usado nos testes
  async function lerMinuta() {
    try {
      const doPainel = minutaDoPainel();
      if (doPainel.length > 200) return doPainel;
      const h = painelResultado(), barra = h?.closest("div.border")?.querySelector("#tour-result-actions") || h?.parentElement.parentElement.lastElementChild;
      const copiar = barra && [...barra.querySelectorAll("button")].find((b) => /Copiar/i.test(texto(b) + " " + (b.title || "")));
      document.documentElement.dataset.projudiCopiado = "";
      if (copiar) { copiar.click(); await esperar(() => document.documentElement.dataset.projudiCopiado, 3000); }
      const t = document.documentElement.dataset.projudiCopiado;
      if (t && t.trim().length > 20) return t;
      return doPainel;
    } catch (e) { return ""; }
  }

  // Abre "Histórico Local", procura o número do processo e carrega a minuta dele na tela do app.
  // `desde` (ms): só vale minuta gravada DEPOIS disso (a da esteira). Um processo costuma ter várias minutas em datas diferentes (a evolução do processo):
  // escolhe sempre a mais recente e confere a data; nunca usa a que por acaso já estava aberta na tela.
  const dataDoCartao = (t) => { const m = String(t).match(/(\d{2})\/(\d{2})\/(\d{4})[ ,]+(\d{2}):(\d{2})/); return m ? new Date(+m[3], +m[2] - 1, +m[1], +m[4], +m[5]).getTime() : 0; };
  async function carregarDoHistorico(processo, desde = 0) {
    const meta = () => (document.getElementById("tour-meta-parties-box")?.innerText || "");
    fecharJanelas();
    const abrir = [...document.querySelectorAll("button")].find((b) => /^Histórico Local$/i.test((b.title || "").trim()) || /^Histórico Local$/i.test(texto(b)));
    if (!abrir) throw new Error("não achei o botão “Histórico Local” do app");
    abrir.click();
    const caixa = await esperar(() => [...document.querySelectorAll("input")].find((i) => visivel(i) && /Buscar processo/i.test(i.placeholder || "")), 15000);
    if (!caixa) throw new Error("a janela do Histórico não abriu");
    definirValor(caixa, processo);
    await esperar(() => false, 1500);      // deixa a lista filtrar
    const cartoes = () => [...document.querySelectorAll("div")].filter((d) => d.innerText && d.innerText.includes(processo) && d.innerText.length < 3000 && [...d.querySelectorAll("button")].some((b) => /Carregar Minuta/i.test(texto(b)))).filter((d, i, todos) => !todos.some((o) => o !== d && d.contains(o)));      // só o cartão mais interno de cada processo
    const lista = await esperar(() => { const c = cartoes(); return c.length ? c : null; }, 15000);
    if (!lista) throw new Error(`não achei o processo ${processo} no Histórico do app (ou ele ainda não tem minuta lá)`);
    const ordenados = lista.map((d) => ({ d, t: dataDoCartao(d.innerText) })).sort((x, y) => y.t - x.t);
    const melhor = ordenados[0], quando = melhor.t ? new Date(melhor.t).toLocaleString("pt-BR") : "data não lida";
    if (desde && melhor.t && melhor.t < desde) throw new Error(`só achei minutas ANTIGAS de ${processo} no Histórico (a mais recente é de ${quando}), anteriores a este pedido da esteira; nada foi usado`);
    const carregar = [...melhor.d.querySelectorAll("button")].find((b) => /Carregar Minuta/i.test(texto(b)));
    carregar.click();
    if (!(await esperar(() => meta().includes(processo) && minutaDoPainel().length > 200, 30000))) throw new Error("a minuta do histórico não carregou na tela");
    window.__minutaCarregadaEm = quando;
    return true;
  }

  // Foto passiva do que o app guardou no navegador (chaves agaia_judge_audits_*): só leitura, sem mexer na tela.
  function fotoAuditorias() {
    const r = {};
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!/judge_audits|auditor|audit/i.test(k)) continue;
        const v = localStorage.getItem(k) || "";
        r[k.replace(/^agaia_judge_audits_/, "")] = [...new Set(v.match(/\d{7}[.\-]\d{2}/g) || [])];
      }
    } catch (e) { /* sem acesso */ }
    return r;
  }
  // Guardião: guarda cópia das auditorias já gravadas e, se o app as perder, devolve ao navegador antes da próxima auditoria.
  function guardarAuditorias() {
    try {
      window.__lupaBackup = window.__lupaBackup || {};
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!/^agaia_judge_audits_/.test(k)) continue;
        const arr = JSON.parse(localStorage.getItem(k) || "[]");
        if (!Array.isArray(arr)) continue;
        const m = new Map((window.__lupaBackup[k] || []).map((a) => [a.id, a]));
        for (const a of arr) if (a && a.id) m.set(a.id, a);
        window.__lupaBackup[k] = [...m.values()];
      }
    } catch (e) { /* sem acesso */ }
  }
  function restaurarAuditorias() {
    let n = 0;
    try {
      for (const [k, lista] of Object.entries(window.__lupaBackup || {})) {
        const atual = JSON.parse(localStorage.getItem(k) || "[]"), ids = new Set((Array.isArray(atual) ? atual : []).map((a) => a.id));
        const faltam = lista.filter((a) => a && !ids.has(a.id));
        if (!faltam.length) continue;
        localStorage.setItem(k, JSON.stringify([...(Array.isArray(atual) ? atual : []), ...faltam].sort((a, b) => (b.date || 0) - (a.date || 0))));
        n += faltam.length;
      }
    } catch (e) { /* cheio ou sem acesso */ }
    return n;
  }
  const fotoTxt = (f) => Object.entries(f).map(([k, v]) => `${k}=[${v.join(",")}]`).join(" ; ") || "(nada no navegador)";
  const temNaFoto = (f, rx) => Object.values(f).some((v) => v.some((n) => rx.test(n)));

  async function lupa({ arquivoId, nome, prompt, processo, minuta, motivoMinuta, texto: textoAutosOrig }) {
    if (!minuta || !minuta.trim()) return { ok: true, parcial: true, mensagem: "a Lupa precisa da minuta elaborada pelo assessor: PDF baixado, auditoria não iniciada" + (motivoMinuta ? " — " + motivoMinuta : "") };
    let textoAutos = textoAutosOrig;
    const bytes = arquivos.get(arquivoId);
    if (!bytes && !textoAutos) throw new Error("arquivo não recebido");
    // O Studio grava a auditoria inteira (com os autos) na nuvem, que rejeita documento acima de 1 MiB — e o registro some.
    // Autos muito longos: mantém início e fim (o servidor do Studio já resume autos acima de ~90 mil caracteres).
    if (textoAutos && textoAutos.length > 300000) textoAutos = textoAutos.slice(0, 150000) + "\n\n[... trecho intermediário omitido por tamanho ...]\n\n" + textoAutos.slice(-150000);
    restaurarAuditorias();      // devolve ao navegador o que o app tenha perdido de auditorias anteriores
    fecharJanelas();
    (document.getElementById("btn-sidebar-minute-auditor") || botao(/Auditoria Ouro/i))?.click();
    const achaModal = () => [...document.querySelectorAll("h2")].find((h) => /Lupa do Magistrado/i.test(texto(h)))?.closest("div.fixed");
    let modal = await esperar(achaModal, 20000);
    if (!modal) throw new Error("a janela da Lupa do Magistrado não abriu");
    // Leva a janela ao formulário de nova auditoria: depois de uma auditoria ela reabre na tela de resultado (“Bancada”/“Resultado & Análise”).
    // Insiste nos botões que levam ao formulário até aparecer o botão “Auditar Minuta”.
    const noForm = () => (botaoAuditar(modal) || botao(/^Colar Texto$/i, modal)) && [...modal.querySelectorAll("textarea")].filter(visivel).length >= 1;
    const caminhos = [/^\s*Nova Auditoria\s*$/i, /Iniciar Nova Auditoria/i, /Nova Auditoria/i];
    document.documentElement.dataset.projudiAutoConfirm = "1";
    try {
      for (let volta = 0; volta < 3 && !noForm(); volta++) {
        for (const rx of caminhos) { if (noForm()) break; const bt = botao(rx, modal); if (bt) { bt.click(); await esperar(noForm, 2500); } }
      }
      if (!noForm()) throw new Error("não consegui abrir o formulário de nova auditoria da Lupa (botões vistos: " + [...modal.querySelectorAll("button")].filter(visivel).map((x) => texto(x).slice(0, 28)).filter(Boolean).slice(0, 14).join(" | ") + ")");
      await dorme(400);
      // O formulário guarda a auditoria anterior; sem limpar, a nova sobrescreve a anterior. Usa só “Limpar Formulário”.
      botao(/Limpar Formul[aá]rio/i, modal)?.click(); await dorme(600);
      if (!noForm()) { botao(/^\s*Nova Auditoria\s*$/i, modal)?.click(); await esperar(noForm, 4000); }
    } finally { delete document.documentElement.dataset.projudiAutoConfirm; }
    for (const ta of modal.querySelectorAll("textarea")) if (ta.value) definirValor(ta, "");
    // Quantos registros havia (e se este processo já estava) antes da auditoria: serve para detectar sobrescrita.
    const digA = String(processo || "").replace(/\D/g, "").slice(0, 9);
    const rxA = digA ? new RegExp(digA.slice(0, 7) + "[.\\-]?" + digA.slice(7, 9)) : null;
    let antes = null, jaTinha = false, avisoPerda = "";
    try {
      botao(/^\s*Processos Auditados/i, modal)?.click(); await dorme(1200);
      const lerQtd = () => { const l = (modal.innerText || "").replace(/\s+/g, " "); return { l, n: (l.match(/Processos Auditados\s*(\d+)/i) || [])[1] }; };
      let { l, n } = lerQtd();
      if (n != null) antes = Number(n);
      // A contagem pode cair por motivos que não são “Limpar Tudo” (lista ainda carregando da nuvem, navegador sem espaço que encurta o que guarda). Reconta algumas vezes antes de concluir que algo sumiu.
      for (let v = 0; v < 3 && antes != null && window.__lupaQtd && antes < window.__lupaQtd && !(window.__lupaRx && temNaFoto(fotoAuditorias(), window.__lupaRx)); v++) {
        await dorme(4000); ({ l, n } = lerQtd()); if (n != null) antes = Number(n);
      }
      if (antes != null && window.__lupaQtd && antes < window.__lupaQtd && !(window.__lupaRx && temNaFoto(fotoAuditorias(), window.__lupaRx))) {
        // não trava a fila: o processo anterior já foi confirmado na hora em que foi auditado; segue com a nova contagem como referência e avisa
        avisoPerda = `atenção: a lista de Processos Auditados tinha ${window.__lupaQtd} registro(s) e agora tem ${antes} (o app pode ter encurtado o que guarda no navegador ou alguém limpou); a contagem de referência foi ajustada`;
        window.__lupaQtd = antes;
      }
      jaTinha = !!(rxA && rxA.test(l));
      botao(/^\s*Nova Auditoria\s*$/i, modal)?.click(); await esperar(noForm, 4000);
    } catch (e) { /* segue sem a contagem */ }
    for (const i of modal.querySelectorAll("input[type=text]")) if (i.value && !/^\s*$/.test(i.value)) definirValor(i, "");
    await dorme(300);
    const sel = seletorDePrompt(modal, prompt);
    if (prompt && (!sel || !escolherPrompt(sel, prompt))) throw erroSemPrompt(prompt, modal, "na Lupa");
    const num = [...modal.querySelectorAll("input[type=text]")].find((i) => /5012345/.test(i.placeholder || ""));
    if (num && processo) definirValor(num, processo);
    const tas = () => [...modal.querySelectorAll("textarea")].filter(visivel);
    definirValor(tas()[0], minuta);      // 1. Minuta elaborada pelo assessor
    if (textoAutos) {      // 2. Autos: aba “Colar Texto”
      botao(/^Colar Texto$/i, modal)?.click();
      const ta = await esperar(() => tas()[1], 10000);
      if (!ta) throw new Error("não achei o campo de texto dos autos na Lupa");
      definirValor(ta, textoAutos); await dorme(500);
      if (ta.value.length < textoAutos.length * 0.98) throw new Error("o campo de texto da Lupa não aceitou o texto completo");
    } else {      // 2. Autos: aba “Upload PDF”
      botao(/^Upload PDF$/i, modal)?.click(); await dorme(400);
      const input = [...modal.querySelectorAll("input[type=file]")][0];
      if (!input) throw new Error("não achei o campo de envio do PDF na Lupa");
      const dt = new DataTransfer(); dt.items.add(new File([bytes], nome, { type: "application/pdf" }));
      input.files = dt.files; input.dispatchEvent(new Event("change", { bubbles: true }));
      await dorme(1000);
    }
    const b = await esperar(() => { const x = botaoAuditar(modal); return x && !x.disabled ? x : null; }, 15000);
    if (!b) throw new Error("não achei o botão “Auditar Minuta”" + dicaTraducao());
    const rotulo = texto(b); const foto0 = fotoAuditorias(); b.click();
    // Espera a auditoria terminar. Sinais: o botão volta ao normal OU a janela deixa de mudar (texto estável por ~12 s, sem “auditando/aguarde”).
    const t0 = Date.now(), texto_ = () => (modal.innerText || "").replace(/\s+/g, " ").trim();
    let ultimo = texto_(), desde = Date.now(), comecou = false, ultimaConf = 0, achouCedo = null;
    const dig0 = String(processo || "").replace(/\D/g, "").slice(0, 9);
    const rxProc0 = dig0 ? new RegExp(dig0.slice(0, 7) + "[.\\-]?" + dig0.slice(7, 9)) : null;
    for (;;) {
      await dorme(1500);
      const e = erroNaTela(); if (e) throw new Error("o app avisou: " + e);
      const x = botaoAuditar(modal), agora = texto_();
      if (!x || x.disabled || texto(x) !== rotulo) comecou = true;
      if (agora !== ultimo) { ultimo = agora; desde = Date.now(); }
      const ocupado = /auditando|analisando|processando|aguarde|carregando|gerando/i.test(agora.slice(0, 4000));
      const voltou = comecou && x && !x.disabled && texto(x) === rotulo;
      // O registro aparece em “Processos Auditados” logo que a auditoria termina e some se a janela for para “Resultado & Análise”:
      // por isso confere na lista assim que a tela se acalma, antes de qualquer outra aba.
      if (rxProc0 && comecou && !ocupado && Date.now() - desde > 2000 && Date.now() - ultimaConf > 3000) {
        ultimaConf = Date.now();
        botao(/^\s*Processos Auditados/i, modal)?.click(); await dorme(1200);
        const l0 = texto_();
        if (rxProc0.test(l0)) { achouCedo = { qtd: (l0.match(/Processos Auditados\s*(\d+)/i) || [])[1] }; botao(/^\s*Nova Auditoria\s*$/i, modal)?.click(); await dorme(500); break; }
      }
      if (voltou || (comecou && !ocupado && Date.now() - desde > 12000) || (!comecou && Date.now() - t0 > 20000)) break;
      if (Date.now() - t0 > 8 * 60000) throw new Error("a auditoria da Lupa demorou mais de 8 minutos");
    }
    const injecaoLupa = lerInjecao(modal);      // a tarja fica no topo do resultado; lida antes de a janela mudar de tela
    const resumo = texto_().replace(/Auditar Minuta com Rigor do Magistrado.*$/i, "").slice(0, 300);
    // Confere em “Processos Auditados” se a auditoria ficou gravada. Só segue para o próximo depois de confirmar:
    // consulta a aba por até ~100 s e, se não aparecer, fecha e reabre o módulo e navega de novo pelos botões.
    const dig = String(processo || "").replace(/\D/g, "").slice(0, 9);
    const rxProc = dig ? new RegExp(dig.slice(0, 7) + "[.\\-]?" + dig.slice(7, 9)) : null;
    const consulta = async () => {
      botao(/^\s*Processos Auditados/i, modal)?.click();
      await dorme(2500);
      const lista = texto_(), qtd = (lista.match(/Processos Auditados\s*(\d+)/i) || [])[1];
      const ok = !rxProc || rxProc.test(lista);
      if (ok) { botao(/^\s*Nova Auditoria\s*$/i, modal)?.click(); await dorme(500); }      // achou: sai da lista sem passar por “Resultado & Análise”
      return { ok, qtd };
    };
    const reabrir = async () => {      // fecha e reabre o módulo
      (botao(/^\s*Fechar\s*$/i, modal) || modal.querySelector("button[aria-label*=echar]"))?.click();
      await dorme(1200); if (achaModal()) fecharJanelas();
      await dorme(800);
      (document.getElementById("btn-sidebar-minute-auditor") || botao(/Auditoria Ouro/i))?.click();
      modal = await esperar(achaModal, 20000);
      if (!modal) throw new Error("a Lupa não reabriu para conferir Processos Auditados");
      await dorme(1500);
    };
    let conf = achouCedo ? { ok: true, qtd: achouCedo.qtd } : { ok: false, qtd: undefined };
    for (let tent = 0; tent < 3 && !conf.ok; tent++) {
      if (tent > 0) await reabrir();
      for (let i = 0; i < 6 && !conf.ok; i++) {
        conf = await consulta();
        if (!conf.ok) { if (i % 2) { botao(/^\s*Nova Auditoria\s*$/i, modal)?.click(); await dorme(1000); } await dorme(i < 2 ? 3000 : 5000); }
      }
    }
    let qtd = conf.qtd;
    if (!conf.ok) throw new Error(`a auditoria terminou, mas ${processo} não aparece em “Processos Auditados” mesmo após aguardar e reabrir o módulo (a lista tem ${qtd ?? "?"} registro(s)). Não passei para o próximo`);
    const foto1 = fotoAuditorias(); guardarAuditorias();
    // Confirmado: não navega mais. Só vai a Nova Auditoria e usa “Limpar Tudo (Novo Cadastro)” para o próximo processo.
    try {
      document.documentElement.dataset.projudiAutoConfirm = "1";
      botao(/^\s*Nova Auditoria\s*$/i, modal)?.click(); await esperar(() => botao(/Limpar Tudo|Novo Cadastro/i, modal), 5000);
      botao(/Limpar Tudo|Novo Cadastro/i, modal)?.click(); await dorme(800);
    } catch (e) { /* o próximo processo limpa de novo */ } finally { delete document.documentElement.dataset.projudiAutoConfirm; }
    await dorme(1500);
    const foto2 = fotoAuditorias(), trilha = `navegador: antes=${fotoTxt(foto0)} | após auditar=${fotoTxt(foto1)} | após Limpar Tudo=${fotoTxt(foto2)}`;
    if (rxProc && temNaFoto(foto1, rxProc) && !temNaFoto(foto2, rxProc)) throw new Error(`o botão “Limpar Tudo” apagou ${processo} dos Processos Auditados. Parei para não perder mais registros. ${trilha}`);
    if (antes != null && !jaTinha && qtd != null && Number(qtd) <= antes) throw new Error(`a auditoria de ${processo} substituiu outra em vez de entrar na lista (eram ${antes}, ficaram ${qtd}). Não passei para o próximo`);
    window.__lupaQtd = Number(qtd) || window.__lupaQtd; window.__lupaRx = rxProc;
    return { ok: true, mensagem: `auditoria gravada em Processos Auditados (${qtd ?? "?"} registro(s); ${processo} ✔) — ${trilha}` + (window.__promptAproximado ? " — " + window.__promptAproximado : "") + (resumo ? " — " + resumo : "") + (avisoPerda ? " — " + avisoPerda : ""), minuta: "", injecao: injecaoLupa };
  }


  // Resultado do Módulo Turbo: o módulo troca o formulário por “DECISÃO/SENTENÇA/DESPACHO” + botões Copiar/Baixar/Abrir no Editor/Nova Análise + abas “Minuta Completa”.
  const moduloTurbo = () => [...document.querySelectorAll("h2")].filter((h) => /M[oó]dulo Turbo Independente/i.test(texto(h)) && visivel(h)).map((h) => h.closest("div.fixed"))[0] || null;
  const resultadoTurbo = () => { const m = moduloTurbo(); return m && botao(/Abrir no Editor/i, m) && [...m.querySelectorAll("button")].some((b) => /^Minuta Completa$/i.test(texto(b))) ? m : null; };
  function lerResultadoTurbo() {
    const m = resultadoTurbo(); if (!m) return { texto: "", html: "" };
    const aba = [...m.querySelectorAll("button")].find((b) => /^Minuta Completa$/i.test(texto(b)));
    aba?.click();
    const rolagem = [...m.querySelectorAll("div")].filter((d) => /overflow-y-auto|overflow-auto/.test(d.className) && (d.innerText || "").length > 200 && !d.querySelector("h2"))
      .sort((a, b) => (b.innerText || "").length - (a.innerText || "").length)[0];
    let linhas = ((rolagem || m).innerText || "").split(/\n+/).map((l) => l.replace(/\s+/g, " ").trim()).filter(Boolean);
    while (linhas.length && /^(PROCESSO N|POLO (ATIVO|PASSIVO)|COMARCA|JUIZO|JUÍZO)/i.test(linhas[0])) linhas.shift();      // cabeçalho de identificação: não faz parte da minuta
    const esc = (x) => x.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const titulo = (l) => l.length < 90 && (l === l.toUpperCase() && /[A-ZÁÉÍÓÚÂÊÔÃÕÇ]{4}/.test(l));
    return { texto: linhas.join("\n"), html: linhas.map((l) => titulo(l) ? `<h3>${esc(l)}</h3>` : `<p>${esc(l)}</p>`).join("") };
  }
  window.__projudiLerTurbo = lerResultadoTurbo;      // usado nos testes

  // Módulo Turbo Independente: "Prompt Especializado do Gabinete", "Tipo de Ato", "Anexar PDF dos Autos" e "Executar Análise Turbo".
  const botaoExecutarTurbo = (raiz) => [...raiz.querySelectorAll("button")].find((x) => /Executar An[aá]lise Turbo/i.test(texto(x)) || /^(\W*)(Analisando|Executando|Gerando|Processando)/i.test(texto(x)));
  function painelTurbo() {
    const rot = [...document.querySelectorAll("span,label,p")].find((e) => e.children.length === 0 && /Prompt Especializado do Gabinete/i.test(texto(e)) && visivel(e));
    for (let e = rot; e && e !== document.body; e = e.parentElement) if (botaoExecutarTurbo(e)) return e;
    return null;
  }
  async function turbo({ arquivoId, nome, prompt, tipo, texto: textoAutos }) {
    const bytes = arquivos.get(arquivoId);
    if (!bytes && !textoAutos) throw new Error("arquivo não recebido");
    fecharJanelas();
    let raiz = painelTurbo();
    if (!raiz && resultadoTurbo()) { botao(/^Nova An[aá]lise$/i, resultadoTurbo())?.click(); raiz = await esperar(painelTurbo, 10000); }      // resultado antigo na tela
    const abrir = () => {      // o app pode ainda estar carregando (aba aberta agora): tenta de novo até o botão do módulo existir
      const ids = ["btn-header-turbo-top", "btn-header-turbo-top-mobile", "btn-header-turbo-dropdown"].map((i) => document.getElementById(i)).filter(Boolean);
      (ids.find(visivel) || ids[0] || botao(/Turbo/i))?.click();
    };
    for (let t0 = Date.now(); !raiz && Date.now() - t0 < 60000;) { abrir(); raiz = await esperar(painelTurbo, 4000); }
    if (!raiz) throw new Error("não achei o Módulo Turbo no app (abra o módulo uma vez e tente de novo)");
    if (prompt) {      // a lista do Turbo mostra “Prompt • [TAG]”: compara sem a etiqueta e procura primeiro no próprio módulo
      const sem = (t) => normal(t).replace(/\s*•.*$/, ""), alvo = sem(prompt);
      const achar = (s) => [...s.options].find((o) => sem(o.text) === alvo) || [...s.options].find((o) => sem(o.text).includes(alvo)) || [...s.options].find((o) => alvo.includes(sem(o.text)) && sem(o.text).length > 8) || null;
      const parecido = (s) => { const p = globalThis.PromptSimilar?.melhor([...s.options].filter((o) => /Área Judicial|Area Judicial/i.test(o.text)).map((o) => ({ texto: o.text, ref: o })), prompt, window.__dicasPrompt); return p ? p.ref : null; };
      const todosSelects = () => [...raiz.querySelectorAll("select"), ...document.querySelectorAll("select")];
      const dono = await esperar(() => todosSelects().find((s) => achar(s)) || todosSelects().find((s) => parecido(s)), 30000), selects = todosSelects();      // a lista de prompts carrega depois da página
      if (!dono) throw erroSemPrompt(prompt, raiz, "no Módulo Turbo");
      if (achar(dono)) definirValor(dono, achar(dono).value); else { const o = parecido(dono); definirValor(dono, o.value); window.__promptAproximado = `prompt “${prompt}” não cadastrado: usado o parecido “${o.text.trim()}”`; }
    }
    await dorme(300);
    const bt = botao(tipo && !/auto/i.test(tipo) ? new RegExp(tipo, "i") : /Auto-?detectar/i, raiz); if (bt) bt.click();
    if (textoAutos) {       // aba “Digitar / Colar Texto”: cola o texto completo dos autos
      botao(/Digitar\s*\/\s*Colar/i, raiz)?.click();
      const ta = await esperar(() => raiz.querySelector("textarea"), 10000);
      if (!ta) throw new Error("não achei o campo de texto do Módulo Turbo");
      definirValor(ta, textoAutos); await dorme(500);
      if (ta.value.length < textoAutos.length * 0.98) throw new Error("o campo de texto do Turbo não aceitou o texto completo");
    } else {
      botao(/Anexar PDF/i, raiz)?.click(); await dorme(400);
      const input = raiz.querySelector("input[type=file]");
      if (!input) throw new Error("não achei o campo de envio do PDF no Módulo Turbo");
      const dt = new DataTransfer(); dt.items.add(new File([bytes], nome, { type: "application/pdf" }));
      input.files = dt.files; input.dispatchEvent(new Event("change", { bubbles: true }));
      await esperar(() => texto(raiz).includes(nome.slice(0, 18)), 20000);
    }
    const exec = await esperar(() => { const b = botaoExecutarTurbo(raiz); return b && !b.disabled && /Executar/i.test(texto(b)) ? b : null; }, 60000);
    if (!exec) throw new Error("o botão “Executar Análise Turbo” não ficou disponível");
    const gigantesAntes = new Set(listaGigantes().map((g) => g.id));
    const rotulo = texto(exec); exec.click();
    // 1) começou (o botão muda ou some) 2) terminou (aparece o resultado: “Abrir no Editor” + aba “Minuta Completa”)
    const decorrido = novoRelogio(), rep = { vezes: 0, ate: 0 };
    const novoGigante = () => listaGigantes().filter((g) => !gigantesAntes.has(g.id)).sort((x, y) => (x.parte || 0) - (y.parte || 0))[0];      // processo em partes: acompanha a Parte 1
    await esperar(() => { const b = botaoExecutarTurbo(raiz); return erroNaTela() || !b || b.disabled || texto(b) !== rotulo || resultadoTurbo() || novoGigante(); }, 20000);
    for (;;) {
      const gig = novoGigante();      // processo gigante: o app lê em lotes, em segundo plano, e a minuta vai para o Histórico; a fila segue
      if (gig) return { ok: true, gigante: true, jobId: gig.id, mensagem: "processo gigante: o Studio está lendo em lotes, em segundo plano" };
      if (resultadoTurbo()) break;
      const e = erroNaTela();
      if (e && repetirSePassageiro(rep, e, () => { const r2 = painelTurbo(), b = r2 && botaoExecutarTurbo(r2); if (b && !b.disabled && /Executar/i.test(texto(b))) b.click(); })) { await dorme(1000); continue; }
      if (e) throw new Error("o app avisou: " + e);
      if (decorrido() > 16 * 60000) throw new Error("o Módulo Turbo demorou mais de 16 minutos");
      await dorme(1000);
    }
    await dorme(1500);
    const r = lerResultadoTurbo();
    if (r.texto.length < 200) throw new Error("o Módulo Turbo terminou, mas não consegui ler a minuta na tela");
    return { ok: true, mensagem: "análise Turbo concluída", minuta: r.texto, minutaHtml: r.html };
  }


  // ---------- Mesa de Audiência ----------
  const corpoMesa = () => document.body.innerText || "";
  const ERRO_MESA = /(Limite tempor[áa]rio de cota[^\n]*|Todas as \d+ chaves[^\n]*|Falha ao processar comando com IA[^\n]*|Erro 429[^\n]*|Quota Exceeded[^\n]*|Os servidores de intelig[êe]ncia artificial[^\n]*|Erro 503[^\n]*|Por favor, selecione arquivos v[áa]lidos[^\n]*)/i;
  const botaoNova = () => botao(/^\s*\+?\s*Nova\s*$/i);
  const dig = (x) => String(x || "").replace(/\D/g, "");
  async function abrirMesa() {
    fecharJanelas();
    if (botaoNova()) return;
    const abrir = document.getElementById("btn-header-hearing-workbench-tools") || [...document.querySelectorAll("button")].find((b) => /Mesa de Audi[êe]ncias/i.test(b.title || texto(b)));
    if (!abrir) throw new Error("não achei o botão “Mesa de Audiências” no app");
    abrir.click();
    if (!(await esperar(botaoNova, 20000))) throw new Error("a Mesa de Audiências não abriu");
  }
  const resumoDaMesa = () => {      // textarea “Resumo Fático da Lide” da aba Briefing (só ela indica que a análise terminou: o texto bruto dos autos também é uma caixa de texto)
    const h = [...document.querySelectorAll("span,h3,h4,label,div")].find((e) => /^Resumo F[áa]tico da Lide$/i.test(texto(e)) && ![...e.children].some((c) => /Resumo F[áa]tico/i.test(texto(c))));      // o título tem um ícone dentro (não é folha)
    for (let n = h; n; n = n.parentElement) { const ta = n.querySelector && n.querySelector("textarea"); if (ta) return ta.value || ""; }
    return "";
  };
  const erroDaMesa = () => { const m = corpoMesa().match(ERRO_MESA); return m ? m[0].trim().slice(0, 260) : ""; };
  const falhar = (msg) => { const err = new Error("a Mesa de Audiência avisou: " + msg); err.semRetry = true; return err; };
  async function aguardarBriefing(t0) {
    for (;;) {
      const e = erroDaMesa(); if (e) throw falhar(e);
      if (!/Extraindo autos|mapeando partes/i.test(corpoMesa()) && Date.now() - t0 > 5000 && resumoDaMesa().length > 40) return;
      if (Date.now() - t0 > 25000 && !mesaOcupada() && resumoDaMesa().length <= 40) { await dorme(4000); if (!mesaOcupada() && resumoDaMesa().length <= 40) throw falhar("a análise da Mesa terminou sem gerar o briefing (veja o aviso na tela da Mesa)"); }
      if (Date.now() - t0 > 20 * 60000) throw falhar("a análise não terminou em 20 minutos");
      await dorme(1500);
    }
  }

  // Cria uma audiência NOVA na Mesa e entrega o PDF (o app extrai e analisa sozinho). Em nova tentativa (retomar), reanalisa a audiência que ficou aberta, sem duplicar.
  // Com comAta, gera também a ata preliminar (intimações e movimentações) e a fecha.
  async function mesa({ arquivoId, nome, retomar, comAta, audData, audHora, processo }) {
    const bytes = arquivos.get(arquivoId);
    if (!bytes) throw new Error("arquivo não recebido");
    await abrirMesa();
    const rean = botao(/Reanalisar com IA/i);
    let t0 = Date.now(), reaproveita = false;
    // Já existe uma audiência deste processo na Mesa? Se já foi analisada, usa a mesma (sem duplicar nem gastar IA); se está vazia, envia o PDF nela.
    // Sem audiência do processo, reaproveita uma "Processo sem número" vazia (sobra de tentativa anterior) antes de criar outra.
    const cartoes = () => [...document.querySelectorAll("div")].filter((d) => /rounded-xl/.test(d.className) && /cursor-pointer/.test(d.className) && visivel(d));
    const alvoDig = dig(processo).slice(0, 9);
    if (!retomar) {
      const doProc = alvoDig.length >= 7 ? cartoes().find((d) => dig(texto(d)).startsWith(alvoDig)) : null;
      if (doProc) {
        doProc.click(); await dorme(1300);
        if (resumoDaMesa().length > 40) { await definirDataHoraMesa(audData, audHora, true); return { ok: true, mensagem: "a audiência já estava na Mesa e já tinha o briefing: usei a mesma, sem analisar de novo", minuta: "", reaproveitada: true }; }
        reaproveita = true;
      } else {
        const vazio = cartoes().find((d) => /Processo sem n[úu]mero/i.test(texto(d)) && !/\d{7}/.test(texto(d)));
        if (vazio) { vazio.click(); await dorme(1000); if (document.querySelector("input[type=file]")) reaproveita = true; }
      }
    }
    if (retomar && rean && corpoMesa().includes(String(nome).replace(/\.pdf$/i, "").slice(0, 14))) { rean.click(); await dorme(2500); }
    else {
      if (!reaproveita) botaoNova().click();
      await definirDataHoraMesa(audData, audHora);
      const input = await esperar(() => [...document.querySelectorAll("input[type=file]")].find((i) => /pdf/i.test(i.accept || "") && /txt/i.test(i.accept || "")), 15000);
      if (!input) throw new Error("não achei o campo “Selecionar PDF(s) dos Autos” na Mesa");
      const dt = new DataTransfer(); dt.items.add(new File([bytes], nome, { type: "application/pdf" }));
      input.files = dt.files; input.dispatchEvent(new Event("change", { bubbles: true }));
      if (!(await esperar(() => /Extraindo autos|mapeando partes/i.test(corpoMesa()), 30000))) {
        const e = erroDaMesa(); if (e) throw falhar(e);
        if (!mesaOcupada() && resumoDaMesa().length <= 40 && !/Pe[çc]as analisadas/i.test(corpoMesa())) throw falhar("o Studio não começou a ler o PDF (o envio do arquivo para a Mesa não foi aceito). Tente de novo; se repetir, atualize a aba do Studio");
      }
      t0 = Date.now();
    }
    await aguardarBriefing(t0);
    await definirDataHoraMesa(audData, audHora, true);      // confere se o app não voltou a data/hora padrão durante a análise
    let avisoAta = "";
    if (comAta) { try { await gerarAta(); } catch (e) { avisoAta = String(e.message || e); } }      // o briefing já está pronto: a falha da ata não trava a fila
    return { ok: true, mensagem: "enviado à Mesa de Audiência (nova audiência com o PDF analisado" + (comAta && !avisoAta ? " e ata preliminar" : "") + ")" + (avisoAta ? ". A ata preliminar NÃO foi gerada: " + avisoAta + " (abra a audiência na Mesa e use “Ata preliminar”)" : ""), minuta: "" };
  }
  const mesaOcupada = () => /Preparando a ata\.\.\.|Analisando\.\.\.|Lendo Arquivos\.\.\.|Extraindo autos|mapeando partes/i.test(corpoMesa());
  // A audiência nova nasce com a data de hoje e 13:30: usa a data e a hora da pauta (a audiência real).
  async function definirDataHoraMesa(data, hora, salvar) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(data || "") && !/^\d{2}:\d{2}$/.test(hora || "")) return;
    const campo = (tipo) => [...document.querySelectorAll("input[type=" + tipo + "]")].find((i) => visivel(i));
    const d = await esperar(() => campo("date"), 8000);
    let mudou = false;
    if (d && /^\d{4}-\d{2}-\d{2}$/.test(data || "") && d.value !== data) { definirValor(d, data); mudou = true; }
    const h = campo("time");
    if (h && /^\d{2}:\d{2}$/.test(hora || "") && h.value !== hora) { definirValor(h, hora); mudou = true; }
    if (mudou) { await dorme(400); if (salvar) { const sv = botao(/Salvar Ficha/i); if (sv) sv.click(); await dorme(600); } }
  }
  const visualizadorAta = () => document.querySelector("[data-testid=ata-preliminar-viewer]");
  async function gerarAta() {      // botão “Ata preliminar”/“Abrir ata preliminar” da aba Briefing; o app gera e abre o visualizador
    const bt = document.querySelector("[data-testid=btn-ata-preliminar]");
    if (!bt) throw falhar("não achei o botão da ata preliminar");
    bt.click();
    const t0 = Date.now(); let ocioso = 0, reabriu = 0;
    for (;;) {
      if (visualizadorAta()) return;
      const e = erroDaMesa(); if (e) throw falhar(e);
      const b2 = document.querySelector("[data-testid=btn-ata-preliminar]");
      if (mesaOcupada()) ocioso = 0;
      else if (Date.now() - t0 > 8000) {      // terminou de carregar e a ata não abriu
        ocioso++;
        if (ocioso >= 3) {
          if (b2 && /Abrir ata preliminar/i.test(texto(b2)) && reabriu < 2) { reabriu++; ocioso = 0; b2.click(); }      // a ata foi gerada: só abre
          else throw falhar("a ata preliminar não foi gerada (a IA não respondeu)");
        }
      }
      if (Date.now() - t0 > 20 * 60000) { const e = falhar("a ata preliminar não terminou em 20 minutos"); e.semRetry = false; throw e; }
      await dorme(1500);
    }
  }
  const fecharAta = async () => { if (!visualizadorAta()) return; window.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); await esperar(() => !visualizadorAta(), 5000); };

  // Lê da Mesa os dados de uma audiência já cadastrada: cabeçalho, abas 1 a 5 (texto das caixas) e a ata preliminar (HTML do documento).
  async function mesaLer({ processo, ata }) {
    await abrirMesa();
    const busca = [...document.querySelectorAll("input")].find((i) => /Buscar processo ou parte/i.test(i.placeholder || ""));
    if (busca) { definirValor(busca, ""); await dorme(300); }
    const alvo = dig(processo).slice(0, 9);
    const cartao = () => [...document.querySelectorAll("div")].find((d) => /rounded-xl/.test(d.className) && /cursor-pointer/.test(d.className) && dig(texto(d)).startsWith(alvo) && visivel(d));
    const c = await esperar(cartao, 10000);
    if (!c) throw new Error("não achei a audiência " + processo + " na Mesa (envie o processo à Mesa antes)");
    c.click(); await dorme(1200);
    const campo = (rot) => { const i = [...document.querySelectorAll("input")].find((x) => new RegExp("^" + rot, "i").test(texto(x.parentElement || x))); return i ? i.value : ""; };
    const procInput = [...document.querySelectorAll("input")].find((i) => /N[ºo°]?\s*do Processo/i.test(i.placeholder || ""));
    const cabecalho = { processo: procInput ? procInput.value : "", autor: campo("Autor"), reu: campo("R[ée]u"), assunto: campo("Assunto") };
    const raiz = document.querySelector(".mesa-escura") || document.body;
    const textoDaAba = () => {
      // As caixas de texto (textarea/input) guardam o conteúdo no VALOR: troca por texto. A cópia vai para um contêiner fora da tela, JÁ na página,
      // para o innerText respeitar as quebras de linha dos blocos (numa cópia solta ele devolve tudo emendado, sem linhas).
      const orig = [...raiz.querySelectorAll("textarea,input")], cl = raiz.cloneNode(true);
      [...cl.querySelectorAll("textarea,input")].forEach((e, i) => { const v = (orig[i] && orig[i].value) || e.value || ""; e.replaceWith(Object.assign(document.createElement("pre"), { textContent: v })); });
      const host = document.createElement("div"); host.style.cssText = "position:fixed;left:-99999px;top:0;width:1100px;pointer-events:none"; host.appendChild(cl); document.body.appendChild(host);
      let bruto = ""; try { bruto = host.innerText || ""; } finally { host.remove(); }
      const t = (bruto || cl.textContent || "").replace(/\n{3,}/g, "\n\n");
      const i = t.lastIndexOf("5. Ata"); return i >= 0 ? t.slice(i + 6).trim() : t;
    };
    const abas = {};
    for (const [k, rx] of [["briefing", /^\s*1\.\s*Briefing/i], ["roteiro", /^\s*2\.\s*Roteiro/i], ["deliberacoes", /^\s*3\.\s*Delibera/i], ["sentenca", /^\s*4\.\s*Senten/i], ["ata", /^\s*5\.\s*Ata/i]]) {
      const b = botao(rx); if (!b) { abas[k] = ""; continue; }
      b.click(); await dorme(900); abas[k] = textoDaAba().slice(0, 30000);
    }
    botao(/^\s*1\.\s*Briefing/i)?.click(); await dorme(500);
    // texto bruto dos autos (botão "Ver / Editar Texto Bruto dos Autos" do Briefing): fonte das citações, intimações, audiências e datas da pauta
    let bruto = "";
    const bBruto = botao(/Ver \/ Editar Texto Bruto/i);
    if (bBruto) {
      bBruto.click();
      const ta = await esperar(() => [...document.querySelectorAll("textarea")].find((x) => /Texto das pe[çc]as processuais/i.test(x.placeholder || "")), 6000);
      if (ta) bruto = ta.value || "";
      botao(/Ocultar Texto Bruto/i)?.click(); await dorme(300);
    }
    let ataHtml = "";
    const bta = document.querySelector("[data-testid=btn-ata-preliminar]");
    if (ata && bta && /Abrir ata preliminar/i.test(texto(bta))) {      // só abre se a ata já existe (não gasta IA) e se foi pedida
      bta.click();
      if (await esperar(visualizadorAta, 15000)) { await dorme(500); ataHtml = document.querySelector("[data-testid=ata-documento]")?.innerHTML || ""; await fecharAta(); }
    }
    return { ok: true, cabecalho, abas, ataHtml, bruto };
  }

  // avisa o app de que é a esteira (e não uma pessoa) que está operando: ele não abre a pergunta de OCR e escolhe o OCR sozinho
  const automatico = (p) => { document.documentElement.dataset.assessorAuto = "1"; return p.finally(() => { delete document.documentElement.dataset.assessorAuto; }); };
  // Quando o app roda dentro de uma moldura (página do AI Studio com o app num iframe *.run.app), a extensão entra nas duas páginas: a de fora
  // (sem o app) fica calada e só a moldura que tem o app responde, para as mensagens não irem para o quadro errado.
  // O app pode estar em qualquer nível de molduras aninhadas (AI Studio → moldura de segurança → app): quem não tem o app na tela e está numa moldura
  // (ou tem molduras dentro) fica calado; responde só o quadro que tem o app. O app publicado, sozinho na aba, responde sempre.
  // o app tem o título "Assessor Judicial" e vários elementos fixos; a tela cheia da minuta, por exemplo, não tem a área de entrada dos autos
  const temApp = () => /^Assessor Judicial/i.test(document.title || "") || !!document.querySelector("#tour-input-panel, #tour-execute-btn, [data-testid=gigantes-selo], #tour-result-tabs");
  const quadroSemApp = () => !temApp() && (window.top !== window || !!document.querySelector("iframe"));
  // ----- Saúde do sistema: entrega ao app os eventos que a extensão anotou (fila em chrome.storage.local) e remove da fila o que o app confirmou -----
  const entregarSaude = async () => {
    try {
      if (quadroSemApp() || !temApp()) return;
      const el = document.documentElement;
      if (el.dataset.projudiSaudeAck) {      // o app confirmou o recebimento: tira esses itens da fila
        const ids = new Set(JSON.parse(el.dataset.projudiSaudeAck || "[]")); delete el.dataset.projudiSaudeAck;
        const { saudeFila = [] } = await chrome.storage.local.get("saudeFila"); await chrome.storage.local.set({ saudeFila: saudeFila.filter((x) => !ids.has(x.id)) });
      }
      const { saudeFila = [], saudeVivo = 0 } = await chrome.storage.local.get(["saudeFila", "saudeVivo"]);
      if (Date.now() - saudeVivo > 24 * 3600_000) {      // uma vez por dia: avisa qual versão da extensão está em uso
        saudeFila.push({ id: "v" + Date.now().toString(36), ts: Date.now(), versao: chrome.runtime.getManifest().version, modulo: "extensao", severidade: "info", mensagem: "Extensão ativa" });
        await chrome.storage.local.set({ saudeFila: saudeFila.slice(-60), saudeVivo: Date.now() });
      }
      if (saudeFila.length && !el.dataset.projudiSaudeFila) { el.dataset.projudiSaudeFila = JSON.stringify(saudeFila.slice(0, 40)); window.dispatchEvent(new Event("projudi:saude")); }
    } catch (e) { /* sem armazenamento da extensão: nada a entregar */ }
  };
  setInterval(entregarSaude, 15000); setTimeout(entregarSaude, 5000);

  // ----- Central de fontes: o app pede as leis do Planalto (atributo + evento); a extensão busca no navegador do Super Admin e devolve uma lei por vez -----
  window.addEventListener("projudi:leis-pedido", () => {
    const el = document.documentElement;
    try {
      if (quadroSemApp()) return;
      const pedido = JSON.parse(el.dataset.projudiLeisPedido || "null"); delete el.dataset.projudiLeisPedido;
      if (!pedido || !Array.isArray(pedido.leis)) return;
      chrome.runtime.sendMessage({ acao: "leis-abrir", pedidoId: String(pedido.pedidoId || ""), modo: pedido.modo === "teste" ? "teste" : pedido.modo === "fonte" ? "fonte" : "leis", leis: pedido.leis.slice(0, 40).map((l) => ({ id: l.id, nome: l.nome, url: l.url, rotulo: l.rotulo, tipo: l.tipo, esfera: l.esfera, ente: l.ente, numero: l.numero, ano: l.ano })), fontesBusca: Array.isArray(pedido.fontesBusca) ? pedido.fontesBusca.slice(0, 20).map((f) => ({ id: f.id, nome: f.nome, esfera: f.esfera, ente: f.ente, url: f.url, ativa: f.ativa })) : [] }, (r) => {
        if (chrome.runtime.lastError || !r?.ok) { el.dataset.projudiLeisFim = JSON.stringify({ pedidoId: pedido.pedidoId, erro: chrome.runtime.lastError?.message || r?.erro || "a extensão não abriu a busca" }); window.dispatchEvent(new Event("projudi:leis-fim")); }
      });
    } catch (e) { /* pedido inválido */ }
  });
  const entregarFonte = async (m) => {      // arquivo (ou a falha) de UMA fonte pendente buscada pela extensão
    const el = document.documentElement, t0 = Date.now();
    while (el.dataset.projudiFonteEntrega) { if (Date.now() - t0 > 90000) throw new Error("o app não terminou de receber a fonte anterior"); await dorme(300); }
    el.dataset.projudiFonteEntrega = JSON.stringify({ pedidoId: m.pedidoId, id: m.id, nome: m.nome, b64: m.b64, contentType: m.contentType, url: m.url, erro: m.erro, tentativas: m.tentativas });
    window.dispatchEvent(new Event("projudi:fonte-entrega"));
    return { ok: true };
  };
  const entregarTeste = async (m) => {      // resultado de UM site do teste de acesso (só números e uma amostra de texto)
    const el = document.documentElement, t0 = Date.now();
    while (el.dataset.projudiTesteEntrega) { if (Date.now() - t0 > 30000) throw new Error("o app não terminou de receber o resultado anterior"); await dorme(200); }
    el.dataset.projudiTesteEntrega = JSON.stringify({ pedidoId: m.pedidoId, resultado: m.resultado });
    window.dispatchEvent(new Event("projudi:teste-entrega"));
    return { ok: true };
  };
  const entregarLei = async (m) => {      // coloca UMA lei no atributo da página e espera o app ler (para não perder nenhuma)
    const el = document.documentElement, t0 = Date.now();
    while (el.dataset.projudiLeiEntrega) { if (Date.now() - t0 > 90000) throw new Error("o app não terminou de receber a lei anterior"); await dorme(300); }
    el.dataset.projudiLeiEntrega = JSON.stringify({ pedidoId: m.pedidoId, id: m.id, nome: m.nome, b64: m.b64 });
    window.dispatchEvent(new Event("projudi:lei-entrega"));
    return { ok: true };
  };

  chrome.runtime.onMessage.addListener((m, _s, responder) => {
    if (m?.acao === "lancar-progresso") { if (btLP.disabled) dizLP(m.texto); return false; }      // andamento do botão “Lançar no Projudi” (definido mais abaixo)
    if (quadroSemApp()) return false;
    if (m?.acao === "studio-ping") { responder({ ok: true }); return false; }
    if (m?.acao === "studio-lei-entrega") { entregarLei(m).then(responder, (e) => responder({ ok: false, erro: String(e.message || e) })); return true; }
    if (m?.acao === "studio-fonte-entrega") { entregarFonte(m).then(responder, (e) => responder({ ok: false, erro: String(e.message || e) })); return true; }
    if (m?.acao === "studio-teste-entrega") { entregarTeste(m).then(responder, (e) => responder({ ok: false, erro: String(e.message || e) })); return true; }
    if (m?.acao === "studio-leis-fim") { document.documentElement.dataset.projudiLeisFim = JSON.stringify({ pedidoId: m.pedidoId, modo: m.modo || "leis", feitas: m.feitas, falhas: m.falhas, bloqueios: m.bloqueios }); window.dispatchEvent(new Event("projudi:leis-fim")); responder({ ok: true }); return false; }
    if (m?.acao === "studio-gigantes") { responder({ ok: true, jobs: listaGigantes() }); return false; }
    if (m?.acao === "studio-parte") {     // recebe um arquivo em pedaços
      const p = partes.get(m.id) || []; const bin = atob(m.b64), b = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
      p[m.i] = b; partes.set(m.id, p);
      if (p.filter(Boolean).length === m.n) {
        const total = p.reduce((s, x) => s + x.length, 0), tudo = new Uint8Array(total); let o = 0;
        p.forEach((x) => { tudo.set(x, o); o += x.length; });
        arquivos.set(m.id, tudo); partes.delete(m.id);
        if (arquivos.size > 3) arquivos.delete(arquivos.keys().next().value);
      }
      responder({ ok: true }); return false;
    }
    if (m?.acao === "studio-enviar-base") { enviar(m.nome, m.arquivoId, m.b64, !!m.substituir).then(responder, (e) => responder({ ok: false, erro: String(e.message || e) })); return true; }
    if (m?.acao === "studio-prompt-texto") {      // IA externa: o app entrega o TEXTO do prompt da serventia (a esteira o cola na conversa da IA)
      const id = "pr" + Date.now() + Math.random().toString(36).slice(2, 5);
      try { delete document.documentElement.dataset.projudiPromptResposta; document.documentElement.dataset.projudiPromptPedido = JSON.stringify({ reqId: id, nome: m.nome || "" }); window.dispatchEvent(new Event("projudi:pedir-prompt")); } catch (e) { responder({ ok: false, erro: String(e.message || e) }); return false; }
      esperar(() => { try { const r = JSON.parse(document.documentElement.dataset.projudiPromptResposta || "null"); return r && r.reqId === id ? r : null; } catch { return null; } }, 15000)
        .then((r) => responder(r || { ok: false, erro: "o app do Studio não respondeu ao pedido do prompt (atualize a aba do Studio)" }));
      return true;
    }
    if (m?.acao === "studio-cadastrar-minuta") {      // minuta pronta vinda do Agaia: o app a grava no Histórico (organizada por serventia e prompt) e confirma pelo atributo da página
      const id = "ag" + Date.now() + Math.random().toString(36).slice(2, 5);
      try { delete document.documentElement.dataset.agaiaCadastro; window.dispatchEvent(new CustomEvent("assessor:cadastrar-minuta", { detail: JSON.stringify({ ...m.dados, reqId: id }) })); } catch (e) { responder({ ok: false, erro: String(e.message || e) }); return false; }
      esperar(() => { try { const r = JSON.parse(document.documentElement.dataset.agaiaCadastro || "null"); return r && r.reqId === id ? r : null; } catch { return null; } }, 30000)
        .then((r) => responder(r ? { ok: !!r.ok, id: r.id, erro: r.erro || "" } : { ok: false, erro: "o app do Studio não confirmou o cadastro (atualize a aba do Studio: a versão dela pode ser antiga)" }));
      return true;
    }
    if (m?.acao === "studio-ler-minuta" && resultadoTurbo() && (!m.processo || (resultadoTurbo().innerText || "").includes(m.processo))) {      // o resultado do Módulo Turbo está na tela: usa-o, sem procurar no histórico
      const r = lerResultadoTurbo(); responder({ ok: !!r.texto, minuta: r.texto, minutaHtml: r.html, erro: r.texto ? "" : "não consegui ler a minuta do Turbo" }); return false;
    }
    if (m?.acao === "studio-ler-minuta") { (m.processo ? carregarDoHistorico(m.processo, m.desde || 0) : Promise.resolve()).then(() => lerMinuta()).then((t) => responder({ ok: !!t, minuta: t, minutaHtml: minutaHtmlDoPainel(), erro: t ? "" : "não há minuta pronta na tela do app" })).catch((e) => responder({ ok: false, erro: String(e.message || e) })); return true; }
    if (m?.acao === "studio-analisar") { window.__dicasPrompt = m.dicas || ""; window.__promptAproximado = ""; }
    if (m?.acao === "studio-analisar" && m.reqId) {      // análise longa (qualquer modo): responde já e entrega o resultado pelo storage (o canal de mensagem pode cair no meio e a análise não se perde)
      const k = "studio_res_" + m.reqId;
      automatico(m.modo === "mesa" ? mesa(m) : m.modo === "mesa-ler" ? mesaLer(m) : m.modo === "lupa" ? lupa(m) : m.modo === "turbo" ? turbo(m) : analisar(m)).catch((e) => ({ ok: false, erro: String(e.message || e), opcoes: e.opcoes, semRetry: !!e.semRetry, grande: !!e.grande })).then((r) => chrome.storage.local.set({ [k]: r }));
      responder({ ok: true, assincrono: true }); return false;
    }
    if (m?.acao === "studio-analisar") { automatico(m.modo === "lupa" ? lupa(m) : m.modo === "turbo" ? turbo(m) : analisar(m)).then(responder, (e) => responder({ ok: false, erro: String(e.message || e), opcoes: e.opcoes })); return true; }
    return false;
  });

  // ---------- botão na tela do app: "Enviar esta minuta à esteira" (para continuar de onde parou) ----------
  const K = (id) => "esteira_" + id;
  const PENDENTES = ["aguardando", "analisando", "pausado", "erro"];
  async function pendentes() {
    const { esteira_ordem = [] } = await chrome.storage.local.get("esteira_ordem");
    const d = await chrome.storage.local.get(esteira_ordem.map(K));
    return esteira_ordem.map((i) => d[K(i)]).filter((x) => x && PENDENTES.includes(x.estado) && x.modo !== "turbo" && x.modo !== "lupa");      // Turbo/Lupa devolvem o resultado sozinhos (não usam Google Docs)
  }
  const host = document.createElement("div"); host.setAttribute("data-projudi-ext", "studio-envio");
  const sh = host.attachShadow({ mode: "open" });
  sh.innerHTML = `<style>.b{position:fixed;left:50%;transform:translateX(-50%);bottom:10px;z-index:2147483646;background:#0b3d7a;color:#fff;font:13px system-ui,sans-serif;padding:8px 12px;border-radius:8px;box-shadow:0 2px 10px #0006;display:none;gap:8px;align-items:center;max-width:90vw}
    button{font:13px system-ui;padding:5px 12px;border:0;border-radius:4px;cursor:pointer;background:#fff;color:#0b3d7a;font-weight:700} select{font:13px system-ui;max-width:260px}</style><div class="b"></div>`;
  const caixa = sh.querySelector(".b");
  document.documentElement.appendChild(host);
  async function atualizarBotao() {
    try {
      if (!host.isConnected) document.documentElement.appendChild(host);
      const pend = await pendentes(), tem = minutaDoPainel().length > 200 || !!resultadoTurbo();
      if (!pend.length || !tem) { caixa.style.display = "none"; return; }
      const num = ((document.getElementById("tour-meta-parties-box")?.innerText) || (resultadoTurbo()?.innerText) || "").match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/)?.[0];
      const certo = pend.find((x) => x.processo === num) || pend[0];
      const chave = pend.map((x) => x.id).join() + "|" + certo.id;
      if (caixa.dataset.chave === chave && caixa.style.display === "flex") return;
      caixa.dataset.chave = chave; caixa.style.display = "flex";
      caixa.innerHTML = `<span>Esteira de minutas:</span><select>${pend.map((x) => `<option value="${x.id}" ${x.id === certo.id ? "selected" : ""}>${x.processo}</option>`).join("")}</select><button>Enviar a minuta aberta aqui para este processo</button><span class="r"></span>`;
      caixa.querySelector("button").onclick = async () => {
        const id = caixa.querySelector("select").value, turbo = resultadoTurbo() ? lerResultadoTurbo() : null, minuta = turbo ? turbo.texto : await lerMinuta();
        if (!minuta) { caixa.querySelector(".r").textContent = "não achei a minuta nesta tela"; return; }
        await navigator.locks.request("esteira-item", async () => { const it = (await chrome.storage.local.get(K(id)))[K(id)]; if (it) await chrome.storage.local.set({ [K(id)]: { ...it, estado: "recebida", minutaRecebida: minuta, htmlRecebido: turbo ? turbo.html : minutaHtmlDoPainel(), erro: "" } }); });
        caixa.querySelector(".r").textContent = pend.find((x) => x.id === id)?.docs ? "enviada! o Google Docs vai abrir." : "enviada à esteira.";
        setTimeout(atualizarBotao, 3000);
      };
    } catch (e) { /* extensão recarregada: esta cópia do script morreu */ }
  }
  // A esteira é automática: a caixa “Enviar a minuta aberta aqui…” não aparece mais (a recuperação manual fica na própria página da esteira).
  void atualizarBotao;

  // ---------- botão flutuante “Lançar no Projudi” ----------
  // Leva a minuta aberta aqui para o editor da pré-análise do Projudi (tipo e modelo “<Tipo> Padrão”), com o PDF dos autos ao lado. A extensão não grava nada no Projudi.
  const hostLP = document.createElement("div"); hostLP.setAttribute("data-projudi-ext", "lancar-projudi");
  const shLP = hostLP.attachShadow({ mode: "open" });
  shLP.innerHTML = `<style>
    .w{position:fixed;right:22px;bottom:96px;z-index:2147483645;display:none;flex-direction:column;align-items:flex-end;gap:6px;font:13px system-ui,sans-serif}
    button{font:700 14px system-ui,sans-serif;padding:11px 18px;border:0;border-radius:999px;cursor:pointer;background:linear-gradient(135deg,#0b3d7a,#1565c0);color:#fff;box-shadow:0 4px 16px #0b3d7a88}
    button:hover{filter:brightness(1.12)} button:disabled{opacity:.7;cursor:wait}
    .r{position:relative;max-width:340px;background:#0b1f3a;color:#fff;padding:8px 30px 8px 11px;border-radius:8px;box-shadow:0 2px 10px #0006;display:none;line-height:1.35}
    .r.e{background:#7a1010}
    .sv{display:none;flex-direction:column;gap:4px;max-width:360px;background:#fff;color:#12263f;border:1px solid #9bb6d6;border-radius:10px;padding:10px;box-shadow:0 4px 16px #0005}
    .sv b{font-size:13px;margin-bottom:2px}
    .sv button{font:600 12.5px system-ui,sans-serif;text-align:left;padding:7px 10px;border-radius:7px;background:#eef4fc;color:#12263f;border:1px solid #c5d6ec;box-shadow:none}
    .sv button.s{background:#0b3d7a;color:#fff;border-color:#0b3d7a}
    .sv .c{background:transparent;border:0;color:#5a6b80;text-align:center}
    .r .x{all:unset;position:absolute;top:4px;right:6px;width:20px;height:20px;line-height:20px;text-align:center;font:700 16px system-ui,sans-serif;color:#fff;opacity:.8;cursor:pointer;border-radius:50%}
    .r .x:hover{opacity:1;background:#ffffff33}
  </style><div class="w"><div class="sv"></div><div class="r"><span class="t"></span><button class="x" type="button" title="Fechar esta mensagem" aria-label="Fechar">×</button></div><button class="p" title="Abre a pré-análise do processo no Projudi (na aba que você já deixou aberta), escolhe o tipo e o modelo padrão, coloca esta minuta no editor e abre o PDF dos autos ao lado. Não grava nada: você confere e salva.">⚖ Lançar no Projudi</button></div>`;
  const wLP = shLP.querySelector(".w"), btLP = shLP.querySelector("button.p"), rLP = shLP.querySelector(".r"), svLP = shLP.querySelector(".sv");
  let timerLP = null;
  // mensagem do botão: tem "×" para fechar; o aviso de sucesso some sozinho em 20 s (andamento e erro ficam até fechar)
  const dizLP = (t, erro = false, ms = 0) => { clearTimeout(timerLP); rLP.querySelector(".t").textContent = t; rLP.className = "r" + (erro ? " e" : ""); rLP.style.display = t ? "block" : "none"; if (t && ms) timerLP = setTimeout(() => dizLP(""), ms); };
  rLP.querySelector(".x").onclick = () => dizLP("");
  const numeroLP = () => ((document.getElementById("tour-meta-parties-box")?.innerText) || (resultadoTurbo()?.innerText) || document.body.innerText.slice(0, 6000) || "").match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/)?.[0] || "";
  async function atualizarLP() {
    try {
      if (!hostLP.isConnected) document.documentElement.appendChild(hostLP);
      wLP.style.display = (minutaDoPainel().length > 200 || resultadoTurbo()) ? "flex" : "none";
      posicionarLP();
    } catch (e) { /* extensão recarregada: esta cópia do script morreu */ }
  }
  // Posição: encostado à ESQUERDA do botão “Editar com o chat Gemini” (chat fechado) ou do “Recolher” (chat aberto, no fluxo da página); acompanha a rolagem.
  // Sem nenhum dos dois na tela, vai para o canto, acima do selo “MySQL – Hostinger” do app (não cobre o chat nem esse selo).
  function posicionarLP() {
    const bts = [...document.querySelectorAll("button")];
    const ancora = bts.find((b) => /Editar com o chat/i.test(texto(b)) && visivel(b)) || bts.find((b) => b.getAttribute("data-testid") === "fechar-chat-gemini" && visivel(b));
    const r = ancora && ancora.getBoundingClientRect();
    if (r && r.bottom > 0 && r.top < innerHeight && r.left > 0) {
      const h = btLP.getBoundingClientRect().height || 40;
      wLP.style.right = Math.max(8, Math.round(innerWidth - r.left + 10)) + "px";
      wLP.style.bottom = Math.max(8, Math.round(innerHeight - r.bottom - (h - r.height) / 2)) + "px";
    } else { wLP.style.right = "22px"; wLP.style.bottom = "64px"; }
  }
  addEventListener("scroll", () => { try { posicionarLP(); } catch (e) { /* nada */ } }, true);
  addEventListener("resize", () => { try { posicionarLP(); } catch (e) { /* nada */ } });
  btLP.onclick = async () => {
    try {
      // se o usuário ainda está digitando direto na minuta, fecha o campo (que salva sozinho) e espera a visão formatada voltar antes de ler
      const ativo = document.activeElement;
      if (ativo && ativo.tagName === "TEXTAREA" && ativo.closest("div.font-serif")) { ativo.blur(); await esperar(() => !document.querySelector("div.font-serif textarea"), 4000); await esperar(() => false, 300); }
      const turbo = resultadoTurbo() ? lerResultadoTurbo() : null;
      const texto2 = turbo ? turbo.texto : await lerMinuta(), html = turbo ? turbo.html : minutaHtmlDoPainel();
      if (!texto2) { dizLP("Não achei a minuta nesta tela.", true); return; }
      const processo = numeroLP();
      if (!processo) { dizLP("Não achei o número do processo nesta tela.", true); return; }
      // em qual serventia do Projudi lançar? (só as que não estão ocultas na extensão); a última escolhida já vem marcada
      let serventiaUrl = "";
      try {
        const sv = await chrome.runtime.sendMessage({ acao: "lancar-serventias", processo });
        if (sv?.serventias?.length) {
          serventiaUrl = await new Promise((ok) => {
            svLP.innerHTML = ""; const t = document.createElement("b"); t.textContent = "Lançar em qual serventia do Projudi?"; svLP.appendChild(t);
            for (const x of sv.serventias) { const b = document.createElement("button"); b.type = "button"; b.textContent = x.serventia + (x.perfil ? " — " + x.perfil : ""); if (x.url === sv.sugerida) b.className = "s"; b.onclick = () => { svLP.style.display = "none"; ok(x.url); }; svLP.appendChild(b); }
            const c = document.createElement("button"); c.type = "button"; c.className = "c"; c.textContent = "Cancelar"; c.onclick = () => { svLP.style.display = "none"; ok(null); }; svLP.appendChild(c);
            svLP.style.display = "flex";
          });
          if (serventiaUrl === null) return;
        }
      } catch (e) { /* sem lista: usa a serventia do processo, se a extensão a conhecer */ }
      btLP.disabled = true; dizLP("Iniciando…");
      const hRes = painelResultado(), rotulo = hRes ? texto(hRes.parentElement).replace(/Resultado\s*&\s*An[aá]lise/i, "").trim().slice(0, 60) : "";      // rótulo do card (ex.: DECISÃO INTERLOCUTÓRIA)
      const r = await Promise.race([chrome.runtime.sendMessage({ acao: "lancar-projudi", processo, serventiaUrl, texto: texto2, html, tituloAto: rotulo }), new Promise((ok) => setTimeout(() => ok({ ok: false, erro: "a extensão não respondeu em 4 minutos; clique de novo (se persistir, recarregue o Projudi e esta aba)" }), 240000))]);
      if (r?.ok) dizLP(`Pronto: ${r.tipo} / “${r.modelo}” com a minuta no editor do Projudi. Confira e clique em “Salvar Texto Parcial”.${r.aviso ? " ⚠ " + r.aviso : ""}`, false, 20000);
      else dizLP("Não deu certo: " + (r?.erro || "sem resposta da extensão") + (r?.passo ? ` (passo: ${r.passo})` : ""), true);
    } catch (e) { dizLP("Não deu certo: " + (e.message || e) + " (se a extensão foi atualizada, recarregue esta aba)", true); }
    finally { btLP.disabled = false; }
  };
  document.documentElement.appendChild(hostLP);
  atualizarLP(); setInterval(atualizarLP, 2000); setInterval(() => { try { if (wLP.style.display === "flex") posicionarLP(); } catch (e) { /* nada */ } }, 400);
})();

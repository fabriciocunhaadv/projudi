// Agaia (simplesefacil.tjgo.jus.br/agaia): troca o texto de um prompt do usuário pelo prompt do Studio.
// Três passos, comandados pela extensão (a página recarrega entre eles): achar na lista pelo TÍTULO → ler o texto atual (cópia de segurança) → gravar o novo texto e clicar em Salvar.
(() => {
  if (window.__projudiAgaiaPrompt) return;
  window.__projudiAgaiaPrompt = true;
  const dorme = (ms) => new Promise((ok) => setTimeout(ok, ms));
  const sem = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\s+/g, " ").trim().toLowerCase();
  const visivel = (el) => { const r = el.getBoundingClientRect(); const cs = getComputedStyle(el); return r.width > 20 && r.height > 10 && cs.visibility !== "hidden" && cs.display !== "none"; };
  const norm = (s) => String(s || "").replace(/ /g, " ").replace(/[ \t]+/g, " ").replace(/\s*\n\s*/g, "\n").trim();

  // ---------- Lista: acha a linha cujo Título é igual ao procurado ----------
  function linhasDaTabela() {
    const tabs = [...document.querySelectorAll("table")];
    const out = [];
    for (const t of tabs) {
      const cab = [...t.querySelectorAll("thead th, tr:first-child th")].map((h) => sem(h.textContent));
      const iTit = cab.findIndex((x) => x.startsWith("titulo")), iUni = cab.findIndex((x) => x.startsWith("unidade")), iPriv = cab.findIndex((x) => x.startsWith("privacidade"));
      if (iTit < 0) continue;
      for (const tr of t.querySelectorAll("tbody tr")) {
        const tds = [...tr.children]; if (tds.length <= iTit) continue;
        const editar = [...tr.querySelectorAll("a,button")].find((a) => /editar/i.test((a.textContent || "") + " " + (a.title || "") + " " + (a.getAttribute("aria-label") || "")) || /\/prompts\/edit\//.test(a.getAttribute("href") || ""));
        out.push({ tr, titulo: (tds[iTit].textContent || "").replace(/\s+/g, " ").trim(), unidade: iUni >= 0 ? (tds[iUni]?.textContent || "").trim() : "", privacidade: iPriv >= 0 ? (tds[iPriv]?.textContent || "").trim() : "", editar });
      }
    }
    return out;
  }
  const proximaPagina = () => [...document.querySelectorAll("a,button")].find((a) => /^(pr[oó]xim[oa]|next|›|»|>)$/i.test((a.textContent || "").trim()) && !/disabled/.test(a.className + " " + (a.parentElement?.className || "")) && !a.disabled && visivel(a));

  async function achar(titulo) {
    const alvo = sem(titulo);
    const cauda = sem(String(titulo).split(" - ").pop());      // “Outros Área Judicial - Execução Fiscal Estadual” → “execução fiscal estadual”: no Agaia vem com prefixo (ex.: “Fabrício Execução Fiscal Estadual”)
    const candidatas = [];
    let vistos = [];
    for (let pag = 0; pag < 30; pag++) {
      for (let i = 0; i < 20 && !linhasDaTabela().length; i++) await dorme(300);      // a lista pode carregar depois (DataTables)
      const linhas = linhasDaTabela();
      vistos = vistos.concat(linhas.map((l) => l.titulo));
      const pontua = (l) => { const x = sem(l.titulo); return x === alvo ? 3 : (x === cauda || x.endsWith(" " + cauda)) ? 2 : (cauda.length >= 6 && x.includes(cauda)) ? 1 : 0; };
      for (const l of linhas) if (l.editar && pontua(l)) candidatas.push({ l, p: pontua(l) });
      const prox = proximaPagina(); if (!prox) break;
      const antes = linhas.map((l) => l.titulo).join("|");
      prox.click(); await dorme(900);
      if (linhasDaTabela().map((l) => l.titulo).join("|") === antes) break;      // o clique não mudou a lista: acabou
    }
    if (candidatas.length) {
      const melhor = Math.max(...candidatas.map((c) => c.p)), top = candidatas.filter((c) => c.p === melhor);
      const menor = Math.min(...top.map((c) => c.l.titulo.length)), fim = top.filter((c) => c.l.titulo.length === menor);
      if (fim.length === 1) { const e = fim[0].l, href = e.editar.getAttribute("href") || ""; if (!href) return { ok: false, erro: "o botão Editar do Agaia não tem endereço (mudou o layout?)" };
        return { ok: true, href: new URL(href, location.href).href, id: (href.match(/\/prompts\/edit\/([^/?#]+)/) || [])[1] || "", unidade: e.unidade, privacidade: e.privacidade, tituloAgaia: e.titulo }; }
      return { ok: false, erro: `há ${fim.length} prompts parecidos com “${titulo}” no Agaia (${fim.map((c) => `“${c.l.titulo}” — ${c.l.unidade || "sem unidade"}`).join("; ")}). Não sei qual trocar; deixe só um com esse nome.` };
    }
    return { ok: false, naoEncontrado: true, erro: `não achei no Agaia um prompt parecido com “${titulo}” (vi ${vistos.length} prompts na lista; procurei por “${String(titulo).split(" - ").pop()}” no título).` };
  }

  // ---------- Editor da página de edição ----------
  function editores() {
    const lista = [];
    for (const el of document.querySelectorAll(".ql-editor, .ck-editor__editable, .note-editable, .fr-element, .trix-content, trix-editor, [contenteditable='true'], [contenteditable='']")) if (visivel(el)) lista.push({ tipo: "rico", el });
    for (const f of document.querySelectorAll("iframe")) { try { const b = f.contentDocument?.body; if (b && (b.isContentEditable || b.getAttribute("contenteditable") === "true") && visivel(f)) lista.push({ tipo: "rico", el: b, iframe: f }); } catch (e) { /* outro domínio */ } }
    for (const el of document.querySelectorAll("textarea")) if (visivel(el)) lista.push({ tipo: "textarea", el });
    const area = (x) => { const r = (x.iframe || x.el).getBoundingClientRect(); return r.width * r.height; };
    return lista.sort((a, b) => area(b) - area(a));
  }
  const textoDe = (ed) => ed.tipo === "textarea" ? ed.el.value : blocosParaTexto(ed.el);
  /** Texto do editor rico preservando as quebras de linha (cada parágrafo/linha vira uma linha). */
  function blocosParaTexto(raiz) {
    const linhas = [], atual = [];
    const fecha = () => { linhas.push(atual.join("")); atual.length = 0; };
    const BLOCO = /^(P|DIV|LI|H[1-6]|BLOCKQUOTE|PRE|TR)$/;
    (function anda(n) {
      for (const c of n.childNodes) {
        if (c.nodeType === 3) atual.push(c.nodeValue);
        else if (c.nodeType === 1) {
          if (c.tagName === "BR") { fecha(); continue; }
          const b = BLOCO.test(c.tagName); if (b && atual.length) fecha();
          anda(c); if (b) fecha();
        }
      }
    })(raiz);
    if (atual.length) fecha();
    return linhas.join("\n").replace(/\n{3,}/g, "\n\n").replace(/^\n+|\s+$/g, "");
  }
  const escapa = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const textoParaHtml = (t) => String(t).split("\n").map((l) => "<p>" + (l.trim() ? escapa(l) : "<br>") + "</p>").join("");

  function campoTitulo() {
    return [...document.querySelectorAll("input[type=text],input:not([type])")].filter(visivel).find((i) => /t[ií]tulo|title/i.test((i.name || "") + " " + (i.id || "") + " " + (i.placeholder || "") + " " + (i.labels?.[0]?.textContent || "")));
  }
  function botaoSalvar() {
    return [...document.querySelectorAll("button,input[type=submit],input[type=button],a.btn")].filter(visivel).find((b) => /^\s*salvar\s*$/i.test(b.textContent || b.value || ""));
  }

  async function ler() {
    let eds = [];
    for (let i = 0; i < 40 && !(eds = editores()).length; i++) await dorme(300);
    if (!eds.length) return { ok: false, erro: "não achei o campo de texto do prompt na página de edição do Agaia" };
    const ed = eds[0];
    return { ok: true, texto: textoDe(ed), html: ed.tipo === "textarea" ? "" : ed.el.innerHTML, tipo: ed.tipo, titulo: campoTitulo()?.value || "", salvarOk: !!botaoSalvar() };
  }

  function disparar(el) { for (const t of ["input", "change", "keyup"]) el.dispatchEvent(new Event(t, { bubbles: true })); }
  /** Troca todo o conteúdo do editor. Retorna true se o texto lido depois bate com o pedido. */
  async function escrever(ed, { texto, html }) {
    if (ed.tipo === "textarea") {
      ed.el.focus(); const set = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set; set.call(ed.el, texto); disparar(ed.el);
    } else {
      const doc = ed.el.ownerDocument, win = doc.defaultView;
      ed.el.focus();
      let ok = false;
      if (html == null) {
        try { doc.execCommand("selectAll", false, null); ok = doc.execCommand("insertText", false, ""); doc.execCommand("delete", false, null); } catch (e) { ok = false; }
        const linhas = String(texto).split("\n");
        for (let i = 0; i < linhas.length; i++) {
          try { if (linhas[i]) doc.execCommand("insertText", false, linhas[i]); if (i < linhas.length - 1) doc.execCommand("insertParagraph", false, null); } catch (e) { /* cai no plano B */ }
        }
        if (norm(blocosParaTexto(ed.el)) !== norm(texto)) { ed.el.innerHTML = textoParaHtml(texto); disparar(ed.el); }      // plano B: coloca o HTML direto
      } else { ed.el.innerHTML = html; disparar(ed.el); }
      try { win.getSelection().removeAllRanges(); } catch (e) { /* nada */ }
    }
    await dorme(300);
    return norm(textoDe(ed)) === norm(texto != null ? texto : blocosParaTexto(Object.assign(document.createElement("div"), { innerHTML: html })));
  }

  async function gravar({ texto, html }) {
    const eds = editores(); if (!eds.length) return { ok: false, erro: "não achei o campo de texto do prompt" };
    const ed = eds[0], salvar = botaoSalvar();
    if (!salvar) return { ok: false, erro: "não achei o botão Salvar" };
    const esperado = texto != null ? texto : blocosParaTexto(Object.assign(document.createElement("div"), { innerHTML: html }));
    const bateu = await escrever(ed, { texto, html });
    if (!bateu) return { ok: false, erro: "não consegui escrever o texto no editor do Agaia (o conteúdo lido depois não bateu)", visto: textoDe(ed).slice(0, 200) };
    setTimeout(() => salvar.click(), 250);      // a página recarrega ao salvar: responde antes
    return { ok: true, esperado };
  }


  /** Retrato da página de edição (para eu ajustar a gravação sem adivinhar): editor, campos do formulário, botão Salvar. Não inclui o texto inteiro do prompt. */
  function diagnostico() {
    const cab = (x, n = 400) => String(x || "").slice(0, n);
    const eds = editores().slice(0, 3).map((e) => ({ tipo: e.tipo, tag: e.el.tagName, id: e.el.id, classe: cab(e.el.className, 120), ce: e.el.getAttribute("contenteditable"), outerComeco: cab(e.el.outerHTML, 600), innerComeco: cab(e.tipo === "textarea" ? e.el.value : e.el.innerHTML, 700), tamanhoInner: (e.tipo === "textarea" ? e.el.value : e.el.innerHTML).length, pai: cab(e.el.parentElement?.outerHTML.replace(e.el.outerHTML, "[EDITOR]"), 500) }));
    const campos = [...document.querySelectorAll("form input, form textarea, form select")].map((c) => ({ tag: c.tagName, tipo: c.type || "", nome: c.name || "", id: c.id || "", tam: String(c.value || "").length, comeco: cab(c.value, 160) }));
    const forms = [...document.querySelectorAll("form")].map((f) => ({ action: f.getAttribute("action"), method: f.method, enctype: f.enctype, id: f.id, classe: cab(f.className, 80) }));
    const s = botaoSalvar();
    const botoes = [...document.querySelectorAll("button,a.btn,input[type=submit]")].filter(visivel).map((b) => cab((b.textContent || b.value || "").replace(/\s+/g, " ").trim(), 40));
    const scripts = [...document.scripts].map((x) => x.src ? x.src.split("/").slice(-1)[0] : "").filter(Boolean);
    return { url: location.href, forms, editores: eds, campos, salvar: s ? cab(s.outerHTML, 400) : null, botoes, scripts, libs: { quill: !!document.querySelector(".ql-container"), tinymce: !!document.querySelector(".tox,.mce-tinymce"), ckeditor: !!document.querySelector(".ck-editor"), summernote: !!document.querySelector(".note-editor"), trix: !!document.querySelector("trix-editor") } };
  }

  chrome.runtime.onMessage.addListener((m, s, responder) => {
    if (m?.acao === "agaia-prompt-ping") { responder({ ok: true, lista: linhasDaTabela().length, editor: editores().length }); return false; }
    if (m?.acao === "agaia-prompt-achar") { achar(String(m.titulo || "")).then(responder, (e) => responder({ ok: false, erro: String(e?.message || e) })); return true; }
    if (m?.acao === "agaia-prompt-diagnostico") { responder(diagnostico()); return false; }
    if (m?.acao === "agaia-prompt-ler") { ler().then(responder, (e) => responder({ ok: false, erro: String(e?.message || e) })); return true; }
    if (m?.acao === "agaia-prompt-gravar") { gravar(m).then(responder, (e) => responder({ ok: false, erro: String(e?.message || e) })); return true; }
    return false;
  });
  window.__projudiAgaiaPromptTeste = { achar, ler, gravar, blocosParaTexto };      // usado só nos testes
})();

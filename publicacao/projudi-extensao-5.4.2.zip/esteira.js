import { todos, atualizar, lerPdf, remover, enfileirar, ROTULO, ATIVOS } from "./esteira-banco.js";
import { instalarSaude, reportarSaude } from "./saude-fila.js";
import { quadroDoProcesso } from "./movimentacoes-quadro.js";
import { lerMidia, guardarPdfDoVideo, lerPdfDoVideo, apagarGuardadosDoVideo, limparGuardadosAntigos } from "./esteira-banco.js";
import { chaveDoProcesso } from "./midias-projudi.js";
instalarSaude("esteira");
import { analisarNoStudio, lerMinutaAtual, consultarGigantes, cadastrarNoStudio, lerPromptDoStudio, sentencaComVideoNoStudio } from "./studio-cliente.js";
import { executarNaIa, capturarDaAba, SITES_IA, temPermissao, pedirPermissao } from "./ia-externa-cliente.js";
import { executarNoAgaia, retomarExecucao } from "./agaia-cliente.js";
import { criarDocumento, abrirLadoALado, lerDocumento, tipoDaMinuta, nomeDoc } from "./docs-api.js";
import { paragrafosDeHtml } from "./docs-core.js";
import { textoDoPdf } from "./pdf-texto.js";
import { vigiarAcordado, conferirAcordado } from "./acordado.js";
import { lerMinutaPre } from "./minuta-pre.js";
import { chaveProc } from "./proc-chave.js";
import "./projudi-quadro.js";      // define globalThis.ProjudiQuadro (navegar DENTRO do quadro da moldura do Projudi)
const BASE = "https://projudi.tjgo.jus.br/";
const absoluta = (u) => (u ? new URL(u, BASE).href : BASE);

const $ = (id) => document.getElementById(id), esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let dono = false, ocupado = false, pausaAte = 0, pausaTurboAte = 0;

// Esteira automática: com a 1ª etapa concluída no Studio o processo está "concluído" para a fila (a minuta fica no histórico do app) e o próximo já é enviado.
// O Projudi só mostra o processo na serventia escolhida na sessão: entra nela antes de abrir (mesmo clique de “Serventias Disponíveis”).
async function abrirNoProjudi(it, url, active = true) {
  // navega dentro de uma aba do Projudi que já esteja aberta (sem abrir aba nova); só cria uma se não houver nenhuma
  const abertas = await chrome.tabs.query({ url: new URL(BASE).origin + "/*" }).catch(() => []);
  const antiga = abertas.find((t) => t.id === it.abas?.projudi) || abertas.find((t) => !t.pinned) || abertas[0];
  const ir = async (alvo) => {
    // com a moldura (cabeçalho e menus) na aba, navega só o quadro: o usuário não perde o menu nem o caminho de volta ao início
    if (aba && await ProjudiQuadro.temMoldura(aba.id)) { if (active) await chrome.tabs.update(aba.id, { active: true }); if (await ProjudiQuadro.irPara(aba.id, alvo)) { await new Promise((ok) => setTimeout(ok, 600)); return; } }
    await chrome.tabs.update(aba.id, { url: alvo, active }); await new Promise((ok) => setTimeout(ok, 600)); await new Promise((ok) => { const f = (id, i) => { if (id === aba.id && i.status === "complete") { chrome.tabs.onUpdated.removeListener(f); ok(); } }; chrome.tabs.onUpdated.addListener(f); setTimeout(() => { chrome.tabs.onUpdated.removeListener(f); ok(); }, 30000); }); };
  const aba = antiga || await chrome.tabs.create({ url: it.serventiaUrl ? absoluta(it.serventiaUrl) : url, active });
  if (antiga) { if (it.serventiaUrl) { await ir(absoluta(it.serventiaUrl)); await new Promise((ok) => setTimeout(ok, 1200)); } await ir(url); if (active) chrome.windows.update(aba.windowId, { focused: true }).catch(() => {}); }
  else if (it.serventiaUrl) { await new Promise((ok) => setTimeout(ok, 3000)); await chrome.tabs.update(aba.id, { url }); }
  return aba;
}

async function entregar(it, bytes, minuta, mensagem, html = "", injecao = null, aproximado = "") {
  const avisoHist = (String(mensagem).match(/ ⚠ (?:ATENÇÃO: a minuta NÃO foi gravada|O app não confirmou)[^—]*/) || [""])[0];
  const aviso = (it.refazer ? `Nova versão da minuta feita só com as movimentações ${it.refazer.min} a ${it.refazer.max} (${it.refazer.n} marcada(s)); está no histórico do Studio, ligada à minuta anterior.` + avisoHist : it.modo === "analise" ? "1ª etapa concluída no Studio; a minuta está no histórico do app (use “Prosseguir para 2ª Etapa” lá para a revisão)." + avisoHist : mensagem) + (aproximado && !String(mensagem).includes(aproximado) ? " ⚠ " + aproximado : (it.modo === "analise" && aproximado ? " ⚠ " + aproximado : ""));
  return atualizar(it.id, { estado: "concluido", minuta: minuta || "", minutaHtml: html, tipo: tipoDaMinuta(minuta), aviso, injecao });
}

// Queda do canal com a aba do Studio (aba recarregada ou fechada, extensão recarregada, análise longa): a análise pode ter terminado lá. Antes de gastar cota de novo, procura a minuta pronta no
// Histórico do app; só vale a minuta gravada DEPOIS do início desta tentativa. Tenta agora e mais uma vez depois de 1 minuto (se o app ainda estiver terminando).
const CANAL_PERDIDO = /demorou mais de \d+ minutos|message channel closed|channel closed|asynchronous response|Receiving end does not exist|Extension context invalidated|foi fechada durante|recarregou durante|não terminou em \d+ minutos|não recebeu o pedido/i;
async function recuperarDoStudio(it, rodada, valida) {
  const desde = Math.floor(rodada) - 2000;
  for (let t = 0; t < 2; t++) {
    if (t) await new Promise((ok) => setTimeout(ok, 60000));
    if (!(await valida())) return true;      // o usuário escolheu outro caminho: não mexe mais
    try {
      const m = await lerMinutaAtual(it.processo, desde);
      if (m?.texto) { await entregar(it, await lerPdf(it.id), m.texto, "", m.html || ""); return true; }
    } catch (e) { /* ainda não há minuta pronta (ou a aba do Studio não está aberta) */ }
  }
  return false;
}

// Modo Agaia: não baixa PDF. O Agaia lê o processo do Projudi e devolve a minuta; a esteira a lança no Histórico do Studio (serventia + prompt) e segue.
// Qualquer mensagem do Agaia (arquivado, segredo de justiça, erro…) fica registrada no processo e a fila segue para o próximo.
async function cadastrarAgaia(it, r) {
  const dados = { processo: it.processo, serventia: it.serventia || "", prompt: it.prompt || "", promptAgaia: r.prompt || "", minutaHtml: r.minutaHtml || "", minutaTexto: r.minutaTexto || "", aproximado: r.aproximado || "", origem: r.origem || (it.modo === "ia" ? (SITES_IA[it.iaId]?.nome || "IA externa") : "Agaia") };
  try { const c = await cadastrarNoStudio(dados); return { ok: true, id: c.id }; } catch (err) { return { ok: false, erro: String(err.message || err) }; }
}
async function analisarNoAgaia(it, valida) {
  const andamento = (t) => atualizar(it.id, { aviso: "Agaia: " + t });
  const opcoes = { aoAndamento: andamento, aindaValido: valida };
  if (it.modo === "agaiapdf" || it.modo === "agaiaseeu") {      // segredo de justiça: PDF do Projudi (sem OCR) / SEEU: PDF enviado pelo usuário; em ambos o PDF é anexado no Agaia
    if (it.modo === "agaiaseeu") opcoes.seeu = true;
    const bytes = await lerPdf(it.id);
    if (!bytes || bytes.length < 1000) { await atualizar(it.id, { estado: "erro", erro: "Agaia: o PDF deste processo não está guardado; use “Rodar no Agaia com PDF” de novo (SEEU: envie o PDF outra vez pela importação).", aviso: "A esteira seguiu para o próximo processo." }); return; }
    opcoes.pdf = { bytes, nome: it.pdfNome || "processo.pdf" }; opcoes.aceiteSigilo = !!it.aceiteSigilo;
  }
  // a esteira recarregou ou o computador voltou no meio: se a execução anterior terminou (ou ainda roda) na aba do Agaia, aproveita em vez de rodar de novo
  let r = it.agaiaPedido ? await retomarExecucao(it.agaiaPedido, opcoes).catch(() => null) : null;
  if (!r) r = await executarNoAgaia(it, { ...opcoes, aoIniciar: (ped) => atualizar(it.id, { agaiaPedido: ped }) }).catch((err) => ({ ok: false, erro: String(err.message || err) }));
  if (!(await valida()) || r.cancelado) return;
  if (!r.ok) {
    if (r.sessao) { pausaAte = Date.now() + 3 * 60000; await atualizar(it.id, { estado: "aguardando", erro: "", agaiaPedido: null, aviso: "O Agaia pediu login: entre no Agaia; a fila retoma em 3 minutos." }); return; }
    await atualizar(it.id, { estado: "erro", erro: "Agaia: " + r.erro, agaiaErro: r.erro, sigiloso: !!r.sigiloso || /segredo de justi/i.test(String(r.erro||"")), agaiaPedido: null, aviso: (r.sigiloso || /segredo de justi/i.test(String(r.erro||""))) ? "Segredo de justiça: use o botão “Rodar no Studio” (a extensão baixa o PDF, faz o OCR e analisa no Studio)." : r.indisponivel ? "O Agaia está fora do ar. Tente de novo mais tarde, ou continue pelos botões abaixo (Rodar no Studio ou em outra IA)." : "A esteira seguiu para o próximo processo." });
    return;
  }
  const texto = r.minutaTexto || "";
  // 1º guarda a minuta na própria esteira (nada se perde se o Studio estiver fechado, a internet cair ou o computador desligar); 2º entrega ao Studio
  await atualizar(it.id, { estado: "concluido", erro: "", minuta: texto, minutaHtml: r.minutaHtml || "", tipo: tipoDaMinuta(texto), agaiaPedido: null, cadastroPendente: true, aviso: "Minuta recebida do Agaia; entregando ao Studio…" });
  const c = await cadastrarAgaia(it, r);
  await atualizar(it.id, { cadastroPendente: !c.ok, aviso: c.ok ? "Minuta feita no Agaia e entregue ao Studio: ela é gravada no Histórico em segundo plano (veja o selo 🤖 Agaia no Studio)." + (r.aproximado ? " ⚠ " + r.aproximado : "") : "Minuta feita no Agaia e guardada aqui, mas ainda NÃO entregue ao Studio (" + c.erro + "). A esteira tenta de novo sozinha; enquanto isso use “Copiar minuta”." });
}

// Modo "video": sentença com o vídeo da audiência (qualquer processo que teve audiência de instrução). Os vídeos já foram baixados pela página do lote (IndexedDB); aqui o PDF e os vídeos vão
// ao Studio, que lê os autos, degrava a audiência e redige a sentença (a mesma base do estúdio principal), salvando no Histórico.
async function analisarComVideo(it, valida) {
  const chave = chaveDoProcesso(it.processo), andamento = (t) => atualizar(it.id, { aviso: "Sentença com vídeo: " + t });
  const bytes = await lerPdf(it.id);
  if (!bytes) throw new Error("o PDF deste processo não está mais guardado");
  const { ["midias_" + chave]: m } = await chrome.storage.local.get("midias_" + chave);
  if (!m?.meta?.length) throw Object.assign(new Error("os vídeos deste processo não estão mais guardados: envie o processo de novo para a esteira"), { semRetry: true });
  let prompt; try { prompt = await lerPromptDoStudio(it.prompt); } catch (e) { await atualizar(it.id, { estado: "erro", erro: "Prompt: " + e.message, promptOpcoes: e.opcoes?.length ? e.opcoes : undefined }); return; }
  void guardarPdfDoVideo(chave, bytes).catch(() => {});      // fica guardado (7 dias) para "Refazer a sentença" sem baixar nem degravar de novo
  await chrome.storage.local.set({ ["midias_" + chave]: { ...m, processo: it.processo, serventia: it.serventia || "", prompt: it.prompt || "", pdfNome: it.pdfNome || "" } });
  // degravação já feita para estes MESMOS vídeos: reaproveita (não envia os vídeos nem gasta a IA de novo)
  const assin = m.meta.map((x) => x.nome + ":" + x.tamanho).join("|"), cache = (await chrome.storage.local.get("degr_" + chave))["degr_" + chave];
  const degravacaoPronta = cache?.assin === assin && cache.texto ? cache.texto : "";
  if (degravacaoPronta) await atualizar(it.id, { aviso: "Sentença com vídeo: reaproveitando a degravação já feita (os vídeos não serão enviados de novo)." });
  const quadro = await quadroDoProcesso(await textoDoPdf(bytes, { simples: true }).catch(() => it.processo));      // o número completo (CNJ) vem do texto do PDF: o da fila pode estar abreviado      // movimentações lidas da tela do processo (todas, inclusive as sem arquivo): sem isto o relatório parava na última movimentação com arquivo
  const videos = [];
  for (let i = 0; i < (degravacaoPronta ? 0 : m.meta.length); i++) { const b = await lerMidia(chave, i); if (!b) throw Object.assign(new Error(`o vídeo ${i + 1} (${m.meta[i].nome}) não está mais guardado: envie o processo de novo`), { semRetry: true }); videos.push({ nome: m.meta[i].nome, tipo: m.meta[i].tipo, bytes: b }); }
  const t0 = Date.now();
  const r = await sentencaComVideoNoStudio({ pdf: { nome: it.pdfNome || `${chave || "autos"}.pdf`, tipo: "application/pdf", bytes }, videos }, { processo: it.processo, serventia: it.serventia || "", promptTitulo: prompt.titulo || it.prompt || "", promptTexto: prompt.texto, degravacaoPronta, quadro, andamento, aindaValido: valida });
  if (!(await valida()) || r.cancelado) return;
  reportarSaude("esteira", r.ok ? "info" : "erro", r.ok ? "Sentença com vídeo concluída" : "Sentença com vídeo: " + r.erro, { modo: "video", videos: videos.length, ms: Date.now() - t0 }, true);
  if (!r.ok) {
    if (r.transcricao && !degravacaoPronta) await chrome.storage.local.set({ ["degr_" + chave]: { assin, texto: r.transcricao, em: Date.now() } });      // a degravação (parte cara) fica guardada: 'Tentar de novo' refaz só o motor principal
    await atualizar(it.id, { estado: "erro", erro: r.erro, tentativas: r.semRetry ? 9 : undefined, aviso: "A esteira seguiu para o próximo processo." }); return;
  }
  await atualizar(it.id, { estado: "concluido", erro: "", minuta: r.minuta, minutaHtml: "", tipo: tipoDaMinuta(r.minuta), cadastroPendente: false, aviso: `Sentença feita com o vídeo da audiência (${m.meta.length} mídia(s)) e salva no Histórico do Studio.` + (r.aviso ? " ⚠ " + r.aviso : "") });
  if (r.transcricao) await chrome.storage.local.set({ ["degr_" + chave]: { assin, texto: r.transcricao, em: Date.now() } });      // a degravação fica guardada: refazer a sentença não degrava de novo
  void desenharGuardados();
}

// Modo IA externa (ChatGPT/Gemini/Claude): usa o PDF baixado (com OCR), anexa na IA, cola o prompt do Studio, espera a minuta e a lança no Histórico do Studio.
async function analisarNaIaExterna(it, valida) {
  const nomeIa = SITES_IA[it.iaId]?.nome || "IA externa";
  const andamento = (t) => atualizar(it.id, { aviso: `${nomeIa}: ` + t });
  const bytes = await lerPdf(it.id);
  if (!bytes) throw new Error("o PDF deste processo não está mais guardado");
  if (!SITES_IA[it.iaId]) { await atualizar(it.id, { estado: "erro", erro: "IA externa não escolhida: escolha ChatGPT, Gemini ou Claude no painel e envie de novo." }); return; }
  let promptTexto = "";
  try { promptTexto = (await lerPromptDoStudio(it.prompt)).texto; } catch (e) { await atualizar(it.id, { estado: "erro", erro: "Prompt: " + e.message, promptOpcoes: e.opcoes?.length ? e.opcoes : undefined }); return; }
  const t0 = Date.now();
  const r = await executarNaIa(it, { id: it.iaId, bytes, promptTexto, aoAndamento: andamento, aindaValido: valida });
  if (!(await valida()) || r.cancelado) return;
  // painel Calibragem → Extensão: sucesso e falha de cada IA externa (sem texto de processo; o servidor ainda mascara números)
  reportarSaude("ia-externa", r.ok ? "info" : r.sessao ? "aviso" : "erro", r.ok ? `${nomeIa}: minuta recebida` : `${nomeIa}: ${r.erro}`, { ia: it.iaId, ok: !!r.ok, ms: Date.now() - t0 }, true);
  if (!r.ok) {
    if (r.sessao) { pausaAte = Date.now() + 3 * 60000; await atualizar(it.id, { estado: "aguardando", erro: "", aviso: r.erro + ". A fila retoma em 3 minutos." }); return; }
    await atualizar(it.id, { estado: "erro", erro: `${nomeIa}: ` + r.erro, aviso: "A esteira seguiu para o próximo processo.", tentativas: r.semRetry ? 9 : undefined });
    return;
  }
  await concluirMinutaDaIa(it, nomeIa, r);
}
/** A minuta chegou da IA externa (pela esteira ou pelo botão "Buscar a minuta na aba"): guarda na linha e entrega ao Studio. */
async function concluirMinutaDaIa(it, nomeIa, r) {
  const texto = r.minutaTexto;
  await atualizar(it.id, { estado: "concluido", erro: "", capturando: false, minuta: texto, minutaHtml: r.minutaHtml || "", tipo: tipoDaMinuta(texto), cadastroPendente: true, aviso: `Minuta recebida de ${nomeIa}; entregando ao Studio…` });
  const c = await cadastrarAgaia(it, r);
  await atualizar(it.id, { cadastroPendente: !c.ok, aviso: c.ok ? `Minuta feita no ${nomeIa} e entregue ao Studio: ela é gravada no Histórico em segundo plano (selo 🤖 ${nomeIa}).` : `Minuta feita no ${nomeIa} e guardada aqui, mas ainda NÃO entregue ao Studio (${c.erro}). A esteira tenta de novo sozinha; enquanto isso use “Copiar minuta”.` });
}
let ultimaTentativaCadastro = 0;
async function cadastrosPendentes(lista) {      // o Studio estava fechado/ocupado quando a minuta chegou: tenta lançar de novo (no máximo a cada 60 s)
  const pend = lista.filter((i) => (i.modo === "agaia" || i.modo === "agaiapdf" || i.modo === "agaiaseeu" || i.modo === "ia") && i.estado === "concluido" && i.cadastroPendente && i.minuta);
  if (!pend.length || Date.now() - ultimaTentativaCadastro < 60000) return;
  ultimaTentativaCadastro = Date.now();
  for (const it of pend) {
    const c = await cadastrarAgaia(it, { minutaHtml: it.minutaHtml, minutaTexto: it.minuta });
    if (c.ok) await atualizar(it.id, { cadastroPendente: false, aviso: "Minuta feita no Agaia e entregue ao Studio: ela é gravada no Histórico em segundo plano (veja o selo 🤖 Agaia no Studio)." });
    else await atualizar(it.id, { aviso: "Minuta feita no Agaia; falta lançar no Histórico do Studio (" + c.erro + "). A esteira tenta de novo." });
  }
}

async function analisar(it) {
  const intervaloTurbo = () => { if (it.modo === "turbo") pausaTurboAte = Date.now() + 60000; };      // janela de 1 minuto da cota gratuita: o próximo Turbo espera 60 s
  const rodada = Date.now() + Math.random();
  await atualizar(it.id, { estado: "analisando", erro: "", rodada });
  const valida = async () => (await todos()).find((x) => x.id === it.id)?.rodada === rodada;      // o usuário pode ter escolhido outro caminho no meio
  try {
    if (it.modo === "agaia" || it.modo === "agaiapdf" || it.modo === "agaiaseeu") return await analisarNoAgaia(it, valida);
    if (it.modo === "ia") return await analisarNaIaExterna(it, valida);
    if (it.modo === "video") return await analisarComVideo(it, valida);
    const bytes = await lerPdf(it.id);
    if (!bytes) throw new Error("o PDF deste processo não está mais guardado");
    if (!it.prompt && (it.modo === "analise" || it.modo === "lupa" || it.modo === "ia")) throw Object.assign(new Error("este processo está sem prompt definido: a esteira não usa o prompt que estiver ativo no Studio (poderia ser de outra matéria). Defina o prompt da serventia no painel e envie de novo."), { semRetry: true });
    const { esteiraConfig = {} } = await chrome.storage.sync.get("esteiraConfig");
    const comTexto = it.modo === "turbo" || ((it.modo === "analise" || (it.modo === "lupa" && it.minutaAssessor)) && esteiraConfig.entrada === "txt");      // Turbo: sempre texto; esteira principal: conforme a escolha do usuário (txt ou PDF)
    let texto = comTexto ? await textoDoPdf(bytes, { simples: true }) : "";
    if (texto) texto = (await quadroDoProcesso(texto)) + texto;      // movimentações da tela do processo (incluem as sem arquivo)
    if (comTexto && texto.replace(/\[Página \d+(?: de \d+)?[^\]]*\]|\s/g, "").length < 200) throw new Error("não consegui extrair texto do PDF (o OCR pode não ter funcionado)");
    const comAta = it.modo === "mesa" ? !!(await chrome.storage.local.get("pauta_mesa_ata")).pauta_mesa_ata : false;
    const r = await analisarNoStudio(bytes, { retomar: !!it.cotaVezes, comAta, nome: it.pdfNome, prompt: it.prompt, modo: it.modo, tipo: "", processo: it.processo, minuta: it.minutaAssessor, motivoMinuta: it.motivoMinuta, dicas: it.serventia || "", audData: it.audData || "", audHora: it.audHora || "", texto, ate1: it.modo === "analise", refazer: it.refazer || null });
    if (!(await valida())) return;
    if (r.gigante) { await atualizar(it.id, { estado: "gigante", erro: "", jobId: r.jobId, aviso: "Processo gigante: o Studio lê os autos em lotes, em segundo plano (pode levar de minutos a horas). A fila segue; a minuta será pega no Histórico quando ficar pronta." }); return; }
    intervaloTurbo();
    await entregar(it, bytes, r.minuta, r.mensagem, r.minutaHtml || "", r.injecao || null, r.aproximado || "");
  } catch (e) {
    intervaloTurbo();
    if ((it.modo === "analise" || it.modo === "turbo") && it.processo && CANAL_PERDIDO.test(e.message || "") && await valida()) {
      await atualizar(it.id, { aviso: "A conexão com a aba do Studio caiu; procurando a minuta pronta no Histórico do app antes de tentar de novo…" });
      if (await recuperarDoStudio(it, rodada, valida)) return;
    }
    if (await valida()) {      // esteira automática: uma nova tentativa sozinha antes de dar erro (o app pode ter estado ocupado)
      const cur = (await todos()).find((x) => x.id === it.id) || it;
      const cota = /cota|quota|429|rate limit|\b503\b|alta demanda|pico tempor|resposta do servidor incompleta|formato inv[áa]lido|reiniciando/i.test(e.message || "");
      if (cota && !e.opcoes?.length) {      // cota gratuita da IA esgotada: espera (a janela renova) e tenta o MESMO processo de novo; depois, não trava a fila
        const n = (cur.cotaVezes || 0) + 1;
        pausaAte = Date.now() + 3 * 60000;
        if (n <= 2) await atualizar(it.id, { estado: "aguardando", erro: "", cotaVezes: n, aviso: `IA indisponível (cota ou sobrecarga do Google): a fila espera 3 minutos e tenta de novo (${n}/2).` });
        else await atualizar(it.id, { estado: "erro", erro: it.modo === "turbo" ? "O PDF/texto extraído é grande demais para o Módulo Turbo (ou a cota da IA esgotou). Use a “análise normal” para este processo." : "A IA não respondeu (cota gratuita esgotada ou sobrecarga do Google) mesmo após esperar. Tente de novo mais tarde ou peça a liberação da Chave Nativa.", grande: it.modo === "turbo", aviso: "A fila segue para o próximo processo depois de 3 minutos." });
      } else if (e.semRetry) await atualizar(it.id, { estado: "erro", erro: e.message, grande: !!e.grande });      // autos grandes demais para o Turbo / Mesa travada: não repete e a fila segue
      else if (e.opcoes?.length) await atualizar(it.id, { estado: "erro", erro: e.message, promptOpcoes: e.opcoes, promptEscolhido: "" });      // sem prompt da matéria: o usuário escolhe na lista do Studio
      else if ((cur.tentativas || 0) < 1) await atualizar(it.id, { estado: "aguardando", erro: "", tentativas: (cur.tentativas || 0) + 1, aviso: "nova tentativa automática após: " + e.message });
      else await atualizar(it.id, { estado: "erro", erro: e.message });
    }
  }
}

// A análise já tinha terminado no Studio (a extensão foi recarregada ou a tela travou): usa a minuta que está lá, sem analisar de novo.
async function usarMinutaDoStudio(it) {
  await atualizar(it.id, { estado: "analisando", erro: "", rodada: Date.now() + Math.random() });
  try { const m = await lerMinutaAtual(it.processo, (it.criadoEm || 0) - 60000); await entregar(it, await lerPdf(it.id), m.texto, "", m.html); }      // só vale minuta gravada depois deste pedido
  catch (e) { await atualizar(it.id, { estado: "erro", erro: e.message }); }
}

async function cadastrar(it) {         // conferência terminada: pega o texto final (com negrito/itálico/citações) e leva ao Projudi
  let texto = it.minuta, html = it.minutaHtml || "", aviso = it.aviso || "";
  try {
    const lido = it.docUrl && it.via === "api" ? await lerDocumento(it.docUrl.match(/\/d\/([\w-]+)/)?.[1]) : null;
    if (lido) { texto = lido.texto; html = lido.html; aviso = ""; }
    else if (it.docUrl) aviso = "Sem o login do Google não dá para ler as suas correções do Docs: será usada a minuta original do Studio.";
  } catch (e) { aviso = "Não consegui ler o Google Docs (" + e.message + "): será usada a minuta original do Studio."; }
  const aba = await abrirNoProjudi(it, absoluta(it.urlPre || it.url), true);
  await atualizar(it.id, { estado: "cadastrando", textoFinal: texto, htmlFinal: html, aviso, projudiTab: aba.id, inserido: false });
}

// Gigante concluído no Studio: a minuta foi gerada AGORA, a pedido desta fila, e o app já a salvou no Histórico. A esteira pega essa minuta (a mais recente DESTE processo, gravada depois
// do pedido: nunca uma antiga) e a entrega como qualquer outra: aparece na lista, com “Copiar minuta”, e segue para a conferência. Só faz isso com o Studio livre, porque carregar a minuta
// do Histórico muda a tela do app; se a leitura falhar, marca como concluído e avisa onde está a minuta.
async function concluirGigante(it, j) {
  const quando = new Date().toLocaleString("pt-BR");
  try {
    const m = await lerMinutaAtual(it.processo || j?.processo || "", (it.criadoEm || 0) - 60000);
    if (m?.texto) { await entregar(it, await lerPdf(it.id), m.texto, "", m.html || ""); return; }
  } catch (e) { /* cai no aviso abaixo */ }
  await atualizar(it.id, { estado: "concluido", erro: "", minuta: "", minutaHtml: "", aviso: `Processo gigante concluído no Studio em ${quando}: a minuta nova foi salva no Histórico do app, mas a esteira não conseguiu trazê-la. Use “Usar a minuta do Studio” ou abra-a no Histórico.` });
}

// Processos gigantes lidos em lotes pelo Studio: confere o andamento (no máximo a cada 45 s) e, quando a minuta fica pronta no Histórico, segue o fluxo normal.
let ultimaConsultaGigantes = 0;
async function verificarGigantes(lista) {
  const gig = lista.filter((i) => i.estado === "gigante");
  if (!gig.length || Date.now() - ultimaConsultaGigantes < 45000) return;
  ultimaConsultaGigantes = Date.now();
  let jobs; try { jobs = await consultarGigantes(); } catch (e) { return; }      // aba do Studio fechada: tenta de novo depois
  const studioLivre = !lista.some((i) => ["analisando", "recebida", "pausado"].includes(i.estado));
  const aguardarLivre = async (it) => { await atualizar(it.id, { aviso: "Processo gigante concluído no Studio: a minuta será trazida para cá assim que o Studio ficar livre (a análise em andamento termina antes)." }); };
  for (const it of gig) {
    const j = jobs.find((x) => x.id === it.jobId);
    if (!j) { await atualizar(it.id, { aviso: "Processo gigante: não encontrei o trabalho no Studio (a aba foi recarregada?). Use “Usar a minuta do Studio” se ele já terminou, ou envie de novo." }); continue; }
    if (j.uniao) {      // processo muito grande: lido em partes; a minuta única só sai depois que o Studio une as partes
      const unida = jobs.find((x) => x.serie === it.jobId);
      if (unida) {
        if (unida.status === "concluido") { if (studioLivre) await concluirGigante(it, unida); else await aguardarLivre(it); }
        else if (unida.status === "erro" || unida.status === "cancelado") await atualizar(it.id, { estado: "erro", erro: "A união das partes parou no Studio: " + (unida.erro || "veja o painel “Gigantes” do app e clique em Retomar.") });
        else await atualizar(it.id, { aviso: "Processo muito grande: as partes já foram lidas e o Studio está redigindo a minuta única (" + unida.status + ")." });
        continue;
      }
      if (j.status === "erro" || j.status === "cancelado") await atualizar(it.id, { estado: "erro", erro: "Uma parte do processo parou no Studio: " + (j.erro || "veja o painel “Gigantes” do app e clique em Retomar.") });
      else await atualizar(it.id, { aviso: "Processo muito grande: o Studio lê as partes uma de cada vez (primeira: " + j.status + ") e depois une tudo numa só minuta." });
      continue;
    }
    if (j.status === "concluido") { if (studioLivre) await concluirGigante(it, j); else await aguardarLivre(it); }
    else if (j.status === "erro" || j.status === "cancelado") await atualizar(it.id, { estado: "erro", erro: j.status === "cancelado" ? "O processo gigante foi cancelado no Studio." : "O processo gigante parou no Studio: " + (j.erro || "veja o painel “Gigantes” do app e clique em Retomar.") });
  }
}

async function passo() {
  if (!dono || ocupado) return;
  if (Date.now() < pausaAte) return;      // espera combinada (cota da IA esgotada)
  ocupado = true;
  try {
    const lista = await todos();
    await verificarGigantes(lista);
    await cadastrosPendentes(lista);
    const rec = lista.find((i) => i.estado === "recebida");      // minuta enviada pelo botão da tela do Studio
    if (rec) { await atualizar(rec.id, { estado: "analisando", rodada: Date.now() + Math.random() }); try { await entregar(rec, await lerPdf(rec.id), rec.minutaRecebida, "", rec.htmlRecebido || ""); } catch (e) { await atualizar(rec.id, { estado: "erro", erro: e.message }); } return; }
    const conf = lista.find((i) => i.estado === "conferido");
    if (conf) { await cadastrar(conf); return; }
    // Um por vez NO STUDIO. No modo contínuo (padrão) o próximo começa assim que o Studio devolve a conclusão; a conferência/lançamento no Projudi
    // do anterior segue em paralelo. Com o modo contínuo desligado, espera o processo anterior ser concluído.
    const { esteiraConfig = {} } = await chrome.storage.sync.get("esteiraConfig");
    const bloqueiam = ["analisando", "recebida", "pausado"];      // só bloqueia enquanto o Studio trabalha (ou o usuário precisa escolher); conferência/Projudi não seguram a fila
    if (lista.some((i) => bloqueiam.includes(i.estado))) return;
    if ((await chrome.storage.local.get("filaPausada")).filaPausada) return;      // pausada pelo celular: não começa processo novo (o que já estava rodando termina)
    const prox = lista.find((i) => i.estado === "aguardando");
    if (prox && prox.modo === "turbo" && Date.now() < pausaTurboAte) return;      // janela de 1 minuto da cota gratuita entre dois Turbo
    if (prox) await analisar(prox);
  } finally { ocupado = false; desenhar(); }
}

// Fecha as abas (ou janelas) que a esteira abriu para este processo: Google Docs, PDF e Projudi.
async function fecharAbas(it) {
  const a = it?.abas; if (!a) return;
  for (const id of [a.doc, a.pdf, a.projudi].filter(Boolean)) await (a.janelas && id !== a.projudi ? chrome.windows.remove(id) : chrome.tabs.remove(id)).catch(() => {});
}


// Fila no celular: a aba dona da esteira deixa em chrome.storage.local um RESUMO (só números, estados e o último erro curto, sem número de processo);
// o script do Studio o entrega ao app, que o mostra em "Minha fila" e avisa o celular quando a fila conclui, para por erro, pede login ou o computador cala.
let ultimoResumo = 0;
async function publicarResumo(forcar) {
  if (!dono || (!forcar && Date.now() - ultimoResumo < 5000)) return;
  ultimoResumo = Date.now();
  try {
    const lista = await todos(), conta = (...est) => lista.filter((i) => est.includes(i.estado)).length, pausadaManual = !!(await chrome.storage.local.get("filaPausada")).filaPausada;
    const ativo = lista.find((i) => ["analisando", "gigante"].includes(i.estado)) || lista.find((i) => i.estado === "aguardando") || lista[lista.length - 1];
    const erro = [...lista].reverse().find((i) => i.estado === "erro");
    const login = lista.find((i) => i.estado === "aguardando" && /pediu login|verifica[çc][ãa]o humana|captcha/i.test(i.aviso || ""));
    await chrome.storage.local.set({ filaResumo: {
      total: lista.length, aguardando: conta("aguardando"), analisando: conta("analisando", "gigante", "recebida", "conferido", "cadastrando"), concluidos: conta("concluido"), erros: conta("erro"), pausados: conta("pausado", "conferindo"),
      modo: ativo?.modo || "", ia: ativo?.modo === "ia" ? (SITES_IA[ativo.iaId]?.nome || "") : "", pausa: login ? String(login.aviso).slice(0, 160) : "", ultimoErro: erro ? String(erro.erro || "").slice(0, 200) : "", versao: chrome.runtime.getManifest().version, pausadaManual, ts: Date.now() } });
  } catch (e) { /* sem armazenamento: segue sem avisar o celular */ }
}
setInterval(publicarResumo, 20000); setTimeout(publicarResumo, 4000);

// Comandos vindos do celular (Minha fila): o app deixa em chrome.storage.local `filaComandos`; a aba dona executa, anota o resultado em `filaComandosResultado`
// e o script do Studio o devolve ao app. Só 3 comandos, todos reversíveis: pausar, retomar e repetir os que deram erro. Nada é apagado nem lançado no Projudi.
async function processarComandos() {
  if (!dono) return;
  try {
    const { filaComandos = [], filaComandosFeitos = [], filaComandosResultado = [] } = await chrome.storage.local.get(["filaComandos", "filaComandosFeitos", "filaComandosResultado"]);
    const novos = filaComandos.filter((c) => c && c.id && !filaComandosFeitos.includes(c.id) && Date.now() - (c.ts || 0) < 10 * 60_000);
    if (!novos.length) return;
    const res = [];
    for (const c of novos) {
      let ok = true, mensagem = "";
      if (c.tipo === "pausar") { await chrome.storage.local.set({ filaPausada: { ts: Date.now(), por: "celular" } }); mensagem = "Fila pausada. O processo em andamento termina; nenhum novo começa."; }
      else if (c.tipo === "retomar") { await chrome.storage.local.remove("filaPausada"); mensagem = "Fila retomada."; setTimeout(passo, 500); }
      else if (c.tipo === "repetir_erros") {
        const erros = (await todos()).filter((i) => i.estado === "erro");
        for (const i of erros) await atualizar(i.id, { estado: "aguardando", erro: "", rodada: 0, tentativas: 0, cotaVezes: 0, aviso: "refeito por comando do celular" });
        mensagem = erros.length ? `${erros.length} processo(s) com erro voltaram para a fila.` : "Não havia processo com erro."; pausaAte = 0; desenhar(); setTimeout(passo, 500);
      } else { ok = false; mensagem = "comando desconhecido"; }
      res.push({ id: c.id, ok, mensagem, ts: Date.now() });
    }
    await chrome.storage.local.set({ filaComandosFeitos: [...filaComandosFeitos, ...novos.map((c) => c.id)].slice(-60), filaComandosResultado: [...filaComandosResultado, ...res].slice(-20) });
    ultimoResumo = 0; void publicarResumo(true);
  } catch (e) { /* sem armazenamento: nada a fazer */ }
}
setInterval(processarComandos, 4000); try { chrome.storage.onChanged.addListener((c, a) => { if (a === "local" && c.filaComandos) void processarComandos(); }); } catch (e) { /* sem ouvinte */ }


let redesenharDepois = false;
async function desenhar(forcar = false) {
  // enquanto a pessoa escolhe numa lista (prompt), não redesenha a tabela: refazer o HTML fechava a lista sozinha; redesenha assim que ela sair do campo
  const ativo = document.activeElement;
  if (!forcar && ativo && ativo.tagName === "SELECT" && ativo.closest && ativo.closest("#linhas")) { redesenharDepois = true; return; }
  void publicarResumo();
  const lista = await todos();
  $("linhas").innerHTML = lista.length ? lista.map((it, n) => {
    const b = [];
    if (it.estado === "aguardando") b.push(`<button data-a="pular" data-id="${it.id}">Pular</button>`);
    if (["aguardando", "pausado", "erro", "analisando"].includes(it.estado)) b.push(`<button data-a="usar" data-id="${it.id}" title="A extensão procura o número do processo no Histórico Local do Studio, carrega a minuta e a leva ao Google Docs, sem analisar de novo">Usar a minuta do Studio (busca no Histórico)</button>`);
    if (it.estado === "erro" && it.modo === "ia" && SITES_IA[it.iaId]) b.push(`<button data-a="capturar-ia" data-id="${it.id}" ${it.capturando ? "disabled" : ""} style="background:#1d4ed8;color:#fff;font-weight:700;padding:6px 10px;border:2px solid #1e3a8a;border-radius:8px;cursor:pointer" title="A minuta pode estar pronta (ou ainda sendo escrita) na conversa aberta. A extensão olha essa conversa, espera a IA terminar e traz a minuta para o Studio, sem enviar nada de novo">${it.capturando ? "Procurando a minuta…" : "🔎 Buscar a minuta na aba do " + esc(SITES_IA[it.iaId].nome)}</button>`);
    if (it.sigiloso && it.estado === "erro") b.push(`<button data-a="sigilo-studio" data-id="${it.id}" style="background:#b45309;color:#fff;font-weight:700;padding:6px 10px;border:2px solid #78350f;border-radius:8px;cursor:pointer" title="O Agaia não roda processo em segredo de justiça. A extensão procura este processo na unidade, baixa o PDF, faz o OCR e extrai o texto, e a análise roda no Studio.">🔒 Segredo de justiça — Rodar no Studio</button>`);
    if (it.sigiloso && it.estado === "erro") b.push(`<button data-a="sigilo-agaia" data-id="${it.id}" style="background:#7c2d12;color:#fff;font-weight:700;padding:6px 10px;border:2px solid #431407;border-radius:8px;cursor:pointer" title="A extensão baixa o PDF deste processo no Projudi (sem OCR), volta ao Agaia, confirma as declarações que VOCÊ autorizar, anexa o PDF, executa e recolhe a minuta.">🔒 Segredo de justiça — Rodar no Agaia com PDF</button>`);
    if (["pausado", "erro", "analisando"].includes(it.estado)) b.push(`<button data-a="repetir" data-id="${it.id}">${it.estado === "erro" ? "Tentar de novo" : "Analisar de novo"}</button>`);
    if (it.estado === "conferindo") { if (it.docUrl) b.push(`<a href="${esc(it.docUrl)}" target="_blank">Abrir Docs</a>`); b.push(`<button data-a="conferido" data-id="${it.id}">✔ Terminei a conferência — cadastrar no Projudi</button>`); }
    if (it.estado === "cadastrando") { b.push(`<button data-a="projudi" data-id="${it.id}">Abrir o processo</button>`, `<button data-a="concluir" data-id="${it.id}">✔ Lancei no Projudi — próximo processo</button>`); }
    if (it.estado === "erro" && ["agaia", "agaiapdf", "agaiaseeu", "ia"].includes(it.modo) && !it.sigiloso) {      // segredo de justiça já tem os botões próprios (Studio e Agaia com PDF)
      const de = it.modo === "ia" ? (SITES_IA[it.iaId]?.nome || "IA externa") : "Agaia";
      const outras = Object.entries(SITES_IA).filter(([k]) => !(it.modo === "ia" && it.iaId === k)).map(([k, v]) => `<option value="${k}">${esc(v.nome)}</option>`).join("");
      const prompts = listaPrompts.map((x) => `<option value="${esc(x)}"${x === it.promptAlt ? " selected" : ""}>${esc(x)}</option>`).join("");
      b.push(`<div data-testid="alt-caminho" style="margin-top:6px;padding:6px 8px;border:1px dashed #64748b;border-radius:8px"><b>Deu erro (${esc(de)})? Continue daqui:</b><br>`
        + `<button data-a="rodar-studio" data-id="${it.id}" style="background:#0f766e;color:#fff;font-weight:700;padding:6px 10px;border:2px solid #115e59;border-radius:8px;cursor:pointer" title="A extensão baixa o PDF com OCR e a análise roda no Studio, na mesma linha">▶ Rodar no Studio</button> `
        + `<select data-a-ia="${it.id}" title="Baixa o PDF com OCR e roda na IA escolhida (a extensão pede a autorização do site se faltar)"><option value="">🌐 Rodar em outra IA…</option>${outras}</select> `
        + `<select data-pp="${it.id}" title="Prompts do seu cadastro no Studio. Em “automático”, vale o prompt da serventia; se não houver, a extensão pergunta."><option value="">Prompt: automático (cadastro do Studio)</option>${prompts}</select></div>`);
    }
    if (it.estado === "erro" && it.promptOpcoes?.length) b.push(`<br><select data-a-sel="${it.id}" title="Prompts que existem no seu Studio"><option value="">— escolha o prompt —</option>${it.promptOpcoes.map((o) => `<option value="${esc(o)}"${o === it.promptEscolhido ? " selected" : ""}>${esc(o)}</option>`).join("")}</select> <button data-a="usarprompt" data-id="${it.id}">Usar este prompt e analisar</button>`);
    if (it.estado === "erro" && it.grande) b.push(`<button data-a="normal" data-id="${it.id}" title="Refaz este processo na análise normal do Studio (PDF/texto completo, sem o Módulo Turbo)">Usar a análise normal</button>`);
    if (it.modo === "mesa" && it.estado === "concluido") b.push(`<label title="Inclui esta audiência na pauta (formato do modelo do gabinete)"><input type="checkbox" data-pauta="${it.id}" ${it.pautaSel ? "checked" : ""}> incluir na pauta</label>`);
    if (it.estado === "concluido" && (it.minuta || "").length > 200) b.push(`<button data-a="copiar" data-id="${it.id}" title="Copia a minuta que a extensão recebeu do Studio (garantia caso ela não apareça no Histórico do app)">📋 Copiar minuta</button>`);
    b.push(`<button data-a="excluir" data-id="${it.id}" title="Tira este processo da fila e apaga o PDF guardado (não mexe no Projudi nem nos arquivos já baixados)">🗑 Excluir</button>`);
    return `<tr><td>${n + 1}</td><td>${esc(it.processo)}<br><small>${esc(it.tipo || "")}</small></td><td class="e-${it.estado}">${esc((it.modo === "agaia" || it.modo === "agaiapdf" || it.modo === "agaiaseeu") && it.estado === "analisando" ? (it.modo === "agaiaseeu" ? "rodando no Agaia (SEEU, com o PDF)…" : it.modo === "agaiapdf" ? "rodando no Agaia (com o PDF)…" : "rodando no Agaia…") : it.modo === "ia" && it.estado === "analisando" ? `rodando no ${SITES_IA[it.iaId]?.nome || "IA externa"}…` : it.modo === "ia" && it.estado === "concluido" ? `concluído (${SITES_IA[it.iaId]?.nome || "IA externa"})` : (it.modo === "agaia" || it.modo === "agaiapdf") && it.estado === "concluido" ? "concluído (Agaia)" : ROTULO[it.estado] || it.estado)}${it.erro ? "<br>" + esc(it.erro) : ""}${it.aviso ? `<br><small>${esc(it.aviso)}</small>` : ""}${it.injecao ? (it.injecao.estado === "vermelha" ? `<br><small class="inj-v">🚨 Prompt injection nos autos: ${esc(it.injecao.texto || "confira a tarja vermelha no app")}</small>` : `<br><small class="inj-ok">✅ Prompt injection: nada encontrado</small>`) : ""}</td><td>${b.join(" ")}</td></tr>`;
  }).join("") : '<tr><td colspan="4">Fila vazia.</td></tr>';
  const conc = lista.filter((x) => x.modo === "mesa" && x.estado === "concluido"), marc = conc.filter((x) => x.pautaSel);
  $("pautaBarra").style.display = conc.length ? "" : "none"; $("pautaN").textContent = marc.length; $("pautaGerar").disabled = !marc.length;
  $("status").textContent = dono ? "" : "Outra aba da esteira já está em execução; esta mostra apenas o andamento.";
}

$("linhas").addEventListener("change", async (ev) => { const pc = ev.target.closest("input[data-pauta]"); if (pc) { await atualizar(pc.dataset.pauta, { pautaSel: pc.checked }); desenhar(); return; } const s = ev.target.closest("select[data-a-sel]"); if (s) await atualizar(s.dataset.aSel, { promptEscolhido: s.value }); const pp = ev.target.closest("select[data-pp]"); if (pp) await atualizar(pp.dataset.pp, { promptAlt: pp.value }); const ia = ev.target.closest("select[data-a-ia]"); if (ia && ia.value) { const v = ia.value, id = ia.dataset.aIa; ia.value = ""; ia.blur(); redesenharDepois = false; await rodarEm(id, v, document.querySelector(`select[data-pp="${id}"]`)?.value || ""); } });
$("linhas").addEventListener("click", async (ev) => {
  const b = ev.target.closest("button[data-a]"); if (!b) return;
  const id = b.dataset.id, a = b.dataset.a;
  if (a === "copiar") {      // a minuta fica guardada aqui mesmo que o Histórico do app não a tenha gravado
    const it = (await todos()).find((x) => x.id === id); const txt = (it && it.minuta) || "";
    try { await navigator.clipboard.writeText(txt); b.textContent = "✔ Copiada"; } catch (e) { const ta = document.createElement("textarea"); ta.value = txt; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); b.textContent = "✔ Copiada"; }
    setTimeout(() => { b.textContent = "📋 Copiar minuta"; }, 2500); return;
  }
  if (a === "excluir") {
    if (!confirm("Excluir este processo da esteira? O PDF guardado pela extensão será apagado (o arquivo baixado no computador e o Projudi não são afetados).")) return;
    await fecharAbas((await todos()).find((x) => x.id === id));
    await atualizar(id, { rodada: 0 });      // se estiver analisando, o resultado que chegar depois é descartado
    await remover([id]); desenhar(); passo(); return;
  }
  if (a === "usarprompt") {
    const it = (await todos()).find((x) => x.id === id), v = document.querySelector(`select[data-a-sel="${id}"]`)?.value || it?.promptEscolhido || "";
    if (!v) { alert("Escolha um prompt da lista."); return; }
    await atualizar(id, { prompt: v, promptOpcoes: null, promptEscolhido: "", estado: "aguardando", erro: "", rodada: 0, tentativas: 0 });
  }
  if (a === "pular") { await fecharAbas((await todos()).find((x) => x.id === id)); await atualizar(id, { estado: "pulado" }); }
  if (a === "capturar-ia") {
    const it = (await todos()).find((x) => x.id === id); if (!it || it.modo !== "ia" || !SITES_IA[it.iaId] || it.capturando) return;
    const nomeIa = SITES_IA[it.iaId].nome;
    await atualizar(id, { capturando: true, aviso: `${nomeIa}: olhando a conversa aberta…` });
    const r = await capturarDaAba(it.iaId, { aoAndamento: (t) => atualizar(id, { aviso: `${nomeIa}: ` + t }) });
    if (!r.ok) { await atualizar(id, { capturando: false, erro: `${nomeIa}: ` + r.erro, aviso: "Nada foi enviado de novo. Quando a minuta estiver pronta na aba do " + nomeIa + ", clique outra vez em “Buscar a minuta”." }); return; }
    await concluirMinutaDaIa(it, nomeIa, r); return;
  }
  if (a === "repetir") await atualizar(id, { estado: "aguardando", erro: "", rodada: 0 });
  if (a === "normal") await atualizar(id, { modo: "analise", estado: "aguardando", erro: "", grande: false, cotaVezes: 0, tentativas: 0, rodada: 0, aviso: "refeito na análise normal" });
  if (a === "sigilo-studio") { await rodarEm(id, "studio", ""); return; }
  if (a === "rodar-studio") { await rodarEm(id, "studio", document.querySelector(`select[data-pp="${id}"]`)?.value || ""); return; }
  if (a === "sigilo-agaia") {
    const it = (await todos()).find((x) => x.id === id); if (!it) return;
    if (!it.url) { alert("Esta linha não guardou o endereço do processo no Projudi. Envie o processo de novo pelo Painel."); return; }
    if (!it.prompt) { alert("Esta linha está sem o nome do prompt no Agaia. Defina “Prompt no Agaia” na tabela de serventias do Painel."); return; }
    if (!(await confirmarDeclaracoes(it))) return;      // as declarações do Agaia são do usuário: só segue com o aceite dele
    const { automacao = {} } = await chrome.storage.sync.get("automacao");
    const chaveServ = Object.keys(automacao).find((x) => String(x).trim().toLowerCase() === String(it.serventia || "").trim().toLowerCase());
    const hoje = new Date().toISOString().slice(0, 10), lote = String(Date.now());
    const limpa = (x, d) => String(x || d).replace(/[\\/:*?"<>|]+/g, "_").slice(0, 60);
    const pasta = `Projudi/${hoje}/${limpa(it.serventia, "Segredo")}/${limpa(it.classificador, "Segredo de justiça")}`;
    await chrome.storage.local.set({ ["lote_" + lote]: { itens: [{ processo: it.processo, url: it.url, classificador: it.classificador || "", serventia: it.serventia || "", situacao: it.tipo || "", urlPre: it.urlPre || "", serventiaUrl: it.serventiaUrl || "", arquivoModelos: automacao[chaveServ]?.arquivoModelos || "", prompt: it.prompt, aceiteSigilo: true, itemId: it.id, pasta }], pasta: "Projudi/" + hoje, opcoes: { atualizarBase: false, studio: { ativo: true, modo: "agaiapdf", docs: false } } } });
    await atualizar(id, { estado: "pausado", sigiloso: false, erro: "", aviso: "Segredo de justiça: baixando o PDF (sem OCR) para anexar no Agaia. Esta mesma linha segue sozinha quando o PDF ficar pronto." });
    chrome.tabs.create({ url: chrome.runtime.getURL("lote.html?lote=" + lote) });
    desenhar(); return;
  }
  if (a === "usar") { usarMinutaDoStudio((await todos()).find((x) => x.id === id)); return; }
  if (a === "conferido") await atualizar(id, { estado: "conferido" });
  if (a === "concluir") { await fecharAbas((await todos()).find((x) => x.id === id)); await atualizar(id, { estado: "concluido" }); }
  if (a === "projudi") { const it = (await todos()).find((x) => x.id === id), t = await abrirNoProjudi(it, absoluta(it.urlPre || it.url), true); await atualizar(id, { abas: { ...(it.abas || {}), projudi: t.id } }); }
  passo();
});
chrome.storage.sync.get("esteiraConfig").then(({ esteiraConfig = {} }) => { $("entrada").value = esteiraConfig.entrada || "pdf"; });
$("entrada").onchange = async () => { const { esteiraConfig = {} } = await chrome.storage.sync.get("esteiraConfig"); chrome.storage.sync.set({ esteiraConfig: { ...esteiraConfig, entrada: $("entrada").value } }); };
// Recuperação: coloca na fila PDFs "número-OCR.pdf" que já estão no computador (a fila foi perdida ou os PDFs vieram de fora).
// Declarações exigidas pelo Agaia em processo sigiloso. São do USUÁRIO: a extensão só as marca depois que ele as aceita aqui (uma vez para este processo).
function confirmarDeclaracoes(it) {
  return new Promise((ok) => {
    const fundo = document.createElement("div");
    fundo.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:99999";
    fundo.innerHTML = `<div style="background:#fff;color:#111;border-radius:12px;padding:18px;max-width:600px;width:94%;font:14px system-ui"><b>Processo em segredo de justiça — Agaia</b><p style="margin:8px 0">Processo <b>${esc(it.processo)}</b>. Para rodar no Agaia, a extensão vai marcar, <b>em seu nome</b>, o que o Agaia exige:</p><ol style="margin:6px 0 10px 18px"><li>Na janela de responsabilidade: <i>“Entendi e desejo continuar”</i> — é sua responsabilidade garantir que os documentos estejam anonimizados e não contenham informações sensíveis que não devam ser processadas pelo sistema.</li><li>Depois que o Agaia extrair o texto do PDF: a caixa <i>“avaliei a extração realizada pela AGAIA. Concordo com o texto extraído, não identifiquei inconformidades com a LGPD e autorizo seu envio para a IA”</i>.</li></ol><p style="margin:6px 0;color:#7c2d12"><b>Atenção:</b> a segunda declaração diz que você avaliou o texto extraído. A extensão não o lê por você; revise a minuta e o processo depois.</p><label style="display:flex;gap:8px;align-items:flex-start;margin:10px 0"><input type="checkbox" id="declOk" style="margin-top:3px"> <span>Li e assumo, como responsável, estas declarações para este processo.</span></label><div style="display:flex;gap:8px;justify-content:flex-end"><button id="declCancelar">Cancelar</button><button id="declOkBtn" disabled style="background:#7c2d12;color:#fff;font-weight:700">Rodar no Agaia com PDF</button></div></div>`;
    document.body.appendChild(fundo);
    const caixa = fundo.querySelector("#declOk"), btn = fundo.querySelector("#declOkBtn");
    caixa.onchange = () => { btn.disabled = !caixa.checked; };
    fundo.querySelector("#declCancelar").onclick = () => { fundo.remove(); ok(false); };
    btn.onclick = () => { fundo.remove(); ok(true); };
  });
}

// ---- Quando a Agaia (ou uma IA externa) falha: a própria linha oferece seguir pelo Studio ou por outra IA, sem voltar ao painel. ----
let listaPrompts = [];      // prompts do cadastro da pessoa no Studio (preenchida por carregarPrompts)

/** Prompt para o novo caminho. Ordem: o que a pessoa escolheu na linha → o que a linha já tinha → o cadastrado para a serventia → um com o nome da serventia.
 *  Só vale o que o Studio realmente tem (a lista é a do cadastro da pessoa no Studio). Se nenhum servir, abre a lista do Studio para a pessoa escolher. Devolve "" se ela desistir. */
async function resolverPrompt(it, forcado) {
  const { automacao = {} } = await chrome.storage.sync.get("automacao");
  const chaveServ = Object.keys(automacao).find((x) => String(x).trim().toLowerCase() === String(it.serventia || "").trim().toLowerCase());
  const candidatos = [...new Set([forcado, it.prompt, automacao[chaveServ]?.prompt, globalThis.Sugestoes ? Sugestoes.prompt(it.serventia) : "", it.serventia].map((x) => String(x || "").trim()).filter(Boolean))];
  let opcoes = [], inalcancavel = false;
  for (const c of candidatos) {
    try { await lerPromptDoStudio(c); return c; }
    catch (e) { if (Array.isArray(e.opcoes) && e.opcoes.length) opcoes = e.opcoes; else { inalcancavel = true; break; } }      // sem resposta do Studio: não insiste (cada tentativa espera vários segundos)
  }
  const explicito = String(forcado || it.prompt || "").trim();
  if (!opcoes.length && inalcancavel && explicito) return explicito;      // o Studio não respondeu: confia no que a linha já usava (a esteira confere de novo ao rodar)
  if (!opcoes.length && !inalcancavel) { try { await lerPromptDoStudio(""); } catch (e) { opcoes = Array.isArray(e.opcoes) ? e.opcoes : []; } }
  if (!opcoes.length) opcoes = listaPrompts.length ? listaPrompts : [...new Set(Object.values(automacao).map((x) => x.prompt).filter(Boolean))];
  return await escolherPrompt(it, opcoes);
}

/** Leva esta linha para o Studio (destino "studio") ou para uma IA externa (destino = id da IA), mantendo a MESMA linha da esteira. */
async function rodarEm(id, destino, promptForcado) {
  const it = (await todos()).find((x) => x.id === id); if (!it) return;
  const ia = destino !== "studio";
  if (ia && !SITES_IA[destino]) return;
  if (ia && it.sigiloso) { alert("Processo em segredo de justiça: ele não é enviado a IA externa. Use “Rodar no Studio”."); return; }
  const nome = ia ? SITES_IA[destino].nome : "Studio";
  // a autorização do navegador só pode ser pedida logo no clique: faz isso ANTES de qualquer janelinha
  if (ia && !(await temPermissao(destino))) { const ok = await pedirPermissao(destino).catch(() => false); if (!ok) { alert(`Sem autorização para o ${nome}: a extensão não consegue usá-lo. Clique de novo e escolha “Permitir”.`); return; } }
  const prompt = await resolverPrompt(it, promptForcado);
  if (!prompt) return;      // desistiu
  const base = { modo: ia ? "ia" : "analise", iaId: ia ? destino : "", prompt, promptOpcoes: null, promptEscolhido: "", sigiloso: false, erro: "", agaiaErro: "", agaiaPedido: null, tentativas: 0, rodada: 0 };
  // PDF com OCR já guardado (linha que vinha de IA externa ou Studio): segue direto, sem baixar de novo
  const guardado = (it.modo === "ia" || it.modo === "analise") ? await lerPdf(it.id).catch(() => null) : null;
  if (guardado && guardado.length > 1000 && it.pdfNome) {
    await atualizar(id, { ...base, estado: "aguardando", aviso: `Seguindo no ${nome} com o prompt “${prompt}” (PDF já guardado).` });
    desenhar(true); passo(); return;
  }
  if (!it.url) { alert("Esta linha não guardou o endereço do processo no Projudi. Envie o processo de novo pelo Painel."); return; }
  const { automacao = {} } = await chrome.storage.sync.get("automacao");
  const chaveServ = Object.keys(automacao).find((x) => String(x).trim().toLowerCase() === String(it.serventia || "").trim().toLowerCase());
  const hoje = new Date().toISOString().slice(0, 10), lote = String(Date.now());
  const limpa = (x, d) => String(x || d).replace(/[\\/:*?"<>|]+/g, "_").slice(0, 60);
  const pasta = `Projudi/${hoje}/${limpa(it.serventia, "Processo")}/${limpa(it.classificador, "Reenvio")}`;
  await chrome.storage.local.set({ ["lote_" + lote]: { itens: [{ processo: it.processo, url: it.url, classificador: it.classificador || "", serventia: it.serventia || "", situacao: it.tipo || "", urlPre: it.urlPre || "", serventiaUrl: it.serventiaUrl || "", arquivoModelos: automacao[chaveServ]?.arquivoModelos || "", prompt, itemId: it.id, pasta }], pasta: "Projudi/" + hoje, opcoes: { atualizarBase: false, studio: { ativo: true, modo: base.modo, docs: false, iaId: base.iaId } } } });
  await atualizar(id, { estado: "pausado", sigiloso: false, erro: "", aviso: `Baixando o PDF e fazendo o OCR para rodar no ${nome} com o prompt “${prompt}”. Esta mesma linha segue sozinha quando o PDF ficar pronto.` });
  chrome.tabs.create({ url: chrome.runtime.getURL("lote.html?lote=" + lote) });
  desenhar(true);
}

// Janelinha para escolher o prompt do Studio quando nenhum corresponde à serventia do processo. Devolve o prompt escolhido ou "" se o usuário cancelar.
function escolherPrompt(it, opcoes) {
  return new Promise((ok) => {
    const fundo = document.createElement("div");
    fundo.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:99999";
    fundo.innerHTML = `<div style="background:#fff;color:#111;border-radius:12px;padding:18px;max-width:520px;width:92%;font:14px system-ui"><b>Escolha o prompt do Studio</b><p style="margin:8px 0">Não encontrei no Studio um prompt para a serventia <b>${esc(it.serventia || "(não identificada)")}</b>. Selecione qual usar neste processo em segredo de justiça (<small>${esc(it.processo)}</small>):</p>${opcoes.length ? `<select id="escPrompt" style="width:100%;padding:6px"><option value="">— escolha o prompt —</option>${opcoes.map((o) => `<option value="${esc(o)}">${esc(o)}</option>`).join("")}</select>` : `<p style="color:#b91c1c">Não consegui ler a lista de prompts do Studio (abra o Studio e tente de novo).</p>`}<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px"><button id="escCancelar">Cancelar</button><button id="escOk" ${opcoes.length ? "" : "disabled"} style="background:#b45309;color:#fff;font-weight:700">Rodar no Studio</button></div></div>`;
    const fim = (v) => { fundo.remove(); ok(v); };
    document.body.appendChild(fundo);
    fundo.querySelector("#escCancelar").onclick = () => fim("");
    fundo.querySelector("#escOk").onclick = () => { const v = fundo.querySelector("#escPrompt")?.value || ""; if (!v) { alert("Escolha um prompt da lista."); return; } fim(v); };
  });
}

// lista de prompts (a mesma do Studio) numa caixa de seleção com seta; se o Studio não responder, usa os prompts cadastrados no Painel
async function carregarPrompts() {
  const sel = $("impPrompt"), msg = $("impPromptMsg"), atual = sel.value; msg.textContent = "carregando a lista do Studio…";
  let lista = [];
  try { await lerPromptDoStudio(""); } catch (e) { lista = Array.isArray(e.opcoes) ? e.opcoes : []; }
  if (!lista.length) { const { automacao = {} } = await chrome.storage.sync.get("automacao"); lista = [...new Set(Object.values(automacao).map((a) => a.prompt).filter(Boolean))]; msg.textContent = "(lista do Painel: o Studio não respondeu)"; } else { msg.textContent = `${lista.length} prompts`; if (lista.join("|") !== listaPrompts.join("|")) { listaPrompts = lista; void desenhar(); } }
  sel.innerHTML = '<option value="">— o prompt cadastrado para a serventia do processo —</option>' + lista.map((x) => `<option value="${esc(x)}">${esc(x)}</option>`).join("");
  if (atual && lista.includes(atual)) sel.value = atual; else if (lista.length === 1) sel.value = lista[0];
}
$("impModo").onchange = () => { $("impSeeuAjuda").hidden = $("impModo").value !== "agaiaseeu"; };
$("impPromptRecarregar").onclick = () => void carregarPrompts();
void carregarPrompts();

$("impArq").onchange = async () => {
  const modo = $("impModo").value, promptDigitado = $("impPrompt").value.trim(), docs = false, arqs = [...$("impArq").files];
  const { estado } = await chrome.storage.local.get("estado"), { automacao = {} } = await chrome.storage.sync.get("automacao");
  const k = (x) => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/\s*-\s*go\s*$/, "").trim();
  // procura o processo (pelos 9 primeiros dígitos) entre os que o painel já conhece: traz serventia, links e prompt cadastrado
  const achar = (dig) => {
    for (const sv of estado?.serventias || []) for (const grupo of ["naoAnalisadas", "preAnalisadas"]) for (const p of sv.processos?.[grupo] || [])
      if (chaveProc(p.processo) === dig) return { ...p, serventia: sv.serventia, serventiaUrl: sv.url || "", situacao: grupo };
    return null;
  };
  const msgs = []; let n = 0; const ja = new Set((await todos()).map((i) => i.processo));
  for (const f of arqs) {
    if (modo === "agaiaseeu") {      // SEEU → Agaia: o PDF do SEEU (nome com o número CNJ completo) é anexado na área SEEU do Agaia; a minuta volta e é gravada no Histórico do Studio
      const m = f.name.replace(/\.pdf$/i, "").match(/(\d{7})\D?(\d{2})\D?(\d{4})\D?(\d)\D?(\d{2})\D?(\d{4})/);
      if (!m) { msgs.push(`${f.name}: o nome do arquivo precisa ter o número CNJ completo do processo do SEEU (20 dígitos)`); continue; }
      const proc = `${m[1]}-${m[2]}.${m[3]}.${m[4]}.${m[5]}.${m[6]}`;
      if (ja.has(proc)) { msgs.push(`${proc}: já está na fila`); continue; }
      if (!promptDigitado) { msgs.push(`${proc}: escolha o prompt (campo ao lado): a esteira procura o parecido no Agaia`); continue; }
      await enfileirar({ processo: proc, url: "", urlPre: "", prompt: promptDigitado, modo: "agaiaseeu", docs, pdfNome: f.name, pdf: f.name, serventia: "", serventiaUrl: "", sistema: "seeu", aceiteSigilo: !!$("impSeeuAceite")?.checked }, new Uint8Array(await f.arrayBuffer()));
      ja.add(proc); n++; continue;
    }
    const cnj = (f.name.match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [])[0], curto = (f.name.match(/(\d{3,7})[-.](\d{1,2})(?!\d)/) || []);
    const dig = cnj ? chaveProc(cnj) : curto[1] ? curto[1].padStart(7, "0") + curto[2].padStart(2, "0") : "";
    if (!dig) { msgs.push(`${f.name}: sem número de processo no nome`); continue; }
    const conhecido = achar(dig), proc = conhecido?.processo || cnj || `${curto[1].padStart(7, "0")}.${curto[2]}`;
    if (ja.has(proc)) { msgs.push(`${proc}: já está na fila`); continue; }
    const chaveServ = conhecido && Object.keys(automacao).find((x) => k(x) === k(conhecido.serventia));
    const prompt = promptDigitado || (chaveServ && automacao[chaveServ]?.prompt) || (conhecido && globalThis.Sugestoes ? Sugestoes.prompt(conhecido.serventia) : "");
    if (modo !== "turbo" && !prompt) { msgs.push(`${proc}: sem prompt (preencha o campo ou marque a serventia no painel)`); continue; }
    let minutaAssessor = "", motivoMinuta = "";
    if (modo === "lupa") {
      if (!conhecido || conhecido.situacao !== "preAnalisadas") motivoMinuta = "o processo não está entre as pré-analisadas do painel (clique em “Verificar agora” no painel)";
      else { $("impMsg").textContent = `Lendo a minuta do assessor de ${proc}…`; const r = await lerMinutaPre({ processo: proc, serventiaUrl: conhecido.serventiaUrl }).catch((e) => ({ texto: "", motivo: e.message })); minutaAssessor = r.texto; motivoMinuta = r.motivo; }
    }
    const num = proc.replace(/\D/g, ""), url = conhecido?.url || (cnj ? `BuscaProcesso?PaginaAtual=2&TipoConsultaProcesso=24&ProcessoNumero=${num.slice(0, -13)}-${num.slice(-13)}` : "");
    await enfileirar({ processo: proc, url, urlPre: conhecido?.urlPre || "", prompt, modo, docs, minutaAssessor, motivoMinuta, pdfNome: f.name, pdf: f.name, serventia: conhecido?.serventia || "", serventiaUrl: conhecido?.serventiaUrl || "" }, new Uint8Array(await f.arrayBuffer()));
    ja.add(proc); n++;
    if (modo === "lupa" && !minutaAssessor) msgs.push(`${proc}: entrou na fila, mas sem a minuta do assessor (${motivoMinuta})`);
  }
  $("impMsg").textContent = (n ? `${n} processo(s) adicionados à fila (${{ analise: "Análise", lupa: "Lupa do Magistrado", turbo: "Análise Turbo", mesa: "Mesa de Audiência", agaiaseeu: "SEEU → Agaia" }[modo]}). ` : "Nenhum arquivo novo. ") + msgs.join(" | ");
  $("impArq").value = ""; passo();
};
$("limpar").onclick = async () => { await remover((await todos()).filter((i) => ["concluido", "pulado"].includes(i.estado)).map((i) => i.id)); desenhar(); };
chrome.storage.onChanged.addListener((c, area) => { if (area === "local" && Object.keys(c).some((k) => k.startsWith("esteira_"))) { desenhar(); passo(); } });
setInterval(passo, 3000);

// Só uma aba executa a fila. A dona avisa que está viva (pulso); se o pulso some (aba antiga/travada ou extensão recarregada), esta aba assume.
async function assumir(lock) {
  if (!lock) return;
  dono = true;
  for (const it of await todos()) if (it.estado === "analisando" || it.estado === "pausado") await atualizar(it.id, { estado: "aguardando", rodada: 0, erro: "" });     // a aba anterior foi fechada no meio da análise: a fila retoma de onde parou (o processo interrompido volta ao início da fila)
  document.body.dataset.executor = "1";
  const pulsar = () => chrome.storage.local.set({ pulso_esteira: Date.now() }).catch(() => {});
  pulsar(); setInterval(pulsar, 4000);
  await desenhar(); passo();
  await new Promise(() => {});      // segura o bloqueio enquanto a aba existir
}
// Uma única aba da esteira: se já existe uma viva (pulso recente), esta se fecha e a existente vem à frente; abas antigas sem sinal de vida são fechadas.
async function umaSoAba() {
  try {
    const eu = await chrome.tabs.getCurrent(); if (!eu) return false;
    const url = chrome.runtime.getURL("esteira.html");      // (tabs.query por URL não enxerga páginas da própria extensão sem a permissão "tabs": usa getContexts)
    const outras = (await chrome.runtime.getContexts({ contextTypes: ["TAB"] })).filter((c) => (c.documentUrl || "").startsWith(url) && c.tabId !== eu.id).map((c) => ({ id: c.tabId, windowId: c.windowId }));
    if (!outras.length) return false;
    const { pulso_esteira = 0 } = await chrome.storage.local.get("pulso_esteira");
    if (Date.now() - pulso_esteira < 25000) {
      await chrome.tabs.update(outras[0].id, { active: true }).catch(() => {}); chrome.windows.update(outras[0].windowId, { focused: true }).catch(() => {});
      await chrome.tabs.remove(eu.id); return true;
    }
    for (const x of outras.filter((o) => o.id < eu.id)) await chrome.tabs.remove(x.id).catch(() => {});      // abas antigas/travadas
  } catch (e) { /* segue como aba normal */ }
  return false;
}
umaSoAba().then((fechou) => { if (fechou) return;
  navigator.locks.request("esteira-executor", { ifAvailable: true }, async (lock) => { if (!lock) desenhar(); return assumir(lock); }).catch(() => { dono = false; });
});
setInterval(async () => {
  if (dono) return;
  const { pulso_esteira = 0 } = await chrome.storage.local.get("pulso_esteira").catch(() => ({}));
  if (Date.now() - pulso_esteira < 25000) return;      // a aba dona está viva
  navigator.locks.request("esteira-executor", { steal: true }, assumir).catch(() => { dono = false; });
}, 6000);

// O computador não entra em espera enquanto houver processo na fila ou em análise (só a aba dona da fila dá o sinal).
vigiarAcordado("esteira", async () => dono && (await todos()).some((i) => ["aguardando", "analisando", "recebida"].includes(i.estado)));
setInterval(conferirAcordado, 60000);

// Pauta de audiências: abre a pauta (modelo do gabinete) com as audiências concluídas que o usuário marcou
$("pautaTodos").onclick = async () => { for (const x of (await todos()).filter((i) => i.modo === "mesa" && i.estado === "concluido")) await atualizar(x.id, { pautaSel: true }); desenhar(); };
$("pautaGerar").onclick = async () => { const ids = (await todos()).filter((i) => i.modo === "mesa" && i.estado === "concluido" && i.pautaSel).map((i) => i.id); if (ids.length) chrome.tabs.create({ url: chrome.runtime.getURL("pauta-doc.html?ids=" + ids.join(",")) }); };

document.addEventListener("focusout", (ev) => { if (redesenharDepois && ev.target && ev.target.tagName === "SELECT") setTimeout(() => { if (document.activeElement?.tagName !== "SELECT") { redesenharDepois = false; void desenhar(); } }, 700); });

// ----- Sentenças com vídeo já preparadas: refazer sem baixar nem degravar de novo -----
const tam = (n) => (n >= 1048576 ? Math.round(n / 1048576) + " MB" : Math.round(n / 1024) + " KB");
async function desenharGuardados() {
  const todosSt = await chrome.storage.local.get(null), lista = Object.entries(todosSt).filter(([k]) => k.startsWith("midias_")).map(([k, v]) => ({ chave: k.slice(7), ...v, degr: todosSt["degr_" + k.slice(7)] })).sort((a, b) => (b.em || 0) - (a.em || 0));
  $("guardadosN").textContent = lista.length ? `(${lista.length})` : "(nenhuma)";
  $("guardadosLinhas").innerHTML = lista.length ? lista.map((g) => `<tr><td>${esc(g.processo || g.chave)}</td><td>${(g.meta || []).length} · ${tam((g.meta || []).reduce((n, x) => n + x.tamanho, 0))}</td><td>${g.degr ? "✅ pronta" : "ainda não"}</td><td>${new Date(g.em || 0).toLocaleString("pt-BR")}</td><td><button data-gv-refazer="${esc(g.chave)}">Refazer a sentença</button> <button data-gv-apagar="${esc(g.chave)}">Apagar</button></td></tr>`).join("") : `<tr><td colspan="5">Nada guardado ainda.</td></tr>`;
}
$("guardadosLinhas").addEventListener("click", async (ev) => {
  const r = ev.target.closest("[data-gv-refazer]"), a = ev.target.closest("[data-gv-apagar]");
  if (a) { if (confirm("Apagar o PDF, os vídeos e a degravação guardados deste processo?")) { await apagarGuardadosDoVideo(a.dataset.gvApagar); desenharGuardados(); } return; }
  if (!r) return;
  const chave = r.dataset.gvRefazer, { ["midias_" + chave]: m } = await chrome.storage.local.get("midias_" + chave), bytes = await lerPdfDoVideo(chave).catch(() => null);
  if (!m || !bytes) { alert("O PDF deste processo não está mais guardado. Envie o processo de novo pela Pauta."); return; }
  const escolhido = $("impPrompt").value.trim() || m.prompt || "";
  await enfileirar({ processo: m.processo || chave, modo: "video", serventia: m.serventia || "", prompt: escolhido, pdfNome: m.pdfNome || `${chave}-OCR.pdf`, classificador: "pauta" }, bytes);
  $("impMsg").textContent = `${m.processo || chave} voltou para a fila (${escolhido ? "prompt: " + escolhido : "prompt da serventia"}); a degravação guardada será reaproveitada.`;
  desenharGuardados();
});
chrome.storage.onChanged.addListener((c, area) => { if (area === "local" && Object.keys(c).some((k) => k.startsWith("midias_") || k.startsWith("degr_"))) desenharGuardados(); });
void limparGuardadosAntigos(7).then(desenharGuardados);

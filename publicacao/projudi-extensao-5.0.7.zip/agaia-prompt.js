// Agaia (simplesefacil.tjgo.jus.br/agaia): troca o texto de um prompt do usuário pelo prompt do Studio.
// Três passos, comandados pela extensão (a página recarrega entre eles): achar na lista pelo TÍTULO → ler o texto atual (cópia de segurança) → gravar o novo texto e clicar em Salvar.
(() => {
  if (window.__projudiAgaiaPrompt) return;
  window.__projudiAgaiaPrompt = true;
  const dorme = (ms) => new Promise((ok) => setTimeout(ok, ms));
  const sem = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\s+/g, " ").trim().toLowerCase();
  const visivel = (el) => { const r = el.getBoundingClientRect(); const cs = getComputedStyle(el); return r.width > 20 && r.height > 10 && cs.visibility !== "hidden" && cs.display !== "none"; };
  const norm = (s) => String(s || "").replace(/ /g, " ").replace(/[ \t]+/g, " ").replace(/\s*\n\s*/g, "\n").trim();

  // ---------- Lista: acha a linha cujo Título é igual ao procurado ----------
  function linhasDaTabela() {
    const tabs = [...document.querySelectorAll("table")];
    const out = [];
    for (const t of tabs) {
      const cab = [...t.querySelectorAll("thead th, tr:first-child th")].map((h) => sem(h.textContent));
      const iTit = cab.findIndex((x) => x.startsWith("titulo")), iUni = cab.findIndex((x) => x.startsWith("unidade")), iPriv = cab.findIndex((x) => x.startsWith("privacidade"));
      if (iTit < 0) continue;
      for (const tr of t.querySelectorAll("tbody tr")) {
        const tds = [...tr.children]; if (tds.length <= iTit) continue;
        const editar = [...tr.querySelectorAll("a,button")].find((a) => /editar/i.test((a.textContent || "") + " " + (a.title || "") + " " + (a.getAttribute("aria-label") || "")) || /\/prompts\/edit\//.test(a.getAttribute("href") || ""));
        out.push({ tr, titulo: (tds[iTit].textContent || "").replace(/\s+/g, " ").trim(), unidade: iUni >= 0 ? (tds[iUni]?.textContent || "").trim() : "", privacidade: iPriv >= 0 ? (tds[iPriv]?.textContent || "").trim() : "", editar });
      }
    }
    return out;
  }
  const proximaPagina = () => [...document.querySelectorAll("a,button")].find((a) => /^(pr[oó]xim[oa]|next|›|»|>)$/i.test((a.textContent || "").trim()) && !/disabled/.test(a.className + " " + (a.parentElement?.className || "")) && !a.disabled && visivel(a));

  async function achar(titulo) {
    const alvo = sem(titulo);
    const cauda = sem(String(titulo).split(" - ").pop());      // “Outros Área Judicial - Execução Fiscal Estadual” → “execução fiscal estadual”: no Agaia vem com prefixo (ex.: “Fabrício Execução Fiscal Estadual”)
    const candidatas = [];
    let vistos = [];
    for (let pag = 0; pag < 30; pag++) {
      for (let i = 0; i < 20 && !linhasDaTabela().length; i++) await dorme(300);      // a lista pode carregar depois (DataTables)
      const linhas = linhasDaTabela();
      vistos = vistos.concat(linhas.map((l) => l.titulo));
      const pontua = (l) => { const x = sem(l.titulo); return x === alvo ? 3 : (x === cauda || x.endsWith(" " + cauda)) ? 2 : (cauda.length >= 6 && x.includes(cauda)) ? 1 : 0; };
      for (const l of linhas) if (l.editar && pontua(l)) candidatas.push({ l, p: pontua(l) });
      const prox = proximaPagina(); if (!prox) break;
      const antes = linhas.map((l) => l.titulo).join("|");
      prox.click(); await dorme(900);
      if (linhasDaTabela().map((l) => l.titulo).join("|") === antes) break;      // o clique não mudou a lista: acabou
    }
    if (candidatas.length) {
      const melhor = Math.max(...candidatas.map((c) => c.p)), top = candidatas.filter((c) => c.p === melhor);
      const menor = Math.min(...top.map((c) => c.l.titulo.length)), fim = top.filter((c) => c.l.titulo.length === menor);
      if (fim.length === 1) { const e = fim[0].l, href = e.editar.getAttribute("href") || ""; if (!href) return { ok: false, erro: "o botão Editar do Agaia não tem endereço (mudou o layout?)" };
        return { ok: true, href: new URL(href, location.href).href, id: (href.match(/\/prompts\/edit\/([^/?#]+)/) || [])[1] || "", unidade: e.unidade, privacidade: e.privacidade, tituloAgaia: e.titulo }; }
      return { ok: false, erro: `há ${fim.length} prompts parecidos com “${titulo}” no Agaia (${fim.map((c) => `“${c.l.titulo}” — ${c.l.unidade || "sem unidade"}`).join("; ")}). Não sei qual trocar; deixe só um com esse nome.` };
    }
    return { ok: false, naoEncontrado: true, erro: `não achei no Agaia um prompt parecido com “${titulo}” (vi ${vistos.length} prompts na lista; procurei por “${String(titulo).split(" - ").pop()}” no título).` };
  }

  // ---------- Editor da página de edição ----------
  function editores() {
    const lista = [];
    for (const el of document.querySelectorAll(".ql-editor, .ck-editor__editable, .note-editable, .fr-element, .trix-content, trix-editor, [contenteditable='true'], [contenteditable='']")) if (visivel(el)) lista.push({ tipo: "rico", el });
    for (const f of document.querySelectorAll("iframe")) { try { const b = f.contentDocument?.body; if (b && (b.isContentEditable || b.getAttribute("contenteditable") === "true") && visivel(f)) lista.push({ tipo: "rico", el: b, iframe: f }); } catch (e) { /* outro domínio */ } }
    for (const el of document.querySelectorAll("textarea")) if (visivel(el)) lista.push({ tipo: "textarea", el });
    const area = (x) => { const r = (x.iframe || x.el).getBoundingClientRect(); return r.width * r.height; };
    return lista.sort((a, b) => area(b) - area(a));
  }
  const textoDe = (ed) => ed.tipo === "textarea" ? ed.el.value : blocosParaTexto(ed.el);
  /** Texto do editor rico preservando as quebras de linha (cada parágrafo/linha vira uma linha). */
  function blocosParaTexto(raiz) {
    const linhas = [], atual = [];
    const fecha = () => { linhas.push(atual.join("")); atual.length = 0; };
    const BLOCO = /^(P|DIV|LI|H[1-6]|BLOCKQUOTE|PRE|TR)$/;
    (function anda(n) {
      for (const c of n.childNodes) {
        if (c.nodeType === 3) atual.push(c.nodeValue);
        else if (c.nodeType === 1) {
          if (c.tagName === "BR") { fecha(); continue; }
          const b = BLOCO.test(c.tagName); if (b && atual.length) fecha();
          anda(c); if (b) fecha();
        }
      }
    })(raiz);
    if (atual.length) fecha();
    return linhas.join("\n").replace(/\n{3,}/g, "\n\n").replace(/^\n+|\s+$/g, "");
  }
  const escapa = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const textoParaHtml = (t) => String(t).split("\n").map((l) => "<p>" + (l.trim() ? escapa(l) : "<br>") + "</p>").join("");

  function campoTitulo() {
    return [...document.querySelectorAll("input[type=text],input:not([type])")].filter(visivel).find((i) => /t[ií]tulo|title/i.test((i.name || "") + " " + (i.id || "") + " " + (i.placeholder || "") + " " + (i.labels?.[0]?.textContent || "")));
  }
  function botaoSalvar() {
    return [...document.querySelectorAll("button,input[type=submit],input[type=button],a.btn")].filter(visivel).find((b) => /^\s*salvar\s*$/i.test(b.textContent || b.value || ""));
  }

  const textoParaDivs = (t) => String(t).split("\n").map((l) => l.length ? "<div>" + escapa(l).replace(/\t/g, "    ").replace(/^ +/, (m) => "&nbsp;".repeat(m.length)).replace(/ {2,}/g, (m) => " " + "&nbsp;".repeat(m.length - 1)) + "</div>" : "<div><br></div>").join("");
  /** Pede ao script da página (mundo MAIN, com acesso ao jQuery/Summernote do Agaia) que coloque o HTML no editor e atualize o campo enviado. */
  function viaSummernote(html) {
    return new Promise((res) => {
      const id = "sn" + Date.now() + Math.random().toString(36).slice(2, 6);
      const f = (ev) => { const d = ev.data; if (ev.source !== window || !d || d.__agaiaPromptMainResp !== id) return; window.removeEventListener("message", f); clearTimeout(t); res(d); };
      const t = setTimeout(() => { window.removeEventListener("message", f); res({ ok: false, erro: "o script da página do Agaia não respondeu" }); }, 15000);
      window.addEventListener("message", f);
      window.postMessage({ __agaiaPromptMain: "codigo", id, html }, "*");
    });
  }
  /** Summernote do Agaia: o texto guardado (bruto, com as marcas < >) está no textarea oculto "conteudo"; o editor só o MOSTRA como HTML (por isso as marcas somem na tela). É esse campo que vale. */
  const campoBruto = () => document.querySelector("textarea[name=conteudo], textarea#conteudo");

  async function ler() {
    const bruto = campoBruto(), sn = !!document.querySelector(".note-editable");
    if (bruto && sn) {      // espera o Summernote carregar o texto no editor; devolve o texto VISÍVEL (para conferir) e o BRUTO (para a cópia de segurança)
      let ed = null; for (let i = 0; i < 40 && !(ed = document.querySelector(".note-editable")); i++) await dorme(300);
      return { ok: true, texto: blocosParaTexto(ed), bruto: String(bruto.value || "").replace(/\r\n?/g, "\n"), html: "", tipo: "summernote", titulo: campoTitulo()?.value || "", salvarOk: !!botaoSalvar() };
    }
    let eds = [];
    for (let i = 0; i < 40 && !(eds = editores()).length; i++) await dorme(300);
    if (!eds.length) return { ok: false, erro: "não achei o campo de texto do prompt na página de edição do Agaia" };
    const ed = eds[0];
    return { ok: true, texto: textoDe(ed), html: ed.tipo === "textarea" ? "" : ed.el.innerHTML, tipo: ed.tipo, titulo: campoTitulo()?.value || "", salvarOk: !!botaoSalvar() };
  }

  function disparar(el) { for (const t of ["input", "change", "keyup"]) el.dispatchEvent(new Event(t, { bubbles: true })); }
  /** Troca todo o conteúdo do editor. Retorna true se o texto lido depois bate com o pedido. */
  async function escrever(ed, { texto, html }) {
    if (ed.tipo === "textarea") {
      ed.el.focus(); const set = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set; set.call(ed.el, texto); disparar(ed.el);
    } else {
      const doc = ed.el.ownerDocument, win = doc.defaultView;
      ed.el.focus();
      let ok = false;
      if (html == null) {
        try { doc.execCommand("selectAll", false, null); ok = doc.execCommand("insertText", false, ""); doc.execCommand("delete", false, null); } catch (e) { ok = false; }
        const linhas = String(texto).split("\n");
        for (let i = 0; i < linhas.length; i++) {
          try { if (linhas[i]) doc.execCommand("insertText", false, linhas[i]); if (i < linhas.length - 1) doc.execCommand("insertParagraph", false, null); } catch (e) { /* cai no plano B */ }
        }
        if (norm(blocosParaTexto(ed.el)) !== norm(texto)) { ed.el.innerHTML = textoParaHtml(texto); disparar(ed.el); }      // plano B: coloca o HTML direto
      } else { ed.el.innerHTML = html; disparar(ed.el); }
      try { win.getSelection().removeAllRanges(); } catch (e) { /* nada */ }
    }
    await dorme(300);
    return norm(textoDe(ed)) === norm(texto != null ? texto : blocosParaTexto(Object.assign(document.createElement("div"), { innerHTML: html })));
  }

  async function gravar({ texto, html, bruto: brutoPedido }) {
    const bruto = campoBruto(), ed0 = document.querySelector(".note-editable");
    if (bruto && ed0) {
      const salvar0 = botaoSalvar(); if (!salvar0) return { ok: false, erro: "não achei o botão Salvar" };
      const set = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set;
      if (typeof brutoPedido === "string") {      // DEVOLVER cópia: volta o texto bruto exatamente como estava guardado
        const t = brutoPedido.replace(/\r\n?/g, "\n"); set.call(bruto, t); ed0.innerHTML = t; await dorme(200);
        if (String(bruto.value) !== t) return { ok: false, erro: "o Agaia alterou o campo ao devolver a cópia; não salvei" };
        setTimeout(() => salvar0.click(), 250); return { ok: true, modo: "bruto" };
      }
      // ENVIAR: igual a colar à mão — o texto entra no editor (marcas < > escapadas, uma linha por <div>) pela API do próprio Summernote, que atualiza o campo enviado
      const t = String(texto ?? "").replace(/\r\n?/g, "\n");
      const r = await viaSummernote(textoParaDivs(t));
      if (!r.ok) return { ok: false, erro: "não consegui escrever pelo editor do Agaia (" + (r.erro || "sem resposta") + ")" };
      await dorme(300);
      const lido = blocosParaTexto(document.querySelector(".note-editable"));
      if (norm(lido) !== norm(t)) return { ok: false, erro: "o editor do Agaia não ficou com o texto enviado (conferência antes de salvar)", visto: lido.slice(0, 120) };
      if (!/&lt;|<div|<p|<br/i.test(String(bruto.value || "")) && /[<]/.test(t)) return { ok: false, erro: "o Agaia não atualizou o campo que ele envia ao salvar" };
      setTimeout(() => salvar0.click(), 250);
      return { ok: true, esperado: t, modo: "summernote", tamanhoCampo: String(bruto.value || "").length };
    }
    const eds = editores(); if (!eds.length) return { ok: false, erro: "não achei o campo de texto do prompt" };
    const ed = eds[0], salvar = botaoSalvar();
    if (!salvar) return { ok: false, erro: "não achei o botão Salvar" };
    const esperado = texto != null ? texto : blocosParaTexto(Object.assign(document.createElement("div"), { innerHTML: html }));
    const bateu = await escrever(ed, { texto, html });
    if (!bateu) return { ok: false, erro: "não consegui escrever o texto no editor do Agaia (o conteúdo lido depois não bateu)", visto: textoDe(ed).slice(0, 200) };
    setTimeout(() => salvar.click(), 250);      // a página recarrega ao salvar: responde antes
    return { ok: true, esperado };
  }


  /** Retrato da página de edição (para eu ajustar a gravação sem adivinhar): editor, campos do formulário, botão Salvar. Não inclui o texto inteiro do prompt. */
  function diagnostico() {
    const cab = (x, n = 400) => String(x || "").slice(0, n);
    const eds = editores().slice(0, 3).map((e) => ({ tipo: e.tipo, tag: e.el.tagName, id: e.el.id, classe: cab(e.el.className, 120), ce: e.el.getAttribute("contenteditable"), outerComeco: cab(e.el.outerHTML, 600), innerComeco: cab(e.tipo === "textarea" ? e.el.value : e.el.innerHTML, 700), tamanhoInner: (e.tipo === "textarea" ? e.el.value : e.el.innerHTML).length, pai: cab(e.el.parentElement?.outerHTML.replace(e.el.outerHTML, "[EDITOR]"), 500) }));
    const campos = [...document.querySelectorAll("form input, form textarea, form select")].map((c) => ({ tag: c.tagName, tipo: c.type || "", nome: c.name || "", id: c.id || "", tam: String(c.value || "").length, comeco: cab(c.value, 160) }));
    const forms = [...document.querySelectorAll("form")].map((f) => ({ action: f.getAttribute("action"), method: f.method, enctype: f.enctype, id: f.id, classe: cab(f.className, 80) }));
    const s = botaoSalvar();
    const botoes = [...document.querySelectorAll("button,a.btn,input[type=submit]")].filter(visivel).map((b) => cab((b.textContent || b.value || "").replace(/\s+/g, " ").trim(), 40));
    const scripts = [...document.scripts].map((x) => x.src ? x.src.split("/").slice(-1)[0] : "").filter(Boolean);
    return { url: location.href, forms, editores: eds, campos, salvar: s ? cab(s.outerHTML, 400) : null, botoes, scripts, libs: { quill: !!document.querySelector(".ql-container"), tinymce: !!document.querySelector(".tox,.mce-tinymce"), ckeditor: !!document.querySelector(".ck-editor"), summernote: !!document.querySelector(".note-editor"), trix: !!document.querySelector("trix-editor") } };
  }

  chrome.runtime.onMessage.addListener((m, s, responder) => {
    if (m?.acao === "agaia-prompt-ping") { responder({ ok: true, lista: linhasDaTabela().length, editor: editores().length }); return false; }
    if (m?.acao === "agaia-prompt-achar") { achar(String(m.titulo || "")).then(responder, (e) => responder({ ok: false, erro: String(e?.message || e) })); return true; }
    if (m?.acao === "agaia-prompt-bruto") { const b = campoBruto(); responder(b ? { ok: true, texto: String(b.value || ""), titulo: campoTitulo()?.value || "", url: location.href } : { ok: false, erro: "esta aba não é a tela de edição de um prompt do Agaia" }); return false; }
    if (m?.acao === "agaia-prompt-diagnostico") { responder(diagnostico()); return false; }
    if (m?.acao === "agaia-prompt-ler") { ler().then(responder, (e) => responder({ ok: false, erro: String(e?.message || e) })); return true; }
    if (m?.acao === "agaia-prompt-gravar") { gravar(m).then(responder, (e) => responder({ ok: false, erro: String(e?.message || e) })); return true; }
    return false;
  });
  window.__projudiAgaiaPromptTeste = { achar, ler, gravar, blocosParaTexto };      // usado só nos testes
})();
